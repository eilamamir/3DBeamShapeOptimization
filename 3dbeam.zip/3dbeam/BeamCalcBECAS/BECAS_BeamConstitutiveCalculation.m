function [utils,Ks,csSol,submats] = BECAS_BeamConstitutiveCalculation(E,nu,eldata)


%This function concentrates the calculatoin and estimation of all the BECAS
%properties


penal = 1;
relrho = eldata.rhoe; %relative density
nmat = length(relrho);
nu0 = nu*ones(nmat,1);
Emin = 1e-6*E;
% Emin = 1e-9;

E0 = Emin + (E - Emin)*relrho.^penal; 
G0 = E0./(2*(nu0+1));
E11 = E0; E22 = E0; E33 = E0; G12 = G0; G13 = G0 ; G23 = G0;
matprops = [E11,E22,E33,G12,G13,G23,nu0,nu0,nu0,relrho];
emat = [(1:eldata.nel)',(1:eldata.nel)',zeros(eldata.nel,2)];

options.foldername = pwd;
options.etype = [(1:eldata.nel)',ones(eldata.nel,1)]; %element type Q4
options.etype = 'Q4';
nl_2d = [(1:eldata.nnodes)',eldata.nx,eldata.ny];
el_2d = [(1:eldata.nel)',eldata.elconnect,zeros(eldata.nel,4)];
[ utils ] = BECAS_UtilsNoMessages( options , nl_2d, el_2d, emat, matprops);


% 
% try
%     options.foldername = 'C:\Users\noa2\Dropbox\Eilam\research\code\3dbeam\BECAS_files';
%     options.etype = [(1:eldata.nel)',ones(eldata.nel,1)]; %element type Q4
%     options.etype = 'Q4';
% 
%     nl_2d = [(1:eldata.nnodes)',eldata.nx,eldata.ny];
%     el_2d = [(1:eldata.nel)',eldata.elconnect,zeros(eldata.nel,4)];
%     [ utils ] = BECAS_UtilsNoMessages( options , nl_2d, el_2d, emat, matprops);
% catch
%     try
%         options.foldername = 'C:\Users\Eamir\Dropbox\Eilam\research\code\3dbeam\BECAS_files';
%         options.etype = [(1:eldata.nel)',ones(eldata.nel,1)]; %element type Q4
%         options.etype = 'Q4';   
%         nl_2d = [(1:eldata.nnodes)',eldata.nx,eldata.ny];
%         el_2d = [(1:eldata.nel)',eldata.elconnect,zeros(eldata.nel,4)];
%         [ utils ] = BECAS_UtilsNoMessages( options , nl_2d, el_2d, emat, matprops);
%     catch
%         options.foldername = 'C:\Users\eilamamir\Dropbox\Eilam\research\code\3dbeam\BECAS_files';
%         options.etype = [(1:eldata.nel)',ones(eldata.nel,1)]; %element type Q4
%         options.etype = 'Q4';   
%         nl_2d = [(1:eldata.nnodes)',eldata.nx,eldata.ny];
%         el_2d = [(1:eldata.nel)',eldata.elconnect,zeros(eldata.nel,4)];
%         [ utils ] = BECAS_UtilsNoMessages( options , nl_2d, el_2d, emat, matprops);
%     end
% end
utils.penal = penal;
utils.E = E;

[ Ks, csSol ]=BECAS_Constitutive_Ks_NoMessages(utils);
[submats.K11, submats.H, submats.G22 ] = BECAS_Assemble_Ks( utils );

end

