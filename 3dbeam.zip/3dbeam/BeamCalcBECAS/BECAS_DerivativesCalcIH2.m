function dQ = BECAS_DerivativesCalcIH2(utils,e)

%This function returns the constitutive stiffness matrix derivatives for an
%linear isotropic homogenous material (IH) with only one elasticity modulus and
%one Poison ratio.
%inputs:
%general property structure of BECAS: utils that contain the relative
%stiffness E0 = E11 = E22 = E33 and the absolute single Poisson ratio:
% nu = nu12 = nu23 = nu13
% 

nu12=utils.matprops(utils.emat(1,2),7);
nu13=utils.matprops(utils.emat(2,2),8);
nu23=utils.matprops(utils.emat(3,2),9);
if nu12 == nu13 && nu12 == nu23
    nu  = nu12;
else
    error('unisotropic material - cannot calculate plain strain condition');
    return;
end

Emin = 1e-6*utils.E;
Emax = utils.E;

dE = utils.penal*(Emax - Emin)*utils.density(e).^(utils.penal - 1);

dQm = zeros(6);

dQm(1,1) = 1 / (2 * nu ^ 2 + nu - 1) * (nu - 1);
dQm(1,2) = -nu / (2 * nu ^ 2 + nu - 1);
dQm(1,3) = -nu / (2 * nu ^ 2 + nu - 1);
dQm(2,2) = (nu - 1) / (nu + 1) / (2 * nu - 1);
dQm(2,3) = -nu / (nu + 1) / (2 * nu - 1);
dQm(3,3) = (nu - 1) / (2 * nu ^ 2 + nu - 1);
 dQm(4,4) = 1 /(2* (nu + 1));
%dQm(4,4) = 1;
dQm(5,5) =  dQm(4,4);
dQm(6,6) = dQm(4,4);

%symmetric matrix conversion
dQm = dQm + dQm' - diag(diag(dQm));

%conversion to BECAS indices
edof=[6 1 2 3 5 4];
dQm(edof,edof)=dQm;

dQ = dQm*dE;
end

