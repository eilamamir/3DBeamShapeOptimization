function [dKs]  = BECAS_dKs(varargin)

%This function calculates the derivatives of the stiffness matrix w.r.t.
%each planar finite element's density

utils = varargin{1};
Ks = varargin{2};
csSol = varargin{3};
submats = varargin{4};
ndof = length(csSol.X(:,1));
nB = ndof + 12;
K11 = submats.K11;
H = submats.H;
G22 = submats.G22;
K12 = H' - H;
X = sparse(csSol.X);
Y = sparse(csSol.Y);
dX = csSol.dX;
dY = csSol.dY;
Gamma2 = zeros(6);
Gamma1 = zeros(6);

W1 = [X;Y;Gamma2];
W2 = [dX;dY;Gamma1];
W = [W1;W2];

Gtilde = [K11,H';H,G22];
Wtilde = sparse(Gtilde*W);

Wtilde1 = Wtilde(1:nB,:);
Wtilde2 = Wtilde(nB+1:end,:);

[Lt,Ut,Pt,Qt] = lu(K11');
Zt = Lt\(Pt*Wtilde1);
Yt = Ut\Zt;
V1 = Qt*Yt;

rhs = -K12'*V1 + Wtilde2;
Zt = Lt\(Pt*rhs);
Yt = Ut\Zt;
V2 = Qt*Yt;

dFs = zeros(6,6,utils.ne_2d);
dKs = zeros(6,6,utils.ne_2d);

for e = 1:utils.ne_2d

    %locating specific active element DOFs
    an = utils.el_2d(e,2:5)'; %active nodes of element e
    adof = [an(1)*3-2:3*an(1),an(2)*3-2:3*an(2),an(3)*3-2:3*an(3),an(4)*3-2:3*an(4)]'; %active dofs
    
    dQe = BECAS_DerivativesCalcIH2(utils,e);
    [dMe, dEe, dCe] = BECAS_Q4( e, dQe, utils);
    
    %Build the remaining: dA/drhoe, dR/drhoe and dL/drhoe matrices
    dRe=dCe*utils.Zg(adof,:);
    dLe=dMe*utils.Zg(adof,:);
    dAe=utils.Zg(adof,:)'*dMe*utils.Zg(adof,:);
    dDe = zeros(6,12);
    
    dK11 = [dEe ,  dRe     ,           dDe' ;...
            dRe',  dAe     ,       zeros(6);...
            dDe ,  zeros(6),      zeros(6)];...
        
    dK12 = [-dCe' + dCe   , -dLe    ,zeros(12,6);...
             dLe'         ,zeros(6) ,zeros(6);...
            zeros(6,12 )  ,zeros(6) ,zeros(6)];
    
    dK = [dK11,dK12;zeros(24),dK11];
    
    dH  = [dCe'          ,dLe     ,zeros(12,6);...
            zeros(6,12),zeros(6),zeros(6);...
            zeros(6,12),zeros(6),zeros(6)];
    
    dG22 = [dMe           ,zeros(12,6),zeros(12,6);...
            zeros(6,12) ,zeros(6)     ,zeros(6)     ;...
            zeros(6,12) ,zeros(6)     ,zeros(6)     ];
    
    
    dGtilde = [dK11,dH';dH,dG22];
    
    Wadof1 = [X(adof,:);Y;Gamma2];
    Wadof2 = [dX(adof,:);dY;Gamma1];
    Wadof = [Wadof1;Wadof2];
    
    Vadof1 = [V1(adof,:);V1(ndof+1:ndof+6,:);V1(ndof+7:end,:)];
    Vadof2 = [V2(adof,:);V2(ndof+1:ndof+6,:);V2(ndof+7:end,:)];
    Vadof  = [Vadof1;Vadof2];
   
    dFs(:,:,e) = - Wadof'*dK'*Vadof + Wadof'*dGtilde*Wadof - Vadof'*dK*Wadof;
    dKs(:,:,e) = -Ks*dFs(:,:,e)*Ks;


end
end

    
    

    

