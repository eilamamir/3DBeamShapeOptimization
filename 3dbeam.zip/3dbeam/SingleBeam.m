function SingleBeam(dx,dy,dz,nmem,npts,nelx,nely,E,nu,loadval,indloaddof,volfrac,StatCase)

%A single 3D beam shape optimization of the compliance minimization problem
% used in 'Free form shape optimization of three dimensional beams using cross section analysis'
% https://doi.org/10.1016/j.ijsolstr.2023.112331
% it uses a high order arbitrary cross section beam calculated numerically
% where its design is updated using shape optimization process. For more
% details see the aforementioned paper.
%
%Inputs:
%   dx,dy,dz - the rectangular physical dimensions
%   nmem - number of beam members.
%   npts - number of control points of the bspline curve that represents the cross section's boundary
%   nelx,nely - number of cross section's planar elements
%   E - modulus of elasticity
%   nu - Poisson ratio.
%   loadval - load value
%   indloaddof - degree of freedom of the loading: 1-6: 1 - transverse force, 2 -
%   vertical force 3 - axial force, 4 - vertical bending moment (around the
%   transverse axis), 5 - transverse bending moment (around the vertical
%   axis), 6 - torsional moment (torque).
%   volfrac - the volume fraction
%   StatCase - the static problem case: 'cantilever', 'beam_dist_load',
%   'beam_dist_load_ps', 'beam_dist_load_ss'

%% Setting current path
error('Change the path on next line and uncomment it, and then comment the line of this message');
[basepath]='C:\your_full_dir_path'; % please update your user dir here
addpath(genpath(fullfile(basepath,'BeamCalcBECAS')));
addpath(genpath(fullfile(basepath,'BECASv3.3')));
addpath(genpath(fullfile(basepath,'bsplines')));
addpath(genpath(fullfile(basepath,'MMA subroutines')));
addpath(genpath(fullfile(basepath,'Misc')));
addpath(genpath(fullfile(basepath,'postProcessing')));


%% Building the physical domain and some general properties

close all;
Vol = dx*dy*dz;
gsdata = beamconstruct(dz,nmem);
nnodes = gsdata.nnodes;
membersg = cell(nmem,1);

for nm = 1:nmem %attributing geometrical properties to each member object - not needed for a single axial beam, yet I kept it here...
   membersg{nm}.L = gsdata.L(nm); %member length
   membersg{nm}.nodes = gsdata.memconnect(nm,:);
   membersg{nm}.IX = gsdata.IX(gsdata.memconnect(nm,:),:);
   membersg{nm}.Rt = eye(18); %Because the local and global frames coincide we use here the 18x18 eye matrix as a 'rotaion matrix'
end

Vstar = volfrac*Vol;
nelem = nelx*nely; %# of elements for cross section calc.
dsc = nelem*100; %discretization of the bspline - derivied from the 2d FE discretization of the cross section
spord = 4; % polynomial order - 1 of the bspline basis function
nGp = 2; %number of Gauss integration points

%% B.Cs & loadings: for each structural problem
ndofs = 6*nnodes;
alldofs = 1:ndofs;
nlc = length(indloaddof(:,1));
indloaddof = abs(indloaddof);
loadvalvec = zeros(nlc,6); %load DOF vector: # rows: #of LCs; #columns - DOF number: 1-6;
for il = 1:nlc
    loadvaltot(il) = sqrt(sum(loadval(il,:).^2)); %#ok<AGROW> 
    loadvalvec(il,indloaddof(il,:)) = loadval(il,:);
end
weight = loadvaltot/sum(loadvaltot);

switch StatCase
    case 'cantilever'
        fixednodes = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)))'; 
        fixeddofs = sort([6*fixednodes-5,6*fixednodes-4,6*fixednodes-3,6*fixednodes-2,6*fixednodes-1,6*fixednodes]);
        freedofs = setdiff(alldofs,fixeddofs);
        loadnodes = find(gsdata.IX(:,3)==max(gsdata.IX(:,3)) & gsdata.IX(:,2)==min(gsdata.IX(:,2)))';
        nloadnodes = length(loadnodes);
    case 'beam_dist_load' %suspended beam with distribuated loads
        fixednodes = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)) | gsdata.IX(:,3)==max(gsdata.IX(:,3)))';
        fixeddofs = sort([6*fixednodes-5,6*fixednodes-4,6*fixednodes-3,6*fixednodes-2,6*fixednodes-1,6*fixednodes]);
        freedofs = setdiff(alldofs,fixeddofs);        
        loadnodes = 1:nnodes;
        nloadnodes = length(loadnodes);
    case 'beam_dist_load_ps' %suspended beam with distribuated loads
        fixednodes1 = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)))';
        fixednodes2 = find(gsdata.IX(:,3)==max(gsdata.IX(:,3)))';
        fixeddofs = sort([6*fixednodes1-5,6*fixednodes1-4,6*fixednodes1-3,6*fixednodes1,...
                          6*fixednodes2-5,6*fixednodes2-4,6*fixednodes2]); %'ps': pinned-simply supported BCs: free axial translation, fixed transverse translation and angular twisting
        freedofs = setdiff(alldofs,fixeddofs);          
        loadnodes = 1:nnodes;
        nloadnodes = length(loadnodes);
    case 'beam_dist_load_ss' %suspended beam with distribuated loads
        fixednodes1 = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)))';
        fixednodes2 = find(gsdata.IX(:,3)==max(gsdata.IX(:,3)))';
        fixeddofs = sort([6*fixednodes1-5,6*fixednodes1-4,6*fixednodes1-3,6*fixednodes1,...
                          6*fixednodes2-5,6*fixednodes2-4,6*fixednodes2-3,6*fixednodes2]); %'pp': pinned-pinned BCs (fixed translation, fixed twisting, just free bending)
        freedofs = setdiff(alldofs,fixeddofs);          
        loadnodes = 1:nnodes;
        nloadnodes = length(loadnodes);
end
        
if nlc ==1 %Applying a single load case:
    F = sparse(ndofs,1);
    for in = 1:length(loadnodes)
        loaddofs = loadnodes(in)*6-6+indloaddof(1,:);
        F(loaddofs,1) = loadvalvec(1,indloaddof(1,:))/nloadnodes;
    end
    U = sparse(ndofs,1); %displacement vector for LC2
elseif nlc == 2
    F1 = sparse(ndofs,1);
    F2 = sparse(ndofs,1);
    %loading on the lower far side
    for in = 1:length(loadnodes)
        loaddofs1 = loadnodes(in)*6-6+indloaddof(1,:);
        F1(loaddofs1,1) = loadvalvec(1,indloaddof(1,:));
        loaddofs2 = loadnodes(in)*6-6+indloaddof(2,:);
        F2(loaddofs2,1) = loadvalvec(2,indloaddof(2,:));
    end
    U1 = sparse(ndofs,1); %displacement vector for LC1
    U2 = sparse(ndofs,1); %displacement vector for LC2
elseif nlc == 3
    F1 = sparse(ndofs,1);
    F2 = sparse(ndofs,1);
    F3 = sparse(ndofs,1);
    %loading on the lower far side
    for in = 1:length(loadnodes)
        loaddofs1 = loadnodes(in)*6-6+indloaddof(1,:);
        F1(loaddofs1,1) = loadvalvec(1,indloaddof(1,:));
        loaddofs2 = loadnodes(in)*6-6+indloaddof(2,:);
        F2(loaddofs2,1) = loadvalvec(2,indloaddof(2,:));
        loaddofs3 = loadnodes(in)*6-6+indloaddof(3,:);
        F3(loaddofs3,1) = loadvalvec(3,indloaddof(3,:));
    end
    U1 = sparse(ndofs,1); %displacement vector for LC1
    U2 = sparse(ndofs,1); %displacement vector for LC2
    U3 = sparse(ndofs,1); %displacement vector for LC3

end

%% Setting design variables and box constraints

%collecting nodes i and k only and attributing coordinates to each node
nvarnodes = 0;
switch StatCase
    case 'cantilever'
        for nn = 1:nnodes              
            if ~ismember(nn,[fixednodes,loadnodes]) &&  ~ismember(nn,gsdata.memconnect(:,2))
                nvarnodes = nvarnodes + 1;
            end
        end
    case 'beam_dist_load'
        for nn = 1:nnodes              
            if ~ismember(nn,fixednodes) &&  ~ismember(nn,gsdata.memconnect(:,2))
                nvarnodes = nvarnodes + 1;
            end
        end
    case 'beam_dist_load_ps'
        for nn = 1:nnodes              
            if ~ismember(nn,fixednodes1) && ~ismember(nn,fixednodes2) && ~ismember(nn,gsdata.memconnect(:,2))
                nvarnodes = nvarnodes + 1;
            end
        end     
   case 'beam_dist_load_ss'
        for nn = 1:nnodes              
            if ~ismember(nn,fixednodes1) && ~ismember(nn,fixednodes2) && ~ismember(nn,gsdata.memconnect(:,2))
                nvarnodes = nvarnodes + 1;
            end
        end             
end     
        

%box constraints for all members:
boxdiag = sqrt(dx^2+dy^2);
circr = min(dx,dy)/10;
Vtmp = 0;
theta0 = 0; %inclined angle of cpts positioning
px = zeros(npts,1); py = zeros(npts,1);
xmin = - ones(npts,1); xmax = ones(npts,1);
ymin = - ones(npts,1); ymax = ones(npts,1);
%Setting initial cross section shape as a circular cross section IAW with the volume fraction (a bit less than V*)
VstartRatio = 1; %initial volume to start with w.r.t. V* to calculate the initial shape
while Vtmp/Vstar < VstartRatio && (min(px) > min(xmin) || min(py) > min(ymin) || max(px) < max(xmax) || max(py) < max(ymax)) %|| Ainit<0.1*boxx*boxy

    [px,py,xmin,xmax,ymin,ymax] = CircCpts(npts,circr,theta0*pi/180,0,0,dx,dy,1e-6);
    [Lpinit,~,~,~] = contpolygon(px,py);    
    [~,~,~,~,~,~,Ainit,~,~] = ClosedUnclampedBspline([px;py],spord,dsc); %construction of B-spline
    Vtmp = Ainit*sum(gsdata.L);
    circr = 1.1*circr;
end

% fixedbounds = [min(xmin),max(xmax),min(ymin),max(ymax)];
figure;
plot(px,py,'o'); hold on;
plot([xmin;xmax],[py;py],'r+:'); plot([px;px],[ymin;ymax],'r+:'); pause(3);
svarnew_bar = (repmat([px,py],[1,nmem]))'; %list of crossectional PHYSICAL design variables in 1 column
varmin = (repmat([xmin,ymin],[1,nmem]))'; 
varmax = (repmat([xmax,ymax],[1,nmem]))';
nvar = length(svarnew_bar); % # of cross section variables 2 x # of control points x # of members
svarnew = (svarnew_bar - varmin)./(varmax - varmin); %vector of MATHEMATICAL design variables to be used in the optimization algorithm

%% Setting values of the optimization properties

%MMA parameters: cross section variables
nv = nvar; %# of varialbes
mc = 3;    %# of constraints
a0mma = 1;              % Constant
amma = zeros(mc,1);      % Constant
cmma = 1e3*ones(mc,1);  % Constant
dmma = zeros(mc,1);      % Constant
svarold1 = svarnew;       % Initial xold1;
svarold2 = svarnew;       % Initial xold2;
low = nan(nv,1);         % Initial lower asymptotes 
upp = nan(nv,1);         % Initial upper asymptotes
scaling = 0.05; %scaling value (usually good is: 1e-3 or 1e-2)
fcsmovemma = 0.1/(abs(Ainit/(dx*dy)))^0.5;   %external move limit proportional to bounding box size costheta_init
movemmavec = zeros(nvar,1);
updateratio_cs = 0.05;

%propertied for the cross section geometry regulation
pn1 = 8; %power of the pnorm summation for the side length constraint
pn2 = 8; %power of the pnorm summation for the control polygon's cosine angle constraint
Lepsi = 1e-4*boxdiag; %constraint over the lengths of the control polygon sides
AngLim = 1.0; %control polygon vertex angle limit: cos(theta)

%parameters for the rectifier function that ensures non negative cross section area
betaA = 1e-4*(dx*dy); %usually: 1e-4
A0 = 0; %This was once a min. cross section area threshold. This feature is in active for a single axial beam 

%initializing variables and starting optimization process
maxit = 150;
stopcseps = 1e-3; %consider change back to 5e-3;
changecs = 1;
changecsold = changecs;

%% Initializing variables
loop = 0;
g1col = zeros(maxit,1);
g2col = zeros(maxit,1);
g3col = zeros(maxit,1);
fcol = zeros(maxit,1);
changsizeecol = zeros(maxit,1);
mmainitcol = zeros(maxit,1);

%% Optimization loop
SampPts = 100; %discretization of the b-spline polynomials for live plotting
tstart = cputime;
figure;
fprintf('Optimization process started\n');
fprintf('V_f = %3.2f\n',volfrac);
while (loop < maxit)  && (changecs > stopcseps) %&& (changegs > stopgseps)
    tic
    %% Iteration initiation
    loop = loop + 1;
    if (changecsold > changecs) && (changecs > stopcseps)
        fcsmovemma  = fcsmovemma*(1-updateratio_cs);
    end
    clf; 
    varnum = 1;
    dg = zeros(nvar,1);
    dgLm = zeros(nvar,1);
    dgangm = zeros(nvar,1);
    Lp = ones(nmem*npts,1)*mean(Lpinit);
    costhetap1 = zeros(nmem*npts,1);
    V = 0;

    %% Physical design update shape and stiffness calculations

    svarnew_bar = varmin + svarnew.*(varmax - varmin); % x_bar of x - relation between mathematical and physical variables    

    %plotting the physical domain box
    mincorner = [-dx/2,-dy/2,-dz/2];
    maxcorner = [dx/2,dy/2,dz/2];
    DomainPlot(mincorner,maxcorner);

    %design update to each beam member: shape and stiffness, global volume
    %summation and move limit adaptation including realtime visualization and
    %reporting
    for nm = 1:nmem
        membersg{nm}.px = svarnew_bar(2*npts*(nm-1)+1:npts*(2*nm-1));
        membersg{nm}.py = svarnew_bar(npts*(2*nm-1)+1:2*npts*nm);

        %calculation of the cross section geometric boundary using b-spline
        [membersg{nm}.sp,membersg{nm}.N,membersg{nm}.dN,xi0,xi1,~,membersg{nm}.A,membersg{nm}.S,membersg{nm}.I] = ClosedUnclampedBspline([membersg{nm}.px,membersg{nm}.py]',spord,dsc); %construction of B-spline
        %calculation of the rectified cross section area to ensure non negative area
        if membersg{nm}.A/betaA > 400 %eliminating large numbers truncation issues
            membersg{nm}.Ar = membersg{nm}.A;
            membersg{nm}.dArdA = 1;
        else
            membersg{nm}.Ar = 1e-6 + betaA*log(1 + exp((membersg{nm}.A)/betaA));
            membersg{nm}.dArdA = exp((membersg{nm}.A-A0)/betaA)/(1 + exp((membersg{nm}.A)/betaA));           
        end
        
        %constrution of the cross section boundary
        membersg{nm}.dxi = linspace(xi0,xi1,dsc);
        membersg{nm}.Cs = membersg{nm}.N'*[membersg{nm}.px',membersg{nm}.px(1:spord)';membersg{nm}.py',membersg{nm}.py(1:spord)']'; %Bspline explicit parametric curve
        membersg{nm}.dCs = membersg{nm}.dN'*[membersg{nm}.px',membersg{nm}.px(1:spord)';membersg{nm}.py',membersg{nm}.py(1:spord)']'; %Bderivative of the spline explicit parametric curve
        
        %construction of the 2D FE mesh and physical cross section identification

        minbound = min([min(membersg{nm}.px),max(membersg{nm}.px),min(membersg{nm}.py),max(membersg{nm}.py)]);
        maxbound = max([min(membersg{nm}.px),max(membersg{nm}.px),min(membersg{nm}.py),max(membersg{nm}.py)]);
        membersg{nm}.polybounds = [minbound,maxbound,minbound,maxbound];


        [membersg{nm}.eldata.elconnect,membersg{nm}.eldata.nx,membersg{nm}.eldata.ny] = BuildFixedGrid(membersg{nm}.polybounds,nelx,nely); %building fixed grid inside the boundaries of the polygon
        membersg{nm}.eldata.nelx = nelx; membersg{nm}.eldata.nely = nely;
        membersg{nm}.eldata.nnodes = length(membersg{nm}.eldata.nx);
        membersg{nm}.eldata.nel = membersg{nm}.eldata.nelx*membersg{nm}.eldata.nely;
        
        %calculation properties of the cross section on the 2D FE mesh
        [membersg{nm}.eldata.in,membersg{nm}.eldata.on] = inpoly([membersg{nm}.eldata.nx,membersg{nm}.eldata.ny],[membersg{nm}.Cs(:,1),membersg{nm}.Cs(:,2)]); %identification of cross section internal and external nodes
        membersg{nm}.eldata = eldensity(membersg{nm}.eldata,membersg{nm}.N,membersg{nm}.dN,membersg{nm}.Cs,membersg{nm}.dCs,membersg{nm}.dxi); %calculation  of the FEs densities
        
        %Calculation of the cross section structural properties using BECAS: Ks, utils, csSol and all required submatrices
        [membersg{nm}.utils,membersg{nm}.Ks,membersg{nm}.csSol,membersg{nm}.submats] = BECAS_BeamConstitutiveCalculation(E,nu,membersg{nm}.eldata);       
        %preparing the physical penalization factor
        membersg{nm}.KbLoc =  BeamGaussInteg(membersg{nm}.Ks,membersg{nm}.L,nGp); %FE intergration along the beam (quadratic shape functions)

        V = V + membersg{nm}.L*membersg{nm}.Ar; %physical volume calculation with penalization over non-physical geometry ('negative' cross section)

        % Realtime reporting: plotting to screen
        RealTimePlot(membersg,nm,SampPts);

        %updating MMA solver external move limit to fit the size of the cross section
        movemmavec(2*npts*(nm-1)+1:npts*(2*nm-1)) = fcsmovemma*(abs(membersg{nm}.A/(dx*dy))).^0.5;
        movemmavec(npts*(2*nm-1)+1:2*npts*nm) = fcsmovemma*(abs(membersg{nm}.A/(dx*dy))).^0.5;

    end

    %% calculating global stiffness and compliance functional

    K = StiffAssembly(membersg,gsdata); %global stiffness assembly of all members
    if nlc==1 %single load case
        U(freedofs,1) = K(freedofs,freedofs)\F(freedofs,1); %#ok<*SPRIX>
    elseif nlc==2  %two load cases
        U1(freedofs,1) = K(freedofs,freedofs)\F1(freedofs,1); %#ok<*SPRIX>
        U2(freedofs,1) = K(freedofs,freedofs)\F2(freedofs,1);
    elseif nlc == 3 %three load cases
        U1(freedofs,1) = K(freedofs,freedofs)\F1(freedofs,1); %#ok<*SPRIX>
        U2(freedofs,1) = K(freedofs,freedofs)\F2(freedofs,1);
        U3(freedofs,1) = K(freedofs,freedofs)\F3(freedofs,1);
    end
    %calculating compliance functional
    if nlc==1
        f = full(F'*U);
    elseif nlc==2       
        f = full(weight(1)*F1'*U1 + weight(2)*F2'*U2); %weighted compliance of all 3 load cases
    elseif nlc == 3
        f = full(weight(1)*F1'*U1 + weight(2)*F2'*U2 + weight(3)*F2'*U3); %weighted compliance of all 3 load cases
    end

    fcol(loop) = f; %comulative compliance
    g1col(loop) = V; %comulative volume

    %% Sensitivity analysis of all response functionals and calculation of geometrical constraints
   
    df = zeros(nvar,1);
    %stiffness derivatives calculation w.r.t. cross section stiffness
    for nm = 1:nmem
        %derivatives calculation: the constitutive properties w.r.t density and the density of each element w.r.t. design variables
        membersg{nm}.dA = CrossecSens([membersg{nm}.px';membersg{nm}.py'],spord,membersg{nm}.N,membersg{nm}.dN); %dA/dx
        dKs = BECAS_dKs(membersg{nm}.utils,membersg{nm}.Ks,membersg{nm}.csSol,membersg{nm}.submats); %dKs/drhoe derivatives of the beam stiffness w.r.t. density of each element       
        drhoe = DensSens(membersg{nm}.eldata,membersg{nm}.N,spord); %drhoe/dx - derivatives of the density w.r.t. c.p. coordinates                
        membersg{nm}.dAr = membersg{nm}.dArdA*membersg{nm}.dA; %dAr/dA*dA/dx
        %identifying the active dofs for later assembly of the global stiffness matrix derivatives
        actnodes = gsdata.memconnect(nm,:);
        actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
                   actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
                   actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];        
    
        %calculating stiffness, volume and compliance derivatives
        for ip = 1:2*npts
            dKcsloc = zeros(18);
            for e = 1:membersg{nm}.eldata.nel
                dKbdrhoe = zeros(18);
                if drhoe(e,ip) ~= 0 %only to those elements that are crossed by the cross section boundary of non zero derivatives
                    dKbdrhoe =  BeamGaussInteg(dKs(:,:,e),membersg{nm}.L,nGp);
                end
                %applying chain rule: dKb_bar/ds = dKb/drho*drho/ds - where s is the c.pt coordinate variable indexed: ip.
                dKcsloc = dKcsloc + dKbdrhoe*drhoe(e,ip);
            end
            
            if nlc == 1
                df(varnum) =  - (varmax(varnum) - varmin(varnum))*U(actdofs)'*dKcsloc*U(actdofs);
            elseif nlc== 2                
                df(varnum) =  - (varmax(varnum) - varmin(varnum))*(weight(1)*U1(actdofs)'*dKcsloc*U1(actdofs) + weight(2)*U2(actdofs)'*dKcsloc(actdofs,actdofs)*U2(actdofs) );
            elseif nlc ==3
                df(varnum) =  - (varmax(varnum) - varmin(varnum))*(weight(1)*U1(actdofs)'*dKcsloc*U1(actdofs) + weight(2)*U2(actdofs)'*dKcsloc(actdofs,actdofs)*U2(actdofs) + weight(3)*U3(actdofs)'*dKcsloc(actdofs,actdofs)*U3(actdofs) );                            
            end
            varnum = varnum + 1;
        end        
        
        %volume constraint derivatives calculation w.r.t. cross section design variabels
        dsvar_tmp1 = varmax(2*npts*(nm-1)+1:npts*(2*nm-1)) - varmin(2*npts*(nm-1)+1:npts*(2*nm-1));
        dsvar_tmp2 = varmax(  npts*(2*nm-1)+1:2*npts*nm  ) - varmin(  npts*(2*nm-1)+1:2*npts*nm  );
        dg(2*npts*(nm-1)+1:npts*(2*nm-1)) = dsvar_tmp1.*membersg{nm}.L.*membersg{nm}.dAr(1:npts);
        dg(npts*(2*nm-1)+1:2*npts*nm)     = dsvar_tmp2.*membersg{nm}.L.*membersg{nm}.dAr(npts+1:2*npts);
        
        %calculating control polygon properties to include in geometrical constraints
        if (membersg{nm}.Ar>A0) %&& ismember(nm,desmembers)
            %calculation of the polygon side length and the polygon angle cosines
            [Lp((nm-1)*npts+1:nm*npts),costhetap1((nm-1)*npts+1:nm*npts),dLp,dcosthetap1] = contpolygon(membersg{nm}.px',membersg{nm}.py');
            Lp1 = Lp((nm-1)*npts+1:nm*npts); %Li
            Lp2 = [Lp1(2:end);Lp1(1)]; %Li+1
            Lp1dLpdLx = Lp1.^(-pn1-1).*diag(dLp(:,1:npts)); %dLi^(p-1)*dLi/dxi
            Lp1dLpdLy = Lp1.^(-pn1-1).*diag(dLp(:,npts+1:2*npts)); %dLi^(p-1)*dLi/dyi
            Lp2dLpdLx = Lp2.^(-pn1-1).*[-diag(dLp(2:npts,2:npts));-dLp(1,1)]; %dLi+1^(p-1)*dLi+1/dxi
            Lp2dLpdLy = Lp2.^(-pn1-1).*[-diag(dLp(2:npts,npts+2:2*npts));-dLp(1,npts+1)]; %dLi+1^(p-1)*dLi+1/dyi
            %summing and placing the derivatives of the geometrical constraints in a design-variable-wise order
            dgLm(2*npts*(nm-1)+1:npts*(2*nm-1)) = Lp1dLpdLx + Lp2dLpdLx; %(dLi^(p-1)*dLi/dxi + dLi+1^(p-1)*dLi+1/dxi
            dgLm(npts*(2*nm-1)+1:2*npts*nm) = Lp1dLpdLy + Lp2dLpdLy; %(dLi^(p-1)*dLi/dyi + dLi+1^(p-1)*dLi+1/dyi
            dgangm(2*npts*(nm-1)+1:npts*(2*nm-1)) = sum((costhetap1((nm-1)*npts+1:nm*npts).^(pn2-1)).*dcosthetap1(:,1:npts));
            dgangm(npts*(2*nm-1)+1:2*npts*nm) = sum((costhetap1((nm-1)*npts+1:nm*npts).^(pn2-1)).*dcosthetap1(:,1+npts:2*npts));
        else 
            Lp((nm-1)*npts+1:nm*npts) = ones(npts,1)*Lepsi*100;
            dgLm(2*npts*(nm-1)+1:npts*(2*nm-1)) = ones(npts,1)*1e-6;
            dgLm(npts*(2*nm-1)+1:2*npts*nm) = ones(npts,1)*1e-6;
            dgangm(2*npts*(nm-1)+1:npts*(2*nm-1)) = ones(1,npts)*1e-6;
            dgangm(npts*(2*nm-1)+1:2*npts*nm) = ones(1,npts)*1e-6;
        end                       
            membersg{nm}.Lp = Lp((nm-1)*npts+1:nm*npts);
            membersg{nm}.costheta = costhetap1((nm-1)*npts+1:nm*npts) - 1; 
    end
    %geometrical constraint aggregation
    gL  = sum(Lp.^-pn1).^(1/pn1);  %p-norm summation of all polygon side lengths
    dgL = -sum((Lp).^(-pn1)).^(1/pn1-1).*dgLm.*(varmax(1:nvar)-varmin(1:nvar)); %derivatives of the min. polygon side length constraints
    gang = sum(costhetap1.^pn2)^(1/pn2)-1; %smooth max cosine angles
    dgang = sum(costhetap1.^pn2).^(1/pn2-1).*dgangm.*(varmax(1:nvar)-varmin(1:nvar)); %derivatives of the smoothed max. cosine angles
    g2col(loop) = gL; %comulative minimum polygon side length
    g3col(loop) = gang; % comulative max. cosine angle

 %% updating design with MMA
    
    svarval = svarnew;
    svarminmma(1:nvar,1) = max(zeros(nvar,1),svarval(1:nvar,1)-movemmavec(1:nvar));
    svarmaxmma(1:nvar,1) = min( ones(nvar,1),svarval(1:nvar,1)+movemmavec(1:nvar));
    fscale = scaling/fcol(1); %scaling factor of the objective wrt 1st iteration value
    fscl = f*fscale; %scaling objective
    fval = [V/Vstar - 1,gL*Lepsi-1,gang/AngLim - 1]';
    dfdx1 = dg(:)/Vstar;
    dfdx1(nvar+1:end) = [];
    dfdx2 = zeros(nvar,1); dfdx2(1:nvar) = dgL*Lepsi;
    dfdx3 = zeros(nvar,1); dfdx3(1:nvar) = dgang/AngLim;
    dfdx = [dfdx1,dfdx2,dfdx3]';
    df = fscale*df; %scaling sensitivites    
    %calling the mma subproblem and updating design: 
    [svarnew,~,~,~,~,~,~,~,~,low,upp,mmainit] = mmasub(mc,nv,loop,svarval,svarminmma,svarmaxmma,svarold1,svarold2,fscl,df,fval,dfdx,low,upp,a0mma,amma,cmma,dmma);
    mmainitcol(loop) = mmainit;
    svarold2 = svarold1;
    svarold1 = svarval;
    changecs = max(max(abs(svarnew(1:nvar)-svarval(1:nvar))));
    changsizeecol(loop) = changecs; % changegs = 1e-6;
    fprintf('chg.cs: %5.4f, init: %2i, loop: %2i, obj: %4.3e, V/V*: %3.3f, min(Lp)/Lp_min: %2.2f, max(cos(th)): %2.2f\n',changecs,mmainit,loop,f,V/Vstar,min(Lp)/Lepsi,max(costhetap1)-1);
        
end %%%%%%%%%%%%%%%%%%%%%%%%%%%%end of optimization loop%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tend = cputime - tstart;
if changecs <= stopcseps %&& changegs <= stopgseps
    fprintf('Optimization terminated with convergence. Elapsed time: %4.1f sec\n',tend);
else
    fprintf('Optimization terminated when reached max. iterataions. Elapsed time: %4.1f sec\n',tend);
end

% CompFinalCalc;

fcol(loop+1:end) = [];
g1col(loop+1:end) = [];
g2col(loop+1:end) = [];
g3col(loop+1:end) = [];
mmainitcol(loop+1:end) = [];
changsizeecol(loop+1:end) = [];
figure;
subplot(3,2,1); plot(fcol);
xlabel('it #'); ylabel('obj.');
subplot(3,2,2); plot(g1col./(dx*dy*dz)); xlabel('it #'); ylabel('vol. frac. const.'); %legend('calc.','reaval.','Location','NorthEast');
subplot(3,2,3); plot(1./(Lepsi*g2col)); xlabel('it #'); ylabel('min(Lp)/Lp,lim');
subplot(3,2,4); plot(g3col); xlabel('it #'); ylabel('max. cos({\theta_i})');
subplot(3,2,5); plot(mmainitcol); xlabel('it #'); ylabel('MMA int. it.');
subplot(3,2,6); plot(changsizeecol); xlabel('it #'); ylabel('change diff'); legend('size','shape');

save('opt_data','fcol','g1col','g2col','g3col','changsizeecol','mmainitcol','svarnew','membersg');

end

%% Internal functions:

function data = beamconstruct(dz,nmem)

data.nnodes = 2*nmem + 1;
data.nmem = nmem;
data.IX = zeros(data.nnodes,3);
gapz = dz/nmem;
data.IX(1:nmem+1,3) = linspace(-dz/2,dz/2,nmem+1);
data.IX(nmem+2:end,3) = linspace(-dz/2+gapz/2,dz/2-gapz/2,nmem);
ii = 1:nmem;
jj = nmem+2:data.nnodes;
kk = 2:nmem+1;
data.memconnect = [ii',jj',kk']; 
nnz = 0;
for m = 1:nmem    
    actnodes = data.memconnect(m,:);
    actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
               actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
               actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];
    data.Srow(nnz+1:nnz+324,1) = reshape(repmat(actdofs,1,18),324,1);
    data.Scol(nnz+1:nnz+324,1) = reshape(repmat(actdofs,18,1),324,1);
    nnz = nnz + 324;    
    Lx = data.IX(kk(m),1) - data.IX(ii(m),1); %ith member X dir. projection
    Ly = data.IX(kk(m),2) - data.IX(ii(m),2); %ith member Y dir. projection
    Lz = data.IX(kk(m),3) - data.IX(ii(m),3); %ith member Z dir. projection
    data.L(m) = (Lx^2+Ly^2+Lz^2)^0.5; %ith member length
    data.Cx(m) = Lx/data.L(m); %ith member cosines - x dir.
    data.Cy(m) = Ly/data.L(m); %ith member cosines - y dir.
    data.Cz(m) = Lz/data.L(m); %ith member cosine - z dir.
    
end

end

function [xx,yy,xxmin,xxmax,yymin,yymax] = CircCpts(np,r,theta0,cx,cy,boxx,boxy,lim)

%construction of the bspline control points scaffold in a circular pattern
%and setting physical box constraints for each control point coordinate
%
%inputs:
% np - number of control points
% r  - radius distance of the control points positions (not exactly the circular curve radius)
% theta0 - tilt angle of the first contorl points w.r.t. the vertical axis.
% cx,cy - coordinates of the center of the circle
% boxx, boxy - box constraints of the physical design domain.
% lim - limitation of the control points allowed positions near the axes.
%
% outputs:
% xx,yy - coordinates of the control points
% xxmin, yymin - individual minimum allowed bounds of each control point
% xxmax, yymax - individual maximum allowed bounds of each control point

theta = linspace(theta0,2*pi+theta0,np+1);
dtheta = theta(2) - theta(1);

xlb = cx - boxx/2;
xub = cx + boxx/2;
ylb = cy - boxy/2;
yub = cy + boxy/2;

xx = cx + r*cos(theta(1:end-1)+dtheta/2);
yy = cy + r*sin(theta(1:end-1)+dtheta/2);

deltax = boxx;
deltay = boxy;
xxmin(xx>0) = max(xx(xx>0)-deltax,lim);
xxmax(xx>0) = min(xx(xx>0)+deltax,xub);
xxmin(xx<0) = max(xx(xx<0)-deltax,xlb);
xxmax(xx<0) = min(xx(xx<0)+deltax,-lim);
yymin(yy>0) = max(yy(yy>0)-deltay,lim);
yymax(yy>0) = min(yy(yy>0)+deltay,yub);
yymin(yy<0) = max(yy(yy<0)-deltay,ylb);
yymax(yy<0) = min(yy(yy<0)+deltay,-lim);

end

function [sp,N,dN,xi0,xi1,kntscoor,A,C,I] = ClosedUnclampedBspline(P,p,desc)
% Generates a Counterclockwise closed spline using control points.
%inputs: 'P' control points - 2 rows vector of the clamping polygon
%        'p' order - B-spline plynomials order
%        'xi0,xi1' bounding spline knots parameters
%        properties of the area calculated utilizing Green's theorem
%        'A' area 
%        'C' centroid of the area [x,y]
%        'I' inertia tensor w.r.t. centroid: [Ixx,Ixy, 0 ...
%                                             Ixy,Iyy, 0 ; 
%                                               0 , 0 ,Jzz]
%
%
sp = 1;
P = [P, P(:,1: p )]; %repeating the first n control points to create a closed curve
n = length(P); % order of B-spline
m = n + p; %order of knots span vector
Xi = 1:m; % knots span vector
xi0 = p; %lower integration limit
xi1 = n; %upper integratio limit
xi = linspace(xi0,xi1,desc); %xi the parametric variable of the B-spline
% dxi = xi(2) - xi(1); %parametric differential of the B-spline
% sp = spmak(Xi,P);
% Ns = spmak(Xi,eye(length(P))); %B-spline basis functions - symbolic functional form
% N = fnval(Ns,xi); %B-spline bassis functions - explicit form
% dNs = fnder(Ns); %derivative: dN/dxi of the basis functions - symbolic functional form
% dN = fnval(dNs,xi); %derivative dN/dxi of the basis functions - explicit form
[N,dN] = bspline_base_and_deriv(p,Xi,xi,desc);
xx = N'*P(1,:)'; %explicit x(xi) cooridnate
yy = N'*P(2,:)'; %explicit y(xi) cooridnate
dxx = dN'*P(1,:)'; %derivative: dx/dxi = sigma(dN/dxi*P(1)) = [dN/dxi]^T*P(1)
dyy = dN'*P(2,:)'; %derivative: dy/dxi = sigma(dN/dxi*P(2)) = [dN/dxi]^T*P(2)

%finding the coordinates of the knots
knotind = zeros(1,n-p+1);
for ix = xi0:xi1
    knotind(ix-xi0+1) = find(xi>=Xi(ix),1,'first');
end
knotind(end) = knotind(1);
kntscoor = [xx(knotind),yy(knotind)];
%explicit formulation of the cross section properties in the closed spline
%using Green's therorem IAW prof. Elber's paper

% A = 0.5*trapz((xx.*dyy - yy.*dxx).*dxi); %cross section area
% Sx = -0.5*trapz((yy.^2.*dxx)*dxi);
% Sy = 0.5*trapz((xx.^2.*dyy)*dxi);

A = 0.5*trapz(xi,(xx.*dyy - yy.*dxx)); %cross section area
Sx = -0.5*trapz(xi,(yy.^2.*dxx));
Sy = 0.5*trapz(xi,(xx.^2.*dyy));


Cx = Sy/A;
Cy = Sx/A;
C = [Cx,Cy]; %centroid of the area

Ixx = -1/3*trapz(xi,(yy.^3.*dxx));
Iyy =  1/3*trapz(xi,(xx.^3.*dyy));
Ixy = -0.5*trapz(xi,(xx.*yy.^2.*dxx));
Iyx = 0.5*trapz(xi,(xx.^2.*yy.*dyy));


% Ixx = -1/3*trapz((yy.^3.*dxx)*dxi) - A*Cy^2;
% Iyy =  1/3*trapz((xx.^3.*dyy)*dxi) - A*Cx^2;
% Ixy = -0.5*trapz((xx.*yy.^2.*dxx)*dxi) - A*Cx*Cy;
% Iyx = 0.5*trapz((xx.^2.*yy.*dyy)*dxi) - A*Cy*Cx;
Jzz = Ixx+Iyy;
I = [Ixx,Ixy, 0 ;...
     Iyx,Iyy, 0 ;...
      0 , 0 ,Jzz];
end

function [econnect, nx,ny] = BuildFixedGrid(boundingbox,nelx,nely)

%subroutine that creats a fixed grid mesh
%input:
%       cx, cy - origin coordinates of the grid
%       dx, dy - size of grid
%       res - resolution number: number of elements in the x direction
%output:
%       nx, ny - coordinates of the indexed node ordered coloumnwise

% x = linspace(cx - dx/2, cx + dx/2,nelx+1);
% y = linspace(cy - dy/2, cy + dy/2,nely+1);
x = linspace(boundingbox(1), boundingbox(2),nelx+1);
y = linspace(boundingbox(3), boundingbox(4),nely+1);

[nx,ny] = meshgrid(x,y);
nx = nx(:); %indexed node x coordinates
ny = ny(:); %indexed node y coordinates
%building connectivity matrix: attributing each element to its 4 nodes (Q4
%1st order elements)
nodenrs = reshape(1:(1+nelx)*(1+nely),1+nely,1+nelx); %nodes map on the mesh grid
k = 0;
econnect = zeros(nelx*nely,4);
for nnx = 1:nelx
    for nny = 1:nely
        k = k + 1;
        econnect(k,1) = nodenrs(nny,nnx);
        econnect(k,2) = nodenrs(nny,nnx+1);
        econnect(k,3) = nodenrs(nny+1,nnx+1);
        econnect(k,4) = nodenrs(nny+1,nnx);
    end
end
end

function K = StiffAssembly(membersg,gsdata)

%stiffness matrix assembly for the ground structure case
nnodes = length(gsdata.IX(:,1));
ndofs = 6*nnodes; 

nnz = 0;

for m = 1:gsdata.nmem
%     Ke = membersg{m}.Rt'*membersg{m}.Kb*membersg{m}.Rt;
    Sval(nnz+1:nnz+324,1) = membersg{m}.KbLoc(:);
    nnz = nnz + 324;
end
K = sparse(gsdata.Srow,gsdata.Scol,Sval,ndofs,ndofs);

end

function DomainPlot(mincor,maxcor)

xminlim = mincor(1);
yminlim = mincor(2);
zminlim = mincor(3);
xmaxlim = maxcor(1);
ymaxlim = maxcor(2);
zmaxlim = maxcor(3);


plot3([zminlim,zmaxlim,zmaxlim,zminlim,zminlim],xminlim*ones(1,5),[yminlim,yminlim,ymaxlim,ymaxlim,yminlim],'k--'); hold on; axis equal; axis off;
plot3([zminlim,zmaxlim,zmaxlim,zminlim,zminlim],xmaxlim*ones(1,5),[yminlim,yminlim,ymaxlim,ymaxlim,yminlim],'k--');
plot3([zminlim,zminlim],[xminlim,xmaxlim],[yminlim,yminlim],'k--');
plot3([zminlim,zminlim],[xminlim,xmaxlim],[ymaxlim,ymaxlim],'k--');
plot3([zmaxlim,zmaxlim],[xminlim,xmaxlim],[yminlim,yminlim],'k--');
plot3([zmaxlim,zmaxlim],[xminlim,xmaxlim],[ymaxlim,ymaxlim],'k--');
% xlabel('z'); ylabel('x'); zlabel('y');
% physdomain = [xminlim,yminlim,zminlim;xmaxlim,yminlim,zminlim;xmaxlim,ymaxlim,zminlim;xminlim,ymaxlim,zminlim;...
% xminlim,yminlim,zmaxlim;xmaxlim,yminlim,zmaxlim;xmaxlim,ymaxlim,zmaxlim;xminlim,ymaxlim,zmaxlim];
end



function membersg = RealTimePlot(membersg,nm,SampPts)

        %reporting and exporting: local to global frame: Pglobal = R^T*Plocal
        npts = length(membersg{nm}.px);
        membersg{nm}.PtsLocal = [membersg{nm}.Cs(1:length(membersg{nm}.Cs)/SampPts:end,1), membersg{nm}.Cs(1:length(membersg{nm}.Cs)/SampPts:end,2),zeros(SampPts,1)/2]; %exoort sampling curve points in local coordinates
        membersg{nm}.ExpPts2Cad = (membersg{nm}.Rt(1:3,1:3)'*membersg{nm}.PtsLocal'+repmat(membersg{nm}.IX(2,:),[SampPts,1])')';  
        membersg{nm}.Cpts2Cad = membersg{nm}.Rt(1:3,1:3)'*[membersg{nm}.px';membersg{nm}.py';zeros(1,npts)] + repmat(membersg{nm}.IX(2,:),[npts,1])';
        membersg{nm}.ExpPts2Cad(end+1,:) = membersg{nm}.ExpPts2Cad(1,:);
        EdgeMemPoints1 = (membersg{nm}.Rt(1:3,1:3)'*membersg{nm}.PtsLocal'+repmat(membersg{nm}.IX(1,:),[SampPts,1])')';
        EdgeMemPoints2 = (membersg{nm}.Rt(1:3,1:3)'*membersg{nm}.PtsLocal'+repmat(membersg{nm}.IX(3,:),[SampPts,1])')';
        tmpx = [EdgeMemPoints1(:,1),EdgeMemPoints2(:,1)];
        tmpy = [EdgeMemPoints1(:,2),EdgeMemPoints2(:,2)];
        tmpz = [EdgeMemPoints1(:,3),EdgeMemPoints2(:,3)];
        %plotting nodes
%         plot3(membersg{nm}.IX(:,3),membersg{nm}.IX(:,1),membersg{nm}.IX(:,2),'k.');
%         hold on; axis equal; axis off; view([45,20]);
%         %ploting structurally participating membres
% %         hp1 = plot3([membersg{nm}.IX(1,3),membersg{nm}.IX(3,3)],...
% %             [membersg{nm}.IX(1,1),membersg{nm}.IX(3,1)],...
% %             [membersg{nm}.IX(1,2),membersg{nm}.IX(3,2)]);
% %         hp1.LineWidth = 1.2;
        plot3([EdgeMemPoints1(:,3);EdgeMemPoints1(1,3)],[EdgeMemPoints1(:,1);EdgeMemPoints1(1,1)],[EdgeMemPoints1(:,2);EdgeMemPoints1(1,2)],'k','LineWidth',1.0);
        hold on; axis equal; axis off; view([45,20]);

%         hp2.Color = [0,0,0];
%         hp2.LineWidth = 1.0;
        plot3([EdgeMemPoints2(:,3);EdgeMemPoints2(1,3)],[EdgeMemPoints2(:,1);EdgeMemPoints2(1,1)],[EdgeMemPoints2(:,2);EdgeMemPoints2(1,2)],'k','LineWidth',1.0);
%         hp3.Color = [0,0,0];
%         hp3.LineWidth = 1.0;
%         stlfilename = [];
        fv = WatertightStlWrite([],tmpx(:),tmpy(:),tmpz(:),membersg{nm}.Rt(1:3,1:3),'binary');
        hp4 = patch('faces',fv.faces,'vertices',[fv.vertices(:,3),fv.vertices(:,1),fv.vertices(:,2)]);
        hp4.FaceAlpha = 1;%hp4.FaceColor = [0,0,1];
        hp4.FaceColor = [0.875,0.875,0.875]; hp4.EdgeColor = 'none';
        view([45,20]);
        drawnow;
end
