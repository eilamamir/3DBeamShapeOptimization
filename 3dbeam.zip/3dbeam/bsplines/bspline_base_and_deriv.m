function [N,dN] = bspline_base_and_deriv(p,Xi,xi,res)
%numerical calculation of b-spline function for the given parameters:
% p - polynomial order: 2-linear,3-quadratic,4-cubic,etc...
% Xi - knot span of the bspline
% xi - parametric variable
% res - numerical resolution

n = numel(Xi)-p; %number of control points - i.e. number of basis functions
N = zeros(n,res);
dN = zeros(n,res);

for ii = 1:n-1
    N(ii,:) = bspline_basis_res(ii-1,p,Xi,xi,res);
    Nt1 = bspline_basis_res(ii-1,p-1,Xi,xi,res);
    Nt2 = bspline_basis_res(ii,p-1,Xi,xi,res);
    p1 = p/(Xi(ii+p)-Xi(ii));
    p2 = p/(Xi(ii+p+1)-Xi(ii+1));
    dN(ii,:)= p1*Nt1-p2*Nt2;
end
N(n,:) = bspline_basis_res(n-1,p,Xi,xi,res);

end