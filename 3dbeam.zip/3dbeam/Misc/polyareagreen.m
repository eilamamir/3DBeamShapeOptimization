function A = polyareagreen(x,y)

%calculate any polygon area using Green's theorem, implemented via the
%'shoelace' method.

x = [x,x(1)];
y = [y,y(1)];

x0 = x(1:end-1);
y0 = y(1:end-1);
x1 = x(2:end);
y1 = y(2:end);
A = 0.5*sum(x0.*y1 - x1.*y0);

end
