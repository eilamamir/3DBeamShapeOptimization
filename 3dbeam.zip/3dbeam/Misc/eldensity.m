function eldata = eldensity(eldata,N,dN,Cs,dCs,xi)

%This function calculates the relative density of each element, based on
%the classification of the fixed grid.
% At first, it recognizes the elements either with one or zero density
% (cases 1 and 14 respectively) by identifying the elements that are fully
% inside or outside the closed boundary respectively.
%
%Secondly, each of the intermediate elements crossed by the bspline- boundary
% are classified IAW the 12 topological cases. Then, for these elements the
% position of the intersections are identified: tin and tout.
%
% Thirdly, performing the calculation of the relative 'filled' area: Ar
% using Green's theorem. Finally the relative density is obtained by:
% relrho = Ar/Ae

%elements topological classification.
eldata.elclasses = [0,0,0,0;...
                    0,1,1,1;...
                    1,0,1,1;...
                    1,1,0,1;...
                    1,1,1,0;...
                    0,0,1,1;...
                    1,0,0,1;...
                    1,1,0,0;...
                    0,1,1,0;...
                    1,0,0,0;...
                    0,1,0,0;...
                    0,0,1,0;...
                    0,0,0,1;...
                    1,1,1,1];

% figure; %to be commented
eldata.eltopclass = zeros(eldata.nel,1);
for e = 1:eldata.nel
    eclass = zeros(1,4);
    ncheck = eldata.elconnect(e,:); %current element nodes
%     plot([eldata.nx(ncheck);eldata.nx(ncheck(1))],[eldata.ny(ncheck);eldata.ny(ncheck(1))],'-o'); axis equal; hold on;
    eclass(eldata.in(ncheck)) = 1; %cecking which nodes are in/out of the cross section for the current element
    for cl = 1:length(eldata.elclasses(:,1))
        if eclass == eldata.elclasses(cl,:)
            eldata.eltopclass(e) = cl; %classification of each element to which of the 14 cases it belongs
        end
    end
    
end

%[eldata.darce{e}(:,2),-eldata.darce{e}(:,1)]./sqrt(eldata.darce{e}(:,1).^2 + eldata.darce{e}(:,2).^2);
eldata.normal = [dCs(:,2),-dCs(:,1)]./sqrt(dCs(:,1).^2 + dCs(:,2).^2);

eldata.tin = zeros(eldata.nel,2);
eldata.tout = zeros(eldata.nel,2);
eldata.rhoe = zeros(eldata.nel,1);
for e = 1:eldata.nel
    
    elncorrds = [eldata.nx(eldata.elconnect(e,:)),eldata.ny(eldata.elconnect(e,:))];
    x1 = elncorrds(1,1); y1 =  elncorrds(1,2);
    x2 = elncorrds(2,1); y2 =  elncorrds(2,2);
    x3 = elncorrds(3,1); y3 =  elncorrds(3,2);
    x4 = elncorrds(4,1); y4 =  elncorrds(4,2);
    Ae = (x2 - x1)*(y4 - y1);
    eldata.Ae = Ae;
%     plot([x1,x2,x3,x4,x1],[y1,y2,y3,y4,y1],'o-'); axis equal; hold on
    if eldata.eltopclass(e) == 14 %case 13 - all nodes inside the closed b-spline
        eldata.rhoe(e) = 1;  
    elseif eldata.eltopclass(e) > 1 && eldata.eltopclass(e) < 14 %intermediate density elements
        indarc = find(Cs(:,1)>= x1 & Cs(:,1) <= x3 & Cs(:,2) >= y1 & Cs(:,2) <= y3); 
        dindarc = find(diff(indarc) == max(diff(indarc)));
        %locating the place of the bspline end and start points. Then reordering
        %the arc such that it will start and end piecewisely.
        if length(dindarc) == 1 && max(diff(indarc))/length(Cs(:,1))>0.9
            indarc = [indarc(dindarc+1:end);indarc(1:dindarc)];
        end      
        arc = Cs(indarc,:);
        darc = dCs(indarc,:);
        Narc = N(:,indarc);
        dNarc = dN(:,indarc);
        arcxi = xi(indarc);
        if length(arc(:,1)) >= 1
            eldata.arce{e} = arc;
            eldata.darce{e} = darc;
            eldata.arcxi{e} = arcxi;
            eldata.Narc{e} = Narc;
            eldata.dNarc{e} = dNarc;
            eldata.indarc{e} = indarc;
            
            if eldata.eltopclass(e) == 2 %nodes topology case #1
                %closed loop order: curved arc -> nodes 2,3,4
                xr = [arc(:,1)',x2,x3,x4];
                yr = [arc(:,2)',y2,y3,y4];
            elseif eldata.eltopclass(e) == 3 %nodes topo. case #2
                %closed loop order: curved arc -> nodes 3,4,1             
                xr = [arc(:,1)',x3,x4,x1];
                yr = [arc(:,2)',y3,y3,y1];
            elseif eldata.eltopclass(e) == 4 %nodes topo. case #3
                %closed loop order: curved arc -> nodes 4,1,2            
                xr = [arc(:,1)',x4,x1,x2];
                yr = [arc(:,2)',y4,y1,y2];
            elseif eldata.eltopclass(e) == 5 %nodes topo. case #4
                %closed loop order: curved arc -> nodes 1,2,3            
                xr = [arc(:,1)',x1,x2,x3];
                yr = [arc(:,2)',y1,y2,y3];
            elseif eldata.eltopclass(e) == 6 %nodes topo. case #5
                %closed loop order: curved arc -> nodes 3,4            
                xr = [arc(:,1)',x3,x4];
                yr = [arc(:,2)',y3,y4];
            elseif eldata.eltopclass(e) == 7 %nodes topo. case #6
                %closed loop order: curved arc -> nodes 3,4            
                xr = [arc(:,1)',x4,x1];
                yr = [arc(:,2)',y4,y1];
            elseif eldata.eltopclass(e) == 8 %nodes topo. case #7
                %closed loop order: curved arc -> nodes 1,1            
                xr = [arc(:,1)',x1,x2];
                yr = [arc(:,2)',y1,y2];
            elseif eldata.eltopclass(e) == 9 %nodes topo. case #8
                %closed loop order: curved arc -> nodes 1,1            
                xr = [arc(:,1)',x2,x3];
                yr = [arc(:,2)',y2,y3];
            elseif eldata.eltopclass(e) == 10 %nodes topo. case #9
                %closed loop order: curved arc -> nodes 1            
                xr = [arc(:,1)',x1];
                yr = [arc(:,2)',y1];
            elseif eldata.eltopclass(e) == 11 %nodes topo. case #10
                %closed loop order: curved arc -> nodes 2           
                xr = [arc(:,1)',x2];
                yr = [arc(:,2)',y2];
            elseif eldata.eltopclass(e) == 12 %nodes topo. case #11
                %closed loop order: curved arc -> nodes 3           
                xr = [arc(:,1)',x3];
                yr = [arc(:,2)',y3];
            elseif eldata.eltopclass(e) == 13 %nodes topo. case #12
                %closed loop order: curved arc -> nodes 4           
                xr = [arc(:,1)',x4];
                yr = [arc(:,2)',y4];
            end
            Ar = polyareagreen(xr,yr);
            ddxr = [diff(xr),xr(1) - xr(end)]';
            ddyr = [diff(yr),yr(1) - yr(end)]';
            eldata.nr{e} = [ddyr,-ddxr]./sqrt(ddxr.^2+ddyr.^2);
            eldata.vr{e} = [ddxr,ddyr];
        elseif eldata.eltopclass(e) >=2 && eldata.eltopclass(e)<=5
            Ar = 1;
        elseif eldata.eltopclass(e) >=10 && eldata.eltopclass(e) <=13
            Ar = 0;
        end
        Ar = abs(Ar);
        eldata.rhoe(e) = Ar/Ae;
        if eldata.rhoe(e)<0; eldata.rhoe(e) = 0;
        end
        if length(indarc) <= 1 %check if arc crosses at the corners and round off 1%>=density to 0 and 0.99%<=density to 1
            if Ar > 0.99
                eldata.rhoe(e) = 1;
            elseif Ar < 0.01
                eldata.rhoe(e) = 0;
            end
            eldata.arce{e} = [];
            eldata.darce{e} = [];
            eldata.arcxi{e} = [];
            eldata.Narc{e} = [];
            eldata.dNarc{e} = [];
            eldata.indarc{e} = [];
        end
%         plot(arc(:,1),arc(:,2));
%         patch(eldata.nx(eldata.elconnect(e,:)),eldata.ny(eldata.elconnect(e,:)),'b','FaceAlpha',eldata.rhoe(e));
        
    end
end
        
       

end