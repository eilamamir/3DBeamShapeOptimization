function varargout = CrossecSens(P,p,N,dN)

%Calculation of the derivatives of the cross section area properties w.r.t.
% all control point coordinates


np = length(P(1,:)); %number of control points
P = [P, P(:,1: p )]; %repeating the first 3 control points to create a closed curve
n = length(P); % order of B-spline
dsc = length(N(1,:)); %discretization size;
% m = n + p; %order of knots span vector
xx = (N'*P(1,:)')'; %explicit x(xi) cooridnate
yy = (N'*P(2,:)')'; %explicit y(xi) cooridnate
dxx = (dN'*P(1,:)')'; %derivative: dx/dxi = sigma(dN/dxi*P(1)) = [dN/dxi]^T*P(1)
dyy = (dN'*P(2,:)')'; %derivative: dy/dxi = sigma(dN/dxi*P(2)) = [dN/dxi]^T*P(2)

xi = linspace(p,n,dsc);

dA = zeros(2*np,1);
for ip = 1:np
    dxloc = zeros(1,np+p);
    if ip <= p %analyzing the case where the c.p. is duplicated
        dxloc(1,ip) = 1;
        dxloc(1,np+ip) = 1;
        Nktmp = N(logical(dxloc),:);
        dNktmp = dN(logical(dxloc),:);
        Nk = Nktmp(1,:) + Nktmp(2,:);
        dNk = dNktmp(1,:) + dNktmp(2,:);
    else
        dxloc(1,ip) = 1;
        Nk = N(logical(dxloc),:);
        dNk = dN(logical(dxloc),:);
    end
    %derivative of the cross section area using Green's theorem w.r.t. x
    %and y c.p. coordinates for the k-th c.p.
    dA(ip) =    0.5*trapz(xi,(Nk.*dyy - yy.*dNk));
    dA(np+ip) = 0.5*trapz(xi,(xx.*dNk - dxx.*Nk));
end
varargout{1} = dA; %returns the derivative of the cross section area
if nargout == 2 || nargout == 3
    dS = zeros(2*np,2);
    for ip = 1:np
        dxloc = zeros(1,np+p);
        if ip <= p %case where c.p is duplicated
            dxloc(1,ip) = 1;
            dxloc(1,np+ip) = 1;
            Nktmp = N(logical(dxloc),:);
            dNktmp = dN(logical(dxloc),:);
            Nk = Nktmp(1,:) + Nktmp(2,:);
            dNk = dNktmp(1,:) + dNktmp(2,:);
        else
            dxloc(1,ip) = 1;
            Nk = N(logical(dxloc),:);
            dNk = dN(logical(dxloc),:);
        end
        %derivative of the area centroid using Green's theorem w.r.t. x
        %and y c.p. coordinates for the k-th c.p
        dS(ip,1)    = -0.5*trapz(xi,(yy.^2.*dNk)); %dSx/dx
        dS(np+ip,1) = -trapz(xi,((Nk.*yy).*dxx));  %dSx/dy
        dS(ip,2)    =  trapz(xi,((Nk.*xx).*dyy));  %dSy/dx
        dS(np+ip,2) =  0.5*trapz(xi,(xx.^2.*dNk)); %dSy/dy
    end
    varargout{2} = dS; %returns the first moment of the area
end
if nargout == 3
    dI = zeros(2*np,3);
    dIp = zeros(2*np,3);
    for ip = 1:np
        dxloc = zeros(1,np+p);
        if ip <= p %case where c.p is duplicated
            dxloc(1,ip) = 1;
            dxloc(1,np+ip) = 1;
            Nktmp = N(logical(dxloc),:);
            dNktmp = dN(logical(dxloc),:);
            Nk = Nktmp(1,:) + Nktmp(2,:);
            dNk = dNktmp(1,:) + dNktmp(2,:);
        else
            dxloc(1,ip) = 1;
            Nk = N(logical(dxloc),:);
            dNk = dN(logical(dxloc),:);
        end

        A = 0.5*trapz(xi,(xx.*dyy - yy.*dxx)); %cross section area
        Sx = -0.5*trapz(xi,(yy.^2.*dxx));
        Sy = 0.5*trapz(xi,(xx.^2.*dyy));

        Ipxx = -1/3*trapz(xi,(yy.^3.*dxx));
        Ipyy =  1/3*trapz(xi,(xx.^3.*dyy));

        %in case of trancation inaccuracy of the 1st moment around zero, we reduce it manually:
        if abs(Sx)>Ipxx || abs(Sx)>Ipyy; Sx = 1e-6*Sx; end
        if abs(Sy)>Ipxx || abs(Sy)>Ipyy; Sy = 1e-6*Sy; end


        dA(ip) =    0.5*trapz(xi,(Nk.*dyy - yy.*dNk));
        dA(np+ip) = 0.5*trapz(xi,(xx.*dNk - dxx.*Nk));

        dS(ip,1)    = -0.5*trapz(xi,(yy.^2.*dNk)); %dSx/dx
        dS(np+ip,1) = -trapz(xi,((Nk.*yy).*dxx));  %dSx/dy
        dS(ip,2)    =  trapz(xi,((Nk.*xx).*dyy));  %dSy/dx
        dS(np+ip,2) =  0.5*trapz(xi,(xx.^2.*dNk)); %dSy/dy

        %Differentiation of inertia terms in arbitrary frame
        dIp(ip,1)    = -1/3*trapz(xi,(yy.^3.*dNk)); %dIpxx/dx
        dIp(np+ip,1) = -trapz(xi,(Nk.*yy.^2.*dxx)); %dIpxx/dy
        dIp(ip,2)    =  trapz(xi,(Nk.*xx.^2.*dyy)); %dIpyy/dx
        dIp(np+ip,2) =  1/3*trapz(xi,(xx.^3.*dNk)); %dIpyy/dy
        dIp(ip,3)    = -0.5*trapz(xi,(yy.^2.*(Nk.*dxx + dNk.*xx))); %dIpxy/dx
        dIp(np+ip,3) = -trapz(xi,(xx.*(Nk.*yy).*dxx)); %dIpxy/dy
        
        %Applying the differentiation IAW the parallel axis theorem - so the inertia terms are located at the centroid:
        dI(ip,1)    = dIp(ip,1)     - (2*Sy*dS(ip,2)*A     - Sy*dA(ip))/A^2;   %dIxx/dx = dIp_xx/dx - d/dx(Sy^2/A) = dIp_xx/dx - (2Sy*dSy/dx*A - SydA/dx)/A^2
        dI(np+ip,1) = dIp(np+ip,1)  - (2*Sy*dS(np+ip,2)*A - Sy*dA(np+ip))/A^2; %dIxx/dy = dIp_xx/dy - d/dy(Sy^2/A) = dIp_xx/dy - (2Sy*dSy/dy*A - SydA/dy)/A^2
        dI(ip,2)    = dIp(ip,2)     - (2*Sx*dS(ip,1)*A     - Sx*dA(ip))/A^2;   %dIyy/dx = dIp_yy/dx - d/dx(Sx^2/A) = dIp_yy/dx - (2Sx*dSx/dx*A - SxdA/dx)/A^2
        dI(np+ip,2) = dIp(np+ip,2)  - (2*Sx*dS(np+ip,1)*A - Sx*dA(np+ip))/A^2; %dIyy/dy = dIp_yy/dy - d/dy(Sy^2/A) = dIp_yy/dy - (2Sx*dSx/dy*A - SxdA/dy)/A^2
        
        %product of inertia differentiation:
        dSxSy_dx = dS(ip,1)*Sy + Sx*dS(ip,2); %d/dx(Sx*Sy) = dSx/dx*Sy + Sx*dSy/dx
        dSxSy_dy = dS(np+ip,1)*Sy + Sx*dS(np+ip,2);  %d/dy(Sx*Sy) = dSx/dy*Sy + Sx*dSy/dy
        
        dI(ip,3)    = dIp(ip,3)     - (dSxSy_dx*A - Sx*Sy*dA(ip))/A^2;    %dIxy/dx  = dIp_xy/dx - d/dx(Sx*Sy/A) = dIp_xy/dx - (d/dx(Sx*Sy)*A - Sx*Sy*dA/dx)/A^2 
        dI(np+ip,3) = dIp(np+ip,3)  - (dSxSy_dy*A - Sx*Sy*dA(np+ip))/A^2; %dIxy/dy  = dIp_xy/dy - d/dy(Sx*Sy/A) = dIp_xy/dy - (d/dy(Sx*Sy)*A - Sx*Sy*dA/dy)/A^2 
    end
    varargout{3} = dI; %returns the 2nd moment of the area, i.e. the 2x2 inertia tensor
end   
    
    
end
