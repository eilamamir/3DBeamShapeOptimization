function [w10,Phi10] = EigFreqCircCrossSec(V,L,E,nu,rho,nmem,bc)

%This function calculates the first 10 eigenfrequencies and eigenmodes of a
%cylindrical cross section beam based upon quadratic Timoshenko's beam FE.
%Input:
%geomerical properties: V-volume and L-length
%material proerties: E elasticity, nu - Poisson ratio, rho - density
%number of beam elements: nmem
%boundary conditions - bc:
%'ps' - pinned-supproted; 'cf' - clamped-free; 'cc' - clamped-clamped

A = V/L;
r = sqrt(A/pi);
I = pi*r^4/4;
G = E/(2*(1+nu));
k = 0.852;

nnodes = 2*nmem + 1;
ndofs = 6*nnodes;
Ms = rho*diag([A,A,A,I,I,2*I]);
Ks = diag([k*G*A,k*G*A,E*A,E*I,E*I,2*G*I]);

[Kb,~] = BeamGaussIntegM(Ks,[],L/nmem,2);
[~,Mb] = BeamGaussIntegM([],Ms,L/nmem,3);

M = MassAssemblyFull(nmem,Mb);
K = StiffAssemblyFull(nmem,Kb);

if strcmpi(bc,'cf')        
    fixeddofs = 1:6; %fixed - free
elseif strcmpi(bc,'cc')
    fixeddofs = [1:6,ndofs-5:ndofs]; %fixed-fixed
elseif strcmpi(bc,'ps')
    fixeddofs = [1:3,6,ndofs-5,ndofs-4,ndofs]; %support-simp. support
elseif strcmpi(bc,'pp')
    fixeddofs = [1:3,6,ndofs-5,ndofs-4,ndofs-3,ndofs]; %support-simp. support
elseif strcmpi(bc,'ff')
    fixeddofs = [];
end

freedofs = setdiff(1:ndofs,fixeddofs);

% 
Phi = zeros(ndofs);
Lambda = zeros(ndofs);
[Phi(freedofs,freedofs),Lambda(freedofs,freedofs)] = eig(K(freedofs,freedofs),M(freedofs,freedofs)); %solving the eigenproblem results with Phi - matrix of eigenvectors and Lambda - diagonal matrix of eigenvalues
lambda = diag(Lambda);
mass_scales = zeros(ndofs,1);
mass_scales(freedofs) = sqrt(diag(Phi(freedofs,freedofs)'*M(freedofs,freedofs)*Phi(freedofs,freedofs)).^(-1));
% 
Phi = Phi*diag(mass_scales); %scaling eigenvectors to comply with mass orthonormality;
% %     Phicol(loop,:,:) = Phi;
PhiMPhi = Phi'*M*Phi; PhiMPhi(PhiMPhi<1e-7) = 0; %#ok<NASGU> %mass orthonoramlity check
% 
if isempty(fixeddofs)
    rigidmodes = find(lambda<1e-6);
    freedofs = setdiff(1:ndofs,rigidmodes);
end
indnondesdof = find(abs(lambda)<1e-9 & abs(lambda)> 0);
freedofs = setdiff(freedofs,indnondesdof);
%sorting eigenvalues and modes so lambda_{i-1} < lambda_{i} < lambda_{i+1}...
lambda = lambda(freedofs);
Phi = Phi(:,freedofs);
[lambdasort,indsort] = sort(lambda);
lambdasort10 = lambdasort(1:10);
indsort10 = indsort(1:10);
% Phisort = Phi(:,indsort);
Phisort10 = Phi(:,indsort10);
% Phisortnorm = Phi(:,indsort)./max(Phi(:,indsort));

w10 = sqrt(lambdasort10);
Phi10 = Phisort10;


end


function K = StiffAssemblyFull(nmem,Kb)

%stiffness matrix assembly for the ground structure case
nnodes = 2*nmem + 1;
ndofs = 6*nnodes;
K = zeros(ndofs);

for m = 1:nmem
    actnodes = [2*m-1,2*m,2*m+1];
    actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
               actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
               actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];
    K(actdofs,actdofs) = K(actdofs,actdofs) +  Kb;
end

end

function M = MassAssemblyFull(nmem,Mb)

%stiffness matrix assembly for the ground structure case
% nnodes = length(gsdata.IX(:,1));
nnodes = 2*nmem + 1;
ndofs = 6*nnodes;
M = zeros(ndofs);

for m = 1:nmem
    actnodes = [2*m-1,2*m,2*m+1];
    actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
               actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
               actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];
    M(actdofs,actdofs) = M(actdofs,actdofs) +  Mb;
end

end
