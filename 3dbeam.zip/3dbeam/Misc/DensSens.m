function drho = DensSens(eldata,N,spord)

%Calculation of the derivatives of the density w.r.t. control point coordinates.
%Based on the 'design velocity' calculation.

nN = length(N(:,1));
np = nN - spord; %number of c.p.

%design velocity calculation - dPi/dsj P - 2 vectors of the cpts (control
%points) coordinates. sj - specific coordinate: x or y. dPi/dsj is nonzero
%only when: i=j. This happens only once for most of the cpts. Yet, a closed
%spline is characterized with number of repeated control points as the
%bspline order.

isarc = logical(eldata.rhoe > 0 & eldata.rhoe < 1);

drho = zeros(eldata.nel,2*np);

for e = 1:eldata.nel
    
    if isarc(e)
        dxi = eldata.arcxi{e}(2) -  eldata.arcxi{e}(1);
        for ci = 1:2*np
           vpts = zeros(2,nN);
            if ci <= np && ci <= spord 
                vpts(1,ci) = 1;
                vpts(1,np+ci) = 1;
            elseif ci <= np
                vpts(1,ci) = 1;
            elseif ci > np && ci <= np+spord
                vpts(2,ci - np) = 1;
                vpts(2,ci) = 1;
            else
                vpts(2,ci-np) = 1;  
            end
            
            velocity = (vpts*eldata.Narc{e})';
            narc = [eldata.darce{e}(:,2),-eldata.darce{e}(:,1)]./sqrt(eldata.darce{e}(:,1).^2 + eldata.darce{e}(:,2).^2);           
            dxy = sqrt(eldata.darce{e}(:,1).^2 + eldata.darce{e}(:,2).^2)*dxi;
            drho(e,ci) = 1/eldata.Ae*trapz(dot(velocity',narc')'.*dxy); %this one is the best so far...
            
        end
    end 
end
    
end
