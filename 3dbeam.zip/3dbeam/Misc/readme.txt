List of 'Misc' subroutines:

BeamGaussInteg: A subroutine that performs intergration IAW the Gauss quadrature itegration method.

controlpolygon: A subroutine that calculates all the required properties of the control polygon.

CrossecSens: A subroutine that calculates derivatives of the cross section properties for the sensitivity analysis (area, 1st and 2nd moments of area)

DensSens: A subroutine that calculates the derivatives of any element density w.r.t. coordinates of the control polygon's control points.

eldensity: A subroutine which performs the classification of 14 cases of element densities.

inpoly: An efficient 'in-polygon' calculation (imported as is from Mathworks' repository)

polyareagreen: Calculation of any polygon area (including a polygon with very large number of sides) utilizing the shoelace method

WatertightStlWrite: A subroutine that plots a watertight manifold for the nice visualization of the beam elements.
