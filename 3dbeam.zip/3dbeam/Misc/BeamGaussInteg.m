function Kb = BeamGaussInteg(Ks,L,nGp)

%Gauss integration of the crosssection stiffness and the quadratic shape
%function w.r.t. the beam length to obtain the 18x18 quadratic beam element
%stiffness matrix


%Reduced integartion: 1 point Gauss quadrature:
% pG = 0; 
% wG = 2;


if nGp == 2
    %Two points Gauss quadrature:    
    pG = [-1/sqrt(3),1/sqrt(3)]; 
    wG = [1,1];
elseif nGp == 3
    %Three points Gauss quadrature:
    pG = [-sqrt(3/5),0,sqrt(3/5)];
    wG = [5/9,8/9,5/9];
elseif nGp ==32
%    Three points Gauss-Lobatto quadrature:
    pG = [-1,0,1];
    wG = [1/3,4/3,1/3];
elseif nGp == 4
    pG = [-sqrt(3/7+2/7*sqrt(6/5)),-sqrt(3/7-2/7*sqrt(6/5)),sqrt(3/7-2/7*sqrt(6/5)),sqrt(3/7+2/7*sqrt(6/5))];
    wG = [(18+30^0.5)/36,(18-30^0.5)/36,(18-30^0.5)/36,(18+30^0.5)/36];
elseif nGp == 5
%     Five points Gauss-Lobatto quadrature:
    pG = [-1,-sqrt(3/7),0,sqrt(3/7),1];
    wG = [0.1,49/90,32/45,49/90,0.1];
end
   
xi = pG;

h1 = 1/2*(1 - xi) - 1/2*(1 - xi.^2);
h2 = 1-xi.^2;
h3 = 1/2*(1 + xi) - 1/2*(1-xi.^2);

dh1 = -1/2 + xi;
dh2 = -2*xi;
dh3 = 1/2 + xi;

Tr = zeros(6); Tr(1,5) = -1; Tr(2,4) = 1;
detJ = L/2;
Kb = zeros(18);

for iG = 1:length(pG)
    N = [eye(6)*h1(iG),eye(6)*h2(iG),eye(6)*h3(iG)];
    dN = [eye(6)*dh1(iG),eye(6)*dh2(iG),eye(6)*dh3(iG)];
    B = Tr*N + detJ^(-1)*dN;
    Kb = Kb + wG(iG)*B'*Ks*B*detJ;
end

end