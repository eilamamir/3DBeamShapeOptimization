function PostPlotInProcess(MemberProps,m,istext)
%m = # of segement

figure;
for e = 1: MemberProps{m}.eldata.nel
    patch(MemberProps{m}.eldata.nx(MemberProps{m}.eldata.elconnect(e,:)),MemberProps{m}.eldata.ny(MemberProps{m}.eldata.elconnect(e,:)),'k','FaceAlpha',MemberProps{m}.eldata.rhoe(e),'EdgeColor','c');
if strcmpi(istext,'TextOn')
    text((MemberProps{m}.eldata.nx(MemberProps{m}.eldata.elconnect(e,1))+MemberProps{m}.eldata.nx(MemberProps{m}.eldata.elconnect(e,2)))/2,...
        (MemberProps{m}.eldata.ny(MemberProps{m}.eldata.elconnect(e,1))+MemberProps{m}.eldata.ny(MemberProps{m}.eldata.elconnect(e,4)))/2,num2str(MemberProps{m}.eldata.rhoe(e)),'FontSize',8,'Color','m');
end
end
hold on;
plot([MemberProps{m}.Cs(:,1);MemberProps{m}.Cs(1,1)],[MemberProps{m}.Cs(:,2);MemberProps{m}.Cs(1,2)],'b','LineWidth',1.5);
plot([MemberProps{m}.px;MemberProps{m}.px(1)],[MemberProps{m}.py;MemberProps{m}.py(1)],'ro--');
if strcmpi(istext,'TextOn')
    for ip = 1:length(MemberProps{m}.px)
        text(0.9*MemberProps{m}.px(ip),0.9*MemberProps{m}.py(ip),num2str(ip));
    end
end
axis equal; axis off;
