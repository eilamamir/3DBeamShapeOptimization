function fv = WatertightStlWrite(filename,x,y,z,R,mode)

%This subroutine takes to faces of a discretized prism, performs 2D
%triangulation to faces of a closed form which then exported as a watertight
%stl file.
%inputs:
% a filename with the '.stl' extension, to be read.
% the x,y,z, coordinates of the two faces ordered columnwisely in a single
% column per coordinate

np = length(x)/2;

verticeslocal = R*[x';y';z']; %transferring to local coordinates to construct vertices list: global to local: Plocal = R*Pglobal

%connectivity of vertices for face1 & face2 
polyg = polyshape(verticeslocal(1,1:np),verticeslocal(2,1:np)); %preparing vertices list

Tri = triangulation(polyg); %preparing connectivity of x and y coordinates so non-cnovex shapes can be accounted as well.
np = length(Tri.Points(:,1));
faces3 = [(1:np)',[(2:np)';1],(1+np:2*np)'];
faces4 = [(1+np:2*np)',[(2+np:2*np)';1+np],[(2:np)';1]];


fv.faces = [Tri.ConnectivityList;Tri.ConnectivityList + np;faces3;faces4];
try
    fv.vertices = (R'*[[Tri.Points;Tri.Points],verticeslocal(3,:)']')';
catch
    npts = size(verticeslocal',1)/2;
    if size(Tri.Points,1) > npts
        fixed_xy_pts = Tri.Points(1:npts,:);
        fv.vertices = (R'*[fixed_xy_pts,verticeslocal(3,1:npts)';fixed_xy_pts,verticeslocal(3,npts+1:2*npts)']')';
    else
        fv.vertices = (R'*[Tri.Points,verticeslocal(3,1:np)';Tri.Points,verticeslocal(3,np+1:2*np)']')';
    end        
    warning('Faces triangulation failed. Manifold probably contains holes.');
end

if ~isempty(filename)
    try
        stlWrite(filename,fv.faces,fv.vertices,'mode',mode);
    catch
        tr2d = triangulation(fv.faces,fv.vertices);
        stlwrite(tr2d,filename,'binary');
    end        
    fprintf('%2i faces wrote to file \n',length(fv.faces));
end

end

