function [Kb,Mb] = BeamGaussIntegM(Ks,Ms,L,nGp)

%Gauss integration of the crosssection stiffness and the quadratic shape
%function w.r.t. the beam length to obtain the 18x18 quadratic beam element
%stiffness matrix

% nel = length(Ks(1,1,:));
% KbCol = zeros(18,18,nel);

%Reduced integartion: 1 point Gauss quadrature:
% pG = 0; 
% wG = 2;
if isempty(Ks); Ks = zeros(6); end
if isempty(Ms); Ms = zeros(6); end

if nGp == 2
    %Two points Gauss quadrature:    
%     pG = [-1/sqrt(3),1/sqrt(3)]; 
%     wG = [1,1];
    pG = [-0.577350269189626,0.577350269189626]; 
    wG = [1,1];

elseif nGp == 3
    %Three points Gauss quadrature:
    pG = [-sqrt(3/5),0,sqrt(3/5)];
    wG = [5/9,8/9,5/9];
elseif nGp ==32
%    Three points Gauss-Lobatto quadrature:
    pG = [-1,0,1];
    wG = [1/3,4/3,1/3];
elseif nGp == 4
%     pG = [-sqrt(3/7+2/7*sqrt(6/5)),-sqrt(3/7-2/7*sqrt(6/5)),sqrt(3/7-2/7*sqrt(6/5)),sqrt(3/7+2/7*sqrt(6/5))];
%     wG = [(18+30^0.5)/36,(18-30^0.5)/36,(18-30^0.5)/36,(18+30^0.5)/36];
    pG = [-0.861136311594053,-0.339981043584856,0.339981043584856,0.861136311594053];
    wG = [0.345854845137454,0.652145154862546,0.652145154862546,0.345854845137454];
elseif nGp == 5
    pG = [-0.906179845938664,-0.538469310105683,0.0,0.538469310105683,0.906179845938664];
    wG = [ 0.236926885056189, 0.478628670499366,0.568888888888889, 0.478628670499366,0.236926885056189];
elseif nGp == 52
%     Five points Gauss-Lobatto quadrature:
    pG = [-1,-sqrt(3/7),0,sqrt(3/7),1];
    wG = [0.1,49/90,32/45,49/90,0.1];
elseif nGp == 6
    pG = [-0.932469514203152,-0.661209386466265,-0.238619186083197,0.238619186083197,0.661209386466265,0.932469514203152];
    wG = [ 0.171324492379170, 0.360761573048139, 0.467913934572691,0.467913934572691,0.360761573048139,0.171324492379170];    
end
   
xi = pG;
h1 = 1/2*(1 - xi) - 1/2*(1 - xi.^2);
h2 = 1-xi.^2;
h3 = 1/2*(1 + xi) - 1/2*(1 - xi.^2);

dh1 = -1/2 + xi;
dh2 = -2*xi;
dh3 = 1/2 + xi;

Tr = zeros(6); Tr(1,5) = -1; Tr(2,4) = 1;
detJ = L/2;
% detJ = 1;
Kb = zeros(18);
Mb = zeros(18);
for iG = 1:length(pG)
    N = [eye(6)*h1(iG),eye(6)*h2(iG),eye(6)*h3(iG)];
    dN = [eye(6)*dh1(iG),eye(6)*dh2(iG),eye(6)*dh3(iG)];
    B = Tr*N + detJ^(-1)*dN;
    Kb = Kb + wG(iG)*B'*Ks*B*detJ;
    Mb = Mb + wG(iG)*N'*Ms*N*detJ;
%     Mb = Mb + wG(iG)*N'*Ms*N;
end

end