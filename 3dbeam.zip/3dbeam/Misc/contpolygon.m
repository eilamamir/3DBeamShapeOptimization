function [L1,Ltilde,dL,dLtilde] = contpolygon(px,py)

%calculation of the control polygon geometrical properties for the cross
%section constraint.
%
%inputs:
%------ 
%        px,py - control polygon coordinates
%outputs: 
%-------
%        L1: 1D vector np length  - control polygon side lenghts
%        Ltilde: 1D vector np length - the cosine of the vertices angles IAW
%        cosine theorem +1  - to obtain only positive values
%        dL: 2D matrix np x 2*np - derivatives of all polygin sides w.r.t. 
%        coordinates. it has a form of two diagonals and two upper diagonals
%        dLtilde: 2D matrix np x 2*np derivatives of all cosine angles
%        (rows) w.r.t. current coordinates (columns)

np = length(px);
%duplicating the last and first points
ppx = [px(end),px,px(1)];
ppy = [py(end),py,py(1)];

%calculating Li, Li+1, Ld_i and Lbar = (Li^2 + Li+1^2 - Ldi)/(2*Li*Li+1)
L1 =   sqrt((ppx(2:end-1) - ppx(1:end-2)).^2 + (ppy(2:end-1) - ppy(1:end-2)).^2);
L2 = [L1(2:end),L1(1)];
Ld = sqrt((ppx(3:end) - ppx(1:end-2)).^2 + (ppy(3:end) - ppy(1:end-2)).^2);

Lbar = (L1.^2 + L2.^2 - Ld.^2)./(2*L1.*L2);
Ltilde = Lbar + 1;

%solving the singular case of theta = psi = pi by setting very small value:
% dacosLbar = -100*ones(1,np);
dacosLbar = -10*ones(1,np);
dacosLbar(Lbar>-0.999) = -1./sqrt(1-Lbar(Lbar>-0.999).^2);

%setting variables for the bookeepping derivative calculation

dL1dx0 = zeros(1,np);
dL1dx1 = zeros(1,np);
dL2dx1 = zeros(1,np);
dL2dx2 = zeros(1,np);
dLddx0 = zeros(1,np);
dLddx2 = zeros(1,np);

dL1dx0(1) = -(px(1)-px(np))/L1(1);
dL1dx1(1) =  (px(1)-px(np))/L1(1);
dL2dx1(1) = -(px(2)-px(1))/L2(1);
dL2dx2(1) =  (px(2)-px(1))/L2(1);
dLddx0(1) = -(px(2)-px(np))/Ld(1);
dLddx2(1) =  (px(2)-px(np))/Ld(1);

dL1dx0(np) = -(px(np)-px(np-1))/L1(np);
dL1dx1(np) =  (px(np)-px(np-1))/L1(np);
dL2dx1(np) = -(px(1)-px(np))/L2(np);
dL2dx2(np) =  (px(1)-px(np))/L2(np);
dLddx0(np) = -(px(1)-px(np-1))/Ld(np);
dLddx2(np) =  (px(1)-px(np-1))/Ld(np);

dL1dy0 = zeros(1,np);
dL1dy1 = zeros(1,np);
dL2dy1 = zeros(1,np);
dL2dy2 = zeros(1,np);
dLddy0 = zeros(1,np);
dLddy2 = zeros(1,np);

dL1dy0(1) = -(py(1)-py(np))/L1(1);
dL1dy1(1) =  (py(1)-py(np))/L1(1);
dL2dy1(1) = -(py(2)-py(1))/L2(1);
dL2dy2(1) =  (py(2)-py(1))/L2(1);
dLddy0(1) = -(py(2)-py(np))/Ld(1);
dLddy2(1) =  (py(2)-py(np))/Ld(1);

dL1dy0(np) = -(py(np)-py(np-1))/L1(np);
dL1dy1(np) =  (py(np)-py(np-1))/L1(np);
dL2dy1(np) = -(py(1)-py(np))/L2(np);
dL2dy2(np) =  (py(1)-py(np))/L2(np);
dLddy0(np) = -(py(1)-py(np-1))/Ld(np);
dLddy2(np) =  (py(1)-py(np-1))/Ld(np);



for ip = 2:np-1
    dL1dx0(ip) = -(px(ip)-px(ip-1))/L1(ip);
    dL1dx1(ip) =  (px(ip)-px(ip-1))/L1(ip);
    dL2dx1(ip) = -(px(ip+1)-px(ip))/L2(ip);
    dL2dx2(ip) =  (px(ip+1)-px(ip))/L2(ip);
    dLddx0(ip) = -(px(ip+1)-px(ip-1))/Ld(ip);
    dLddx2(ip) =  (px(ip+1)-px(ip-1))/Ld(ip);
    
    dL1dy0(ip) = -(py(ip)-py(ip-1))/L1(ip);
    dL1dy1(ip) =  (py(ip)-py(ip-1))/L1(ip);
    dL2dy1(ip) = -(py(ip+1)-py(ip))/L2(ip);
    dL2dy2(ip) =  (py(ip+1)-py(ip))/L2(ip);
    dLddy0(ip) = -(py(ip+1)-py(ip-1))/Ld(ip);
    dLddy2(ip) =  (py(ip+1)-py(ip-1))/Ld(ip);

end
    
dLbardL1 =  (L1.^2 - L2.^2 + Ld.^2)./(2*L1.^2.*L2);
dLbardL2 = -(L1.^2 - L2.^2 - Ld.^2)./(2*L1.*L2.^2);
dLbardLd = -Ld./(L1.*L2);

dLbardx0 = dLbardL1.*dL1dx0 + dLbardLd.*dLddx0;
dLbardx1 = dLbardL1.*dL1dx1 + dLbardL2.*dL2dx1;
dLbardx2 = dLbardL2.*dL2dx2 + dLbardLd.*dLddx2;

dLbardy0 = dLbardL1.*dL1dy0 + dLbardLd.*dLddy0;
dLbardy1 = dLbardL1.*dL1dy1 + dLbardL2.*dL2dy1;
dLbardy2 = dLbardL2.*dL2dy2 + dLbardLd.*dLddy2;

           
Atheta = zeros(1,np);
for ip = 2:np+1
    Atheta(ip-1) = 0.5*det([1,1,1;ppx(ip-1),ppx(ip),ppx(ip+1);ppy(ip-1),ppy(ip),ppy(ip+1)]);
end

sthetar = sign(Atheta);


dthetap  = zeros(np,2*np);
dL       = zeros(np,2*np);
dLbar    = zeros(np,2*np);
dq1dotq2 = zeros(np,2*np); %the numerator of the dot product: ni>*ni+1> which is used to calculate the external angle 


dthetap(1,np)      = sthetar(1)*dacosLbar(1)*dLbardx0(1); 
dthetap(1,2*np)    = sthetar(1)*dacosLbar(1)*dLbardy0(1); 
dthetap(1,1)       = sthetar(1)*dacosLbar(1)*dLbardx1(1); 
dthetap(1,np+1)    = sthetar(1)*dacosLbar(1)*dLbardy1(1); 
dthetap(1,2)       = sthetar(1)*dacosLbar(1)*dLbardx2(1);
dthetap(1,np+2)    = sthetar(1)*dacosLbar(1)*dLbardy2(1);

dthetap(np,np-1)     = sthetar(np)*dacosLbar(np)*dLbardx0(np); 
dthetap(np,2*np-1)   = sthetar(np)*dacosLbar(np)*dLbardy0(np); 
dthetap(np,np)       = sthetar(np)*dacosLbar(np)*dLbardx1(np); 
dthetap(np,2*np)     = sthetar(np)*dacosLbar(np)*dLbardy1(np); 
dthetap(np,1)        = sthetar(np)*dacosLbar(np)*dLbardx2(np);
dthetap(np,np+1)     = sthetar(np)*dacosLbar(np)*dLbardy2(np);

%%%%%

dLbar(1,np)      = dLbardx0(1); 
dLbar(1,2*np)    = dLbardy0(1); 
dLbar(1,1)       = dLbardx1(1); 
dLbar(1,np+1)    = dLbardy1(1); 
dLbar(1,2)       = dLbardx2(1);
dLbar(1,np+2)    = dLbardy2(1);

dLbar(np,np-1)   = dLbardx0(np); 
dLbar(np,2*np-1) = dLbardy0(np); 
dLbar(np,np)     = dLbardx1(np); 
dLbar(np,2*np)   = dLbardy1(np); 
dLbar(np,1)      = dLbardx2(np);
dLbar(np,np+1)   = dLbardy2(np);


dL(1,np)      = dL1dx0(1);
dL(1,2*np)    = dL1dy0(1);
dL(1,1)       = dL1dx1(1);
dL(1,np+1)    = dL1dy1(1);
dL(np,np-1)   = dL1dx0(np);
dL(np,2*np-1) = dL1dy0(np);
dL(np,np)     = dL1dx1(np);
dL(np,2*np)   = dL1dy1(np);

%calculation of the nomerator of the cos(psi) - the abs. ext. angle:
%d(qi>dotqi+1>)/dx_i = d(xi*xi+1 + yi*yi+1)/dxi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dq1dotq2(1,np)      = px(1)  - px(2); %d(q_n>*dq_1>)/dxn = x1 - x2
dq1dotq2(1,1)       = px(np) - 2*px(1) + px(2); %d(q_n>*q_1>)/dx1 = xn - 2*x1 + x2 
dq1dotq2(1,2)       = px(1)  - px(np); %d(q_n>*q_1)/dx2 = x1 - xn
dq1dotq2(np,np-1)   = px(np) - px(1); %d(q_n>*q_1>)/dxn = xn - x1
dq1dotq2(np,np)     = px(np-1) - 2*px(np) + px(1); %d(q_n-1>*q_n>)/dxn = xn-1 - 2*xn + x1 
dq1dotq2(np,1)      = px(np) - px(np-1); %d(q_n-1>*dq_n>)/dx1 = x_n - x_n-1

dq1dotq2(1,2*np)    = py(1)  - py(2); %d(q_n>*dq_1>)/dyn = y1 - y2
dq1dotq2(1,np+1)    = py(np) - 2*py(1) + py(2); %d(q_n>*q_1>)/dy1 = yn - 2*y1 + y2 
dq1dotq2(1,np+2)    = py(1)  - py(np); %d(q_n>*q_1)/dy2 = y1 - yn
dq1dotq2(np,2*np-1) = py(np) - py(1); %d(q_n>*q_1>)/dyn = yn - y1
dq1dotq2(np,2*np)   = py(np-1) - 2*py(np) + py(1); %d(q_n-1>*q_n>)/dyn = yn-1 - 2*yn + y1 
dq1dotq2(np,np+1)   = py(np) - py(np-1); %d(q_n-1>*dq_n>)/dy1 = y_n - y_n-1

for ip = 2:np-1
    dthetap(ip,ip-1)     = sthetar(ip)*dacosLbar(ip)*dLbardx0(ip); %dtheta_i/dxi-1
    dthetap(ip,np+ip-1)  = sthetar(ip)*dacosLbar(ip)*dLbardy0(ip); %dtheta_i/dyi-1
    dthetap(ip,ip)       = sthetar(ip)*dacosLbar(ip)*dLbardx1(ip); %dtheta_i/dxi
    dthetap(ip,np+ip)    = sthetar(ip)*dacosLbar(ip)*dLbardy1(ip); %dtheta_i/dyi
    dthetap(ip,ip+1)     = sthetar(ip)*dacosLbar(ip)*dLbardx2(ip); %dtheta_i/dx+1
    dthetap(ip,np+ip+1)  = sthetar(ip)*dacosLbar(ip)*dLbardy2(ip); %dtheta_i/dy+1
    %%%
    dLbar(ip,ip-1)     = dLbardx0(ip); %dLbar_i/dxi-1
    dLbar(ip,np+ip-1)  = dLbardy0(ip); %dLbar_i/dyi-1
    dLbar(ip,ip)       = dLbardx1(ip); %dLbar_i/dxi
    dLbar(ip,np+ip)    = dLbardy1(ip); %dLbar_i/dyi
    dLbar(ip,ip+1)     = dLbardx2(ip); %dLbar_i/dx+1
    dLbar(ip,np+ip+1)  = dLbardy2(ip); %dLbar_i/dy+1
    
    %%%
    dL(ip,ip-1)    = dL1dx0(ip);
    dL(ip,np+ip-1) = dL1dy0(ip);
    dL(ip,ip)      = dL1dx1(ip);
    dL(ip,np+ip)   = dL1dy1(ip);
    
    %%%
    dq1dotq2(ip,ip-1)    = px(ip) - px(ip+1);               %d(q_j+1>*q_j)/dxj = xj+1 - xj+2
    dq1dotq2(ip,np+ip-1) = py(ip) - py(ip+1);               %d(q_j+1>*q_j)/dyj = yj+1 - yj+2
    dq1dotq2(ip,ip)      = px(ip-1) - 2*px(ip) + px(ip+1);  %d(q_j-1>*q_j>)/dxj = xj-1 - 2*xj + xj+1 
    dq1dotq2(ip,np+ip)   = py(ip-1) - 2*py(ip) + py(ip+1);  %d(q_j-1>*q_j>)/dyj = yj-1 - 2*yj + yj+1
    dq1dotq2(ip,ip+1)    = px(ip) - px(ip-1);               %d(q_j-2>*q_j-1)/dxj = xj-1 - xj-2
    dq1dotq2(ip,np+ip+1) = py(ip) - py(ip-1);               %d(q_j-2>*q_j-1)/dyj = yj-1 - yj-2
    
end

dLtilde = dLbar; %the derivatives of the cosine angle and the cosine angle +1 in the same

%polygon discrete curvature calculation - may be useful some day
% 
% q1 = [diff(ppx(1:end-1));diff(ppy(1:end-1))];
% q2 = [q1(:,2:end),q1(:,1)];
% n1 = q1./L1;
% n2 = [n1(:,2:end),n1(:,1)];
% q1dotq2 = dot(q1,q2);
% n1dotn2 = dot(n1,n2);
% dacosn1dotn2 = -10*ones(1,np);
% dacosn1dotn2(n1dotn2<0.999) = -1./sqrt(1-n1dotn2(n1dotn2<0.999).^2);
% 
% psi = acos(n1dotn2); %abs. ext. angle
% k = 2*psi./(L1+L2); %#ok<NASGU>  %abs. normalized curvature
% 
% 
% %calculating derivatives of k w.r.t. design variables
% 
% %calciation the denomerator of the ni>*ni+1> product: d/dqj(Li*Li+1)
% dL1 = dL;
% dL2 = [dL(2:end,:);dL(1,:)];
% dL1andL2 = dL1 + dL2; %d(Li+Li+1)/dqj
% 
% dL1L2 = zeros(np,2*np);
% dn1dotn2 = zeros(np,2*np);
% dpsi = zeros(np,2*np);
% dk   = zeros(np,2*np);
% for ip = 1:np
%     for jp = 1:np       
%         dL1L2(ip,jp)    = dL1(ip,jp).*L2(ip)    + L1(ip).*dL2(ip,jp);
%         dL1L2(ip,np+jp) = dL1(ip,np+jp).*L2(ip) + L1(ip).*dL2(ip,np+jp);
%         
%         dn1dotn2(ip,jp) = (1/(L1(ip)*L2(ip))^2)*(dq1dotq2(ip,jp)*(L1(ip)*L2(ip)) - ...
%                           q1dotq2(ip)*dL1L2(ip,jp));
%         dn1dotn2(ip,np+jp) = (1/(L1(ip)*L2(ip))^2)*(dq1dotq2(ip,np+jp)*(L1(ip)*L2(ip)) - ...
%                           q1dotq2(ip)*dL1L2(ip,np+jp));
%         dpsi(ip,jp)    = dacosn1dotn2(ip)*dn1dotn2(ip,jp);
%         dpsi(ip,np+jp) = dacosn1dotn2(ip)*dn1dotn2(ip,np+jp);
%         dk(ip,jp) = (2/(L1(ip)+L2(ip))^2)*(dpsi(ip,jp)*(L1(ip)+L2(ip))-psi(ip)*dL1andL2(ip,jp));
%         dk(ip,np+jp) = (2/(L1(ip)+L2(ip))^2)*(dpsi(ip,np+jp)*(L1(ip)+L2(ip))-psi(ip)*dL1andL2(ip,np+jp));
%         
%     end
% end

end