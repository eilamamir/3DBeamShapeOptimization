function [ Ks, csSol] = BECAS_Constitutive_Ks_WithIntMatsOrigSolve( varargin )
%********************************************************
% File: BECAS_Constitutive_Ks.m
%   Function to calculate the 6x6 cross section stiffness matrix for
%   anisotropic and inhomogeneous sections of arbitrary geometry. This
%   function also returns the solutions matrices which are used for the
%   evaluation of the strains in the cross section for a given vector of
%   forces and moments.
%
% Syntax:
%   [ Ks, csSol, intmat ]=BECAS_Constitutive_Ks( utils )
%
% Input:
%   utils   :  Structure with all inputdata and other data necessary (see
%              BECAS_utils).
%
% Output:
%   Ks        :  Cross section stiffness matrix
%   csSol.dX :  Matrix of solutions dX/dz to cross section equilibrium
%              equations ( du/dz = dX/dz * theta )
%   csSol.dY :  Matrix of solutions dY/dz to cross section equilibrium
%              equations ( dpsi/dz = dY/dz * theta )
%   csSol.X  :  Matrix of solutions X to cross section equilibrium
%              equations ( u = X * theta )
%   csSol.Y  :  Matrix of solutions Y to cross section equilibrium
%              equations ( psi = Y * theta )
%   intmat   : internal submatrices K, H, G for later sensitivity analysis
% Calls:
% based upon original BECAS v3.3 libraries of J.P.Blasques from DTU Wind
% Energy

%Store utils structure
utils = varargin{1};
ndof = 3*utils.nn_2d;
nEgx = ndof + 12;
%% Assemble global matrices
%fprintf(1,'> Started assembling matrices... ')
%[ K11, H, G22 ] = BECAS_Assemble_Ks(utils);
[submats] = BECAS_Assemble_Ks_SubMatsQ4(utils);

Eg = submats.Eg;
Rg = submats.Rg;
Ag = submats.Ag;
Dg = submats.Dg;
Cg = submats.Cg;
Lg = submats.Lg;
Mg = submats.Mg;

K11 = [Eg ,  Rg     ,     Dg';
       Rg',  Ag     ,     zeros(6);
       Dg , zeros(6),     zeros(6)];


G22 = [Mg           ,  zeros(ndof,6), zeros(ndof,6);
       zeros(6,ndof),  zeros(6)     , zeros(6)     ;
       zeros(6,ndof),  zeros(6)     , zeros(6)    ];
   
H = [Cg           Lg        zeros(ndof,6);
     zeros(6,ndof) zeros(6) zeros(6);
     zeros(6,ndof) zeros(6) zeros(6)];

 
% Phi = [Eg         ,Rg         ,-(Cg - Cg'), -Lg     ;
%        Rg'        ,Ag         , Lg'       ,zeros(6);
%        zeros(48)  ,zeros(48,6), Eg        ,Rg      ;
%        zeros(6,48),zeros(6,6) , Rg'       ,Ag      ];

Phi = [Eg         ,Rg         ,-(Cg - Cg');
       Rg'        ,Ag         , Lg'       ;
       zeros(48)  ,zeros(48,6), Eg        ];
      

tr = [0,-1,0;1,0,0;0,0,0];
Tr = [zeros(3),tr;zeros(3),zeros(3)];
% %unit loads: F
% F = [zeros(48,6);eye(6);zeros(48,6);Tr'];       

F = [zeros(48,6);eye(6);zeros(48,6)];       

% F1 = [zeros(27,6);eye(6);zeros(27,6)];
% F2 = [zeros(27,6);Tr;zeros(27,6)];
% F = [F1;F2];
% 
W = pinv(Phi)*F;

X = W(1:ndof,:);
Y = W(ndof+1:ndof+6,:);
dX = W(ndof+7:2*ndof+6,:);
%dY = W(2*ndof+7:end,:);
% K11 = K(1:nEgx,1:nEgx);
% G22 = G(nEgx+1:2*nEgx,nEgx+1:2*nEgx);
%fprintf(1,'DONE! \n');

%% Calculate cross section stiffness matrix using Schur complement and
%Matlab's lu
%fprintf(1,'> Started solving cross section equilibrium equations...')
[ Ks, w, dw ] = BECAS_SolveLin_Schur( K11, H, G22 );
%fprintf(1,'DONE! \n');
%Extracting state variables from solution vector
nEx=size(K11,1)-12; nAx=6;
csSol.dX=dw(1:nEx,:);
csSol.dY=dw(nEx+1:nEx+nAx,:);
csSol.X=w(1:nEx,:);
csSol.Y=w(nEx+1:nEx+nAx,:);
% intmat.K = K;
% intmat.G = G;
% intmat.H = H;
end