function BECAS_PARAVIEW( dirname, utils, csprops, warping, strain, stress, failure )
%********************************************************
% File: BECAS_PARAVIEW.m
%   Write BECAS input and result data to several files in EnSight Gold
%   format. These files can be loaded in Paraview or CEI Ensight in order to
%   visualize:
%       * Mesh
%       * Material Assignment
%       * Material Orientation
%       * Element Numbers
%       * Node Numbers
%       * Elastic Center, Shear Center, Mass Center
%       * Warping Displacements
%       * Stresses and Strains
%       * Results of failure criteria
%   The first argument is the name of the directory to which the
%   EnSight files should be written. If the directory exists, it
%   is deleted!
%
% Syntax:
%   BECAS_PARAVIEW( dirname, utils, csprops, warping, strain, stress, failure )
%
% The first two arguments (dirname and utils) are required,
% the rest is optional! The number of EnSight files produced and the amount
% of data written depends on the number of input arguments provided.
%
% Date:
%   Version 1.0    26.09.2012   Robert Bitsche and Jos� Pedro Blasques
%   Version 2.0    17.12.2013   Robert Bitsche: Now supports multiple
%                               element types per model. Also cleaner files
%                               are generated now which validate if checked
%                               with ens_checker.exe provided by CEI.
%   Version 2.1    20.08.2014   JPBL: Fixed the error message so that all
%                               files are closed and returns to original
%                               folder before aborting function.
%   Version 2.2    20.08.2014   JPBL: Fixed bug so it works when EDETAIL is
%   defined and strain and stress array have the size of the elements in 
%   the detail. strain and stress arrays are now rebuilt to have the size
%   of the entire model. Results are set to zero outside the detail region.
%
% (c) DTU Wind Energy
%********************************************************

%Check if calculating only for detail
if isfield(utils,'edetail')
    if nargin>4;
        %Rebuild strain to have same size as original model
        strain_detail=strain;
        strain=zeros(utils.ne_2d,6);
        strain(utils.edetail,:)=strain_detail;
    end
    if nargin>5;
        %Rebuild stress to have same size as original model
        stress_detail=stress;
        stress=zeros(utils.ne_2d,6);
        stress(utils.edetail,:)=stress_detail;
    end
    if nargin>6;
        %Rebuild failure to have same size as original model
        failure_detail=failure;
        failure=zeros(utils.ne_2d,6);
        failure(utils.edetail,:)=failure_detail;
    end
    %Issue warning message
    warningmessage='Strain, stress and failure results available only for detail, remaining entries set to zero. \n';
    warning('something:anything',warningmessage);
end

%% Make output directory and open case file
fprintf(1,'> Started writing results in EnSight Gold format (Paraview, Ensight)...');
oridir = pwd;

% If paraview output directory exists, delete it and create a new one.
if exist(fullfile(pwd,dirname),'dir') > 1,
    rmdir(dirname,'s');
end;
mkdir(dirname); cd(dirname);

% open the .case-file
casefile = fopen('becas_results.case','w+');

%% For the EnSight Gold file format output needs to be sorted by
% element topology (not element type).
paraview.etopo = [utils.element(utils.etype).etopo];  % make vector of element topology integers
[paraview.etopo, paraview.sind] = sort(paraview.etopo); % sort elements with respect to topology
paraview.el_2d = utils.el_2d(paraview.sind,:); % sorted connectivity table
paraview.elabel = utils.elabel(paraview.sind,:);
paraview.etype = utils.etype(paraview.sind); % sorted
paraview.etopo_string = {utils.element(paraview.etype).etopo_string}; % sorted
paraview.nnpe_2d = [utils.element(paraview.etype).nnpe_2d]; % sorted
paraview.emat = utils.emat(paraview.sind,:);

%% Find indices where element topology changes
sk = size(paraview.el_2d);
paraview.etopochange = find(diff(paraview.etopo))+1;
paraview.etopochange = [1 paraview.etopochange]; % add index 1
paraview.etopochange = [paraview.etopochange sk(1)+1]; % pseudo-change 1 element after last element

%% The following is always written:

% Write geometry file (nodes and elements) and centers (if given)
if nargin > 2
    geo_file = BECAS_PARAVIEWwrite_geo(utils, paraview, csprops);
else
    geo_file = BECAS_PARAVIEWwrite_geo(utils, paraview);
end

% Write material id numbers to a file
matid_file = 'becas_input.ensi.matid';
BECAS_PARAVIEWwrite_per_element(matid_file,'BECAS material id', paraview, 1, paraview.emat(:,2));

% Write element numbers to a file
% This is for Paraview, Ensight can display the numbers from the geo file.
enum_file = 'becas_input.ensi.enum';
BECAS_PARAVIEWwrite_per_element(enum_file,'BECAS element numbers', paraview, 1, paraview.elabel);

% Write node numbers to a file
% This is for Paraview, Ensight can display the numbers from the geo file.
nnum_file = 'becas_input.ensi.nnum';
BECAS_PARAVIEWwrite_per_node(nnum_file,'BECAS node numbers', 1, utils.nlabel);

% Write material orientation information to 3 individual file
[ori1_file, ori2_file, ori3_file] = BECAS_PARAVIEWwrite_ori(utils, paraview);

% Write to the .case file
fprintf(casefile,'FORMAT\n');
fprintf(casefile,'type: ensight gold\n');
fprintf(casefile,'GEOMETRY\n');
fprintf(casefile,'model: %s\n', geo_file);
fprintf(casefile,'VARIABLE\n');
fprintf(casefile,'scalar per element: material_id %s\n', matid_file);
fprintf(casefile,'vector per element: material_ori_1 %s\n', ori1_file);
fprintf(casefile,'vector per element: material_ori_2 %s\n', ori2_file);
fprintf(casefile,'vector per element: material_ori_3 %s\n', ori3_file);
fprintf(casefile,'scalar per node: nodenumbers %s\n', nnum_file);
fprintf(casefile,'scalar per element: elementnumbers %s\n', enum_file);

%% Write only if centers are given
if nargin>2
    [axis1_file, axis2_file] = BECAS_PARAVIEWwrite_el_axes(utils, csprops);
    % Add to the .case file
    fprintf(casefile,'vector per node: elastic_axis_1  %s\n', axis1_file);
    fprintf(casefile,'vector per node: elastic_axis_2  %s\n', axis2_file);
end

%% Write only if warping displacements are given
if nargin>3
    warp_file = 'becas_output.ensi.warp';
    BECAS_PARAVIEWwrite_per_node(warp_file,'BECAS warping displacements', 1, reshape(warping,3,[])');
    % Add to the .case file
    fprintf(casefile,'vector per node: warping %s\n',warp_file);
end

%% Write only if strains are given
% Strains are written as 6 scalars instaed of a tensor here because of a
% bug in Paraview.
if nargin>4
    paraview.strain = strain(paraview.sind,:);
    if size(strain,2) ~= 6
        fclose('all');
        cd(oridir);
        errormessage='\n Error: Function BECAS_PARAVIEW expects one strain tensor per element\n';
        error('something:anything',errormessage);
    end
    tensor_indices = {'11' '22' '12' '13' '23' '33'};
    for i=1:6
        strain_file = sprintf('becas_output.ensi.strain%s', tensor_indices{i});
        description = sprintf('BECAS strain%s', tensor_indices{i});
        BECAS_PARAVIEWwrite_per_element(strain_file,description, paraview, 1, paraview.strain(:,i));
        fprintf(casefile,'scalar per element: strain%s  becas_output.ensi.strain%s\n',tensor_indices{i},tensor_indices{i});
    end
end

%% Write only if stresses are given
% Stresses are written as 6 scalars instaed of a tensor here because of a
% bug in Paraview.
if nargin>5
    paraview.stress = stress(paraview.sind,:);
    if size(stress,2) ~= 6
        fclose('all');
        cd(oridir);
        errormessage='\n Error: Function BECAS_PARAVIEW expects one stress tensor per element\n';
        error('something:anything',errormessage);
    end
    tensor_indices = {'11' '22' '12' '13' '23' '33'};
    for i=1:6
        stress_file = sprintf('becas_output.ensi.stress%s', tensor_indices{i});
        description = sprintf('BECAS stress%s', tensor_indices{i});
        BECAS_PARAVIEWwrite_per_element(stress_file,description, paraview, 1, paraview.stress(:,i));
        fprintf(casefile,'scalar per element: stress%s  becas_output.ensi.stress%s\n',tensor_indices{i},tensor_indices{i});
    end
end

%% Write only if failure parameters are given
if nargin>6
    paraview.failure = failure(paraview.sind,:);
    if size(failure,2) ~= 6
        fclose('all');
        cd(oridir);
        errormessage='\n Error: Function BECAS_PARAVIEW expects failure to be of size ne x 6 \n';
        error('something:anything',errormessage);
    end
    tensor_indices = {'11' '22' '12' '13' '23' '33'};
    for i=1:6
        failure_file = sprintf('becas_output.ensi.failure%s', tensor_indices{i});
        description = sprintf('BECAS failure%s', tensor_indices{i});
        BECAS_PARAVIEWwrite_per_element(failure_file,description, paraview, 1, paraview.failure(:,i));
        fprintf(casefile,'scalar per element: failure%s  becas_output.ensi.failure%s\n',tensor_indices{i},tensor_indices{i});
    end
end

%% Close file and back to original directory
fclose(casefile);
cd(oridir);
fprintf(1,'DONE!\n');
end

