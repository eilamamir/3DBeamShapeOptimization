function [ constitutive_3d, solutions_3d ] = BECAS_3d_Constitutive_Ks( Kg, slice3d_utils )
%********************************************************
% File: BECAS_3D_Constitutive_Ks.m
%   Function to calculate the 6x6 cross section stiffness matrix for
%   anisotropic and inhomogeneous sections of arbitrary geometry based on
%   a 3D FE model of a cross section slice. The function also returns the 
%   solutions matrices which are used for the evaluation of the strains in 
%   the cross section for a given vector of forces and moments.
%
% Syntax:
%   [ Ks, dX, dY, X, Y ]=BECAS_Constitutive_Ks( nl_2d, el_2d, emat,
%   matprops )
% Input:
%   k3d     :  Global stiffness FE matrix of 3D solid model
%   nl_3d   :  List of nodes in the solid model
%
% Output:
%   Ks      :  Cross section stiffness matrix
%   dX      :  Matrix of solutions dX/dz to cross section equilibrium
%              equations ( du/dz = dX/dz * theta )
%   dY      :  Matrix of solutions dY/dz to cross section equilibrium
%              equations ( dpsi/dz = dY/dz * theta )
%   dX      :  Matrix of solutions X to cross section equilibrium
%              equations ( u = X * theta )
%   dX      :  Matrix of solutions Y to cross section equilibrium
%              equations ( psi = Y * theta )
% Calls:
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%% Assemble global cross section matrices
fprintf(1,'Started assembling matrices \n')
[mat3d.Mg,mat3d.Cg,mat3d.Eg,mat3d.Rg,mat3d.Lg,mat3d.Ag,mat3d.Dg] = BECAS_3d_Assemble(Kg,slice3d_utils);
fprintf(1,'Finished assembling matrices \n')

%% Uncomment to use with Matlab's lu
%Calculate cross section stiffness matrix using Matlab's lu solver 
% tic
% fprintf(1,'> Started solving using Matlab lu\n')
% [Ks,solvec.dX,solvec.dY,solvec.X,solvec.Y] = BECAS_SolveLin(Mg,Cg,Eg,Rg,Lg,Ag,Dg);
% toc
% fprintf(1,'> Finished solving \n')
%% Uncomment to use with SuiteSparse
%Calculate cross section stiffness matrix using SuiteSparse KLU solver
% tic
% fprintf(1,'> Started solving using SuiteSparse\n')
% [Ks,solvec.dX,solvec.dY,solvec.X,solvec.Y] = BECAS_SolveLin_SuiteSparse(Mg,Cg,Eg,Rg,Lg,Ag,Dg);
% toc
% fprintf(1,'> Finished solving \n')
%% Uncomment to use with Schur complement and Matlab's lu 
%Calculate cross section stiffness matrix using Schur complement and
%Matlab's lu
fprintf(1,'> Started solving using Schur complement and Matlab lu...')
% tic
[ constitutive_3d.Ks, solutions_3d.dX, solutions_3d.dY, solutions_3d.X, solutions_3d.Y ] = ...
    BECAS_SolveLin_Schur( mat3d.Mg, mat3d.Cg, mat3d.Eg, mat3d.Rg, mat3d.Lg, mat3d.Ag, mat3d.Dg );
% toc
fprintf(1,'DONE! \n');

  
end