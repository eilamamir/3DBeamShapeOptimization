function [ Ks, csSol, intmat ]=BECAS_Constitutive_Ks_OrigPaperWithIntMats( varargin )
%********************************************************
% File: BECAS_Constitutive_Ks.m
%   Function to calculate the 6x6 cross section stiffness matrix for
%   anisotropic and inhomogeneous sections of arbitrary geometry. This
%   function also returns the solutions matrices which are used for the
%   evaluation of the strains in the cross section for a given vector of
%   forces and moments.
%
% Syntax:
%   [ Ks, solvec ]=BECAS_Constitutive_Ks( utils )
%
% Input:
%   utils   :  Structure with all inputdata and other data necessary (see
%              BECAS_utils).
%
% Output:
%   Ks        :  Cross section stiffness matrix
%   solvec.dX :  Matrix of solutions dX/dz to cross section equilibrium
%              equations ( du/dz = dX/dz * theta )
%   solvec.dY :  Matrix of solutions dY/dz to cross section equilibrium
%              equations ( dpsi/dz = dY/dz * theta )
%   solvec.X  :  Matrix of solutions X to cross section equilibrium
%              equations ( u = X * theta )
%   solvec.Y  :  Matrix of solutions Y to cross section equilibrium
%              equations ( psi = Y * theta )
% Calls:
%   utils.m, BECAS_Assemble.m, and BECAS_SolveLin or
%   BECAS_SolveLin_SuiteSparse if SuiteSparse is installed.
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%
%   Version 1.1    07.09.2012   Jos� Pedro Blasques: Included a new solver
%   based on the Schur complement. Significantly faster than the two
%   previous solvers (even after updating). Removed BECAS_utils and changed
%   the input to receive the utils structure. Changed output to gather the
%   solutin vectors in a structure.
%   Version 1.2    28.09.2012   Jos� Pedro Blasques: Header to BECAS is no
%   longer printed here and is moved to BECAS_utils.
%
% (c) DTU Wind Energy
%********************************************************

%Store utils structure
utils = varargin{1};
ndof = 3*utils.nn_2d;
nEgx = ndof + 12;
%% Assemble global matrices
%fprintf(1,'> Started assembling matrices... ')
%[ K11, H, G22 ] = BECAS_Assemble_Ks(utils);
% [K,G,H] = BECAS_Assemble_Ks_FullOrigQ4(utils);
[K,G,H] = BECAS_Assemble_Ks_FullQ4(utils);


K11 = K(1:nEgx,1:nEgx);
K12 = K(1:nEgx,nEgx+1:end);
G22 = G(nEgx+1:2*nEgx,nEgx+1:2*nEgx);
%fprintf(1,'DONE! \n');

%direct calculation using matlab's mldivide on two stages:

%building RHS - 2nd eq:

T=zeros(6);
T(1,5)=-1;
T(2,4)=1;
rhs = sparse([ zeros(ndof,6); T' ; zeros(6)]);
iK11 = K11\eye(nEgx);
W2 = iK11*rhs;
rhs = -K12*W2 + sparse([zeros(ndof,6);eye(6);zeros(6)]);
W1 = iK11*rhs;
W = [W1;W2];
Fs = W'*G*W;
Ks = Fs\eye(6);
% %% Calculate cross section stiffness matrix using Schur complement and
% %Matlab's lu
% %fprintf(1,'> Started solving cross section equilibrium equations...')
[ Ks2, w, dw ] = BECAS_SolveLin_Schur( K11, H, G22 );
% %fprintf(1,'DONE! \n');
% %Extracting state variables from solution vector
nEx=size(K11,1)-12; nAx=6;
csSol.dX=W2(1:nEx,:);
csSol.dY=W2(nEx+1:nEx+nAx,:);
csSol.X=W1(1:nEx,:);
csSol.Y=W1(nEx+1:nEx+nAx,:);
intmat.K = K;
intmat.G = G;
intmat.H = H;
%keyboard;
end