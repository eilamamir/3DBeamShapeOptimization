function [ serr2d ] = BECAS_CalcEnergyReleaseRate( utils, solutions, theta )
%********************************************************
% File: BECAS_CalcEnergyReleaseRate
%   Function to calculate the strain energy release rate at crack tips
%
% Syntax:
%   [ serr2d ] = BECAS_CalcEnergyReleaseRate( utils, solutions, theta )
%
% Input:
%   solutions : Structure with warping solutions as given by
%   BECAS_Constitutive_Ks
%   theta : load vector with forces and moments.
%   utils  : Structure with input data, useful arrays, and constants.
%
% Output:
%   serr2d : Strain energy release rate GI, GII, and GIII.
%
% Calls:
%
% Date:
%   Version 1.0    14.10.2014   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%Evaluate internal forces at cross section finite element nodes
[ forces ] = BECAS_CalcNodalForces(theta, solutions, utils );

%Evaluate strain energy release rate based on the VCCT at central section
disp=solutions.X*theta';
[ serr2d ] = BECAS_VCCT( disp, forces, utils );

end

