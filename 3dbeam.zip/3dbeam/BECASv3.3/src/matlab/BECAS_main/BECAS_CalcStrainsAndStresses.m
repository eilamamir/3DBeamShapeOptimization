function [ strain, stress ] = BECAS_CalcStrainsAndStresses( fm0, solutions, utils )
%********************************************************
% File: BECAS_CalcStrainsAndStresses
%   Function to calculate the strains and stresses at any point in the
%   cross section.
%
% Syntax:
%   [ strain, stress ] = BECAS_CalcStrainsAndStresses( fm0, solutions, becas_utils )
%
% Input:
%   fm0  :  1x6 Load (forces and moments) vector
%   solutions : Structure containing the warping solutions arrays X, Y, dX
%               and dY returned by BECAS_Constitutive_Ks
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   strain : structure containing the strains at element centers and Gauss
%   points in the global and material coordinate system.
%
%   stress : structure containing the stress at element centers and Gauss
%   points in the global and material coordinate system.
%
% Calls:
%
% Date:
%   Version 1.0    14.10.2014   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%Evaluate cross section strains and stresses
[ strain ] = BECAS_RecoverStrains( fm0, solutions, utils );

%Evaluate cross section stresses
[ stress ] = BECAS_RecoverStresses( strain, utils );

%Average Gauss point results
for i=1:6
    strain.MaterialAverageGauss(:,i)=mean(strain.MaterialGauss(:,i:6:end),2);
    stress.MaterialAverageGauss(:,i)=mean(stress.MaterialGauss(:,i:6:end),2);
end

end

