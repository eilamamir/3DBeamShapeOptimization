function [ utils, constitutive, solutions, csprops ] = BECAS_Calc2DAnalysis( options )
%********************************************************
% File: BECAS_Calc2DAnalysis.m
%   Function to calculate all the cross section properties - stiffness and
%   mass matrix, shear and elastic center, etc.
%
% Syntax:
%   [ utils, constitutive, solutions, csprops ] = ...
%    BECAS_Calc2DAnalysis( options )
%
% Input:
%   options   :  Structure with all options required to run BECAS.
%
% Output:
%   utils   :  Structure with input data, useful arrays, and
%              constants.
%   constitutive : structure containing the stiffness and mass matrix.
%   solutions : structure containing the warping solutions.
%   csrops : structure containing the cross section properties.
%
% Calls:
%
%
% Revisions:
%   Version 1.0    14.10.2014   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

% Build arrays for BECAS
[ utils ] = BECAS_Utils( options );

% Call BECAS module for the evaluation of the cross section stiffness matrix
[constitutive.Ks,solutions] = BECAS_Constitutive_Ks(utils);

% Call BECAS module for the evaluation of the cross section mass matrix
[constitutive.Ms] = BECAS_Constitutive_Ms(utils);

% Call BECAS module for the evaluation of the cross section properties
[csprops] = BECAS_CrossSectionProps(constitutive.Ks,utils);

end

