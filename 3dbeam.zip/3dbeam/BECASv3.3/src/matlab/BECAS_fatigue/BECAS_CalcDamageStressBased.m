function [ D ] = BECAS_CalcDamageStressBased( utils, signal )
%********************************************************
% File: BECAS_CalcDamageStressBased
%   Function to calculate the fatigue damage based on a time history of the
%   stresses. 
%   REQUIRES the rainflow counting algorithm from here https://www.mathworks.com/matlabcentral/fileexchange/3026-rainflow-counting-algorithm)
%
% Syntax:
%   [ D ] = BECAS_CalcDamageStressBased( utils, signal )
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
%   signal : array containing the array with stress history for all 
%            elements in the cross section (or element set defined in 
%            EDETAIL.in). The array size is n_t x n_e x n_s where n_t is 
%            the number of instances at which the stresses have been 
%            evaluated (e.g., instants in time), $n_e$ is the number of 
%            elements in the cross section (or defined in EDETAIL.in), and 
%            n_s is the number of stress components (typically \sigma_{11},
%            the stress in the material 11 direction, or the fiber 
%            direction when working with laminated composite materials).
%
% Output:
%   D : array of size n_e x n_s x n_m containing the fatigue damage values 
%       where n_e is the number of elements in the cross section (or 
%       defined in EDETAIL.in), n_s is the number of stress components 
%       (typically \sigma_{11}, the stress in the material 11 direction, or
%       the fiber direction when working with laminated composite 
%       materials), and $n_m$ is the number of methods specified in the 
%       flag options.MeanCorrectionMethod.
%
% Calls:
%  Rainflow counting algorithm from here 
%  https://www.mathworks.com/matlabcentral/fileexchange/3026-rainflow-counting-algorithm)
%
% Date:
%   Version 1.0    06.07.2016   Jos� Pedro Blasques and Martin Eder
%
% (c) DTU Wind Energy
%********************************************************

% Fatigue damage parameters
fatigueExists = 1;
if fatigueExists
    if ~isfield(utils.failMat,'m')
        fatigueExists = 0;
    end
end
if ~fatigueExists
    error('Missing fatigue damage parameters in FAILMAT.in file. Impossile to calculate damage. Please read documentation.');
end

%Read detail
if isfield(utils,'edetail')
    ne_2d=size(utils.edetail,1);
    el_2d=utils.edetail;
else
    ne_2d=utils.ne_2d;
    el_2d=utils.el_2d(:,1);
end

%Find number of components
Nsc = size(signal,3);

%Build matrix of strength components for fatigue damage analysis
UTS = [ reshape([utils.failMat(:).st],3,[])' reshape([utils.failMat(:).t],3,[])'];
UTS = UTS(:,[1 2 4 5 6 3]);
UCS = [ reshape([utils.failMat(:).sc],3,[])' reshape([utils.failMat(:).t],3,[])'];
UCS = UCS(:,[1 2 4 5 6 3]);
URS = UTS;

%Initialize
if ischar(utils.fatigue.MeanCorrectionMethod)
    flagAux = {utils.fatigue.MeanCorrectionMethod};
elseif iscell(utils.fatigue.MeanCorrectionMethod)
    flagAux = utils.fatigue.MeanCorrectionMethod;
end
D = zeros(ne_2d,1,size(flagAux,2));

for ii = 1:size(flagAux,2) %Loop methods
    flagMeanCorrectionMethod = flagAux{ii};
    for counter=1:ne_2d
        e=el_2d(counter);
        matNo = utils.emat(e,2);
        %Set damage parameters
        m = utils.failMat(matNo).m;
        sMeanPeak = utils.failMat(matNo).smp;
        K = utils.failMat(matNo).K;
        for i = 1:Nsc %Loop stress components
            %Get ultimate strength values
            UTSm = UTS(matNo,i);
            UCSm = UCS(matNo,i);
            URSm = URS(matNo,i);
            %Get time stress signal
            signal_piece = signal(:,counter,i);
            %Rainflow counting
            [ amp, mean, cycle ] = BECAS_BECAS2RFC( signal_piece );
            %Initialize N
            N = zeros(size(amp,1),1);
            %Choose mean correction method
            if strcmp(flagMeanCorrectionMethod,'NoMean')
                N = (URSm./amp).^m;
                
            elseif strcmp(flagMeanCorrectionMethod,'Eder')
                N(mean<sMeanPeak) = ( URSm*K./amp(mean<sMeanPeak ).*( 1-( mean(mean<sMeanPeak)-sMeanPeak )./ ( UCSm-sMeanPeak ))).^m;
                N(mean>=sMeanPeak) = ( URSm*K./amp(mean>=sMeanPeak ).*( 1-( mean(mean>=sMeanPeak)-sMeanPeak )./ ( UTSm-sMeanPeak ))).^m;
                
            elseif strcmp(flagMeanCorrectionMethod,'Goodman')
                N(mean<0) = ( URSm*K*( UCSm - mean(mean<0) )./( UCSm*amp(mean<0) ) ).^m;
                N(mean>=0) = ( URSm*K*( UTSm - mean(mean>=0) )./( UTSm*amp(mean>=0) ) ).^m;
                
            elseif strcmp(flagMeanCorrectionMethod,'ShiftedGoodman')
                N = ( ( UTSm+abs(UCSm)-abs(2*mean-UTSm+abs(UCSm)) ) ./ (2*amp) ).^m;

            end
            % Calculate damage index in nodes
            D(counter,i,ii) = sum(cycle./N);

        end
    end
end



end