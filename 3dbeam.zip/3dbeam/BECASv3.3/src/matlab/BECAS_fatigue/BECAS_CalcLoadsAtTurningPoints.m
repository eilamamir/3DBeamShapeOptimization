function [ theta_tp ] = BECAS_CalcLoadsAtTurningPoints( utils )
%********************************************************
% File: BECAS_CalcLoadsAtTurningPoints
%   Function to calculate the turning points of a time-history of cross
%   section loads (forces and moments).
%   REQUIRES the rainflow counting algorithm from here https://www.mathworks.com/matlabcentral/fileexchange/3026-rainflow-counting-algorithm)
%
% Syntax:
%   [ utils.csloadsp ] = BECAS_CalcLoadsAtTurningPoints( utils.csloads )
%
% Input:
%   utils namely utils.csloads  : (n_t x 6) array containing the cross 
%                                 section forces and
%   moments at the n_t instants in time.
%
% Output:
%   utils.csloads : (n_tp x 6) array containing the cross section forces and
%   moments at the n_tp turning points.
%
% Calls:
%  Rainflow counting algorithm from here 
%  https://www.mathworks.com/matlabcentral/fileexchange/3026-rainflow-counting-algorithm)
%
% Date:
%   Version 1.0    06.07.2016   Jos� Pedro Blasques and Martin Eder
%
% (c) DTU Wind Energy
%********************************************************

if ~isfield(utils,'csloads')
    error('Error in BECAS_CalcLoadsAtTurningPoints. The loads in utils.csloads must be defined. Please see documentation.')
end

%% Get turning points of loads
ts_est = [];
t_span = (1:size(utils.csloads,1))';
for i=1:6 %Loop the six cross section forces and moments
    % Extract turning points of load signal
    [ ~, tMx] = sig2ext( utils.csloads(:,i), t_span );
    %Concatenate all turning points
    ts_est = union( ts_est, tMx );
end

% Get indices of the turning points
[~, idx] = ismember(ts_est,t_span);

%Get loads at turning points
theta_tp = utils.csloads(idx(idx>0),:);

end

