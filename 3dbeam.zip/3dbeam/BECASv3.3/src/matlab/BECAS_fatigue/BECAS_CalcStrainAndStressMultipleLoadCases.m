function [ stress_n ] = BECAS_CalcStrainAndStressMultipleLoadCases( utils, solutions, theta_n )
%********************************************************
% File: BECAS_CalcStrainAndStressMultipleLoadCases
%   Function to calculate the stresses at for multiple (typically many) 
%   cross section load (forces and moments) points.
%
% Syntax:
%   [ stress_n ] = BECAS_CalcStrainAndStressMultipleLoadCases( utils, solutions, theta_n )
%
% Input:
%   theta_n  :  nx6 Load (forces and moments) vector at n instants.
%   solutions : Structure containing the warping solutions arrays X, Y, dX
%               and dY returned by BECAS_Constitutive_Ks
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   stress_n:array containing the array with stress history for all 
%            elements in the cross section (or element set defined in 
%            EDETAIL.in). The array size is n_t x n_e x n_s where n_t is 
%            the number of instances at which the stresses have been 
%            evaluated (e.g., instants in time), $n_e$ is the number of 
%            elements in the cross section (or defined in EDETAIL.in), and 
%            n_s is the number of stress components (typically \sigma_{11},
%            the stress in the material 11 direction, or the fiber 
%            direction when working with laminated composite materials).
%
% Calls:
%
% Date:
%   Version 1.0    06.07.2016   Jos� Pedro Blasques and Martin Eder
%
% (c) DTU Wind Energy
%********************************************************

%Check for detail
if isfield(utils,'edetail')
    ne_2d=size(utils.edetail,1);
else
    ne_2d=utils.ne_2d;
end

%% First determine stresses for unit loads
stress_unity = zeros( ne_2d, 6, 6);
theta_u = eye(6);
for i = 1:6
    %Calculate strains at element center in material coordinate system
    [ ~, strain.MaterialElement ] = BECAS_CalcStrainsElementCenter( theta_u(i,:), solutions, utils );
    %Calculate stresses at element center in material coordinate system
    [ ~, stress_unity(:,:,i) ] = BECAS_CalcStressesElementCenter( strain , utils );
end

%% Get turning points of loads
%Instead of analyzing the stresses at all instants in time, the stresses
%are analyzed only where each of the six signals of the forces and moments
%has a local maxima or a minima, i.e., at the turning points. 
% We use here a time history of six components of load (forces and 
%moments) at corresponding section based on nonlinear aeroelastic 
%simulations of the entire turbine. This is a 600s sample from one existing
%load case corresponding to 30 000 instants given here solely as an
%example. The resulting turning points are about � of the original number
%of points, i.e., 15 000.
[ theta_tp ] = BECAS_CalcLoadsAtTurningPoints( utils );

%% Now determine the time history based on linear superposition (i.e.,
%scale stresses from unit loads by actual forces and moments)
stress_n = zeros( size(theta_n,1), ne_2d ,6);
aux_stress = permute(stress_unity,[3,1,2]);
for i = 1:6
    stress_n(:,:,i) = theta_n*aux_stress(:,:,i);
end

end

