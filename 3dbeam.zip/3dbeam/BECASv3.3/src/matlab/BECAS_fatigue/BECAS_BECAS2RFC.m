function [ amp, mean, cycle ] = BECAS_BECAS2RFC( signal )
%BECAS_BECAS2WAFO Summary of this function goes here
%   Detailed explanation goes here

%Get turning points
[ext] = sig2ext( signal ); 
rf = rainflow(ext); 
amp = rf(1,:); 
mean = rf(2,:);  
cycle = rf(3,:);


end

