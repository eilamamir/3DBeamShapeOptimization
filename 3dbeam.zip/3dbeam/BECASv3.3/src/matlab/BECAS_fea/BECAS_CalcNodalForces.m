function [ forces ] = BECAS_CalcNodalForces(...
    theta0, solutions, utils )
%********************************************************
% File: BECAS_RecoverReactions.m
%   Function to calculate the nodal reaction forces at each node of the 
%   cross section FE mesh.
%
% Syntax:
%   [ forces ] = BECAS_CalcNodalForces(...
%    theta0, solutions, utils )
%
% Input:
%  theta0 - vector of forces and moments.
%  solutions - structure holding the warping arrays for unit loads.
%  utils - structure holding general input and useful arrays.
%
% Output:
%
% Calls:
%
%
% Revisions:
%   Version 1.0    07.03.2012   Jos� Pedro Blasques
%   Version 1.1    24.08.2013   Jos� Pedro Blasques: Altered the previous
%   version so that the reaction forces are calculated taking into accoun
%   the whole matrix K in Blasques and Stolpe. Improved computational
%   efficiency by pre-multiplying the warping and strain arrays by the load
%   vector.
%   Version 1.2    03.10.2013   Jos� Pedro Blasques: Rewriten to accomodate
%   the changes included in BECAS_Q4 and BECAS_Q8 which no longer return
%   the matrices R, L, and A. Now Re, Le, and Ae are obtained through
%   matrix matrix multiplications as described in the manual for BECAS_3D.
%   Version 1.3    21.10.2013   Jos� Pedro Blasques: Added the possibility
%   doing the calculations only for a small portion of the elements defined
%   in the list util.edetail.
%
% (c) DTU Wind Energy
%********************************************************

%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
end

% Calculate the reaction forces at each element
forces=zeros(utils.ne_2d,utils.max_mdim_2d*2+12);

% Pre-multiply the warpind and rigid body motions by the load vector
x=solutions.X*theta0';
y=solutions.Y*theta0';
dx=solutions.dX*theta0';
dy=solutions.dY*theta0';

for counter=1:ne_2d
    e=el_2d(counter);
    
    %Defining constants to make equations readable
    nnpe_2d = utils.element(utils.etype(e)).nnpe_2d;
    mdim_2d = utils.element(utils.etype(e)).mdim_2d;    
    
    %% Assemble edof mapping array
    edof_2d=zeros(mdim_2d,1);
    for i=1:nnpe_2d
        for j=1:mdim_2d/nnpe_2d
            edof_2d(mdim_2d/nnpe_2d*(i-1)+j) = mdim_2d /nnpe_2d * (utils.el_2d(e,i+1)-1)+j;
        end
    end
    
    %Assemble material constitutive matrix for element e
    Qe=utils.Q(:,:,e);
    
    %Evaluate element matrices for the different element types
    if(utils.etype(e) == 1)
        [Me,Ee,Ce]  = BECAS_Q4(e,Qe,utils);
    elseif(utils.etype(e) == 2 || ...
           utils.etype(e) == 3)
        [Me,Ee,Ce]  = BECAS_Q8(e,Qe,utils);       
    elseif(utils.etype(e) == 4)
        [Me,Ee,Ce]  = BECAS_T6(e,Qe,utils); 
    end
    
    %Build remaining BECAS matrices
    Ze=utils.Zg(edof_2d,:);
    Re=sparse(Ce*Ze);
    Le=sparse(Me*Ze);
    Ae=sparse(Ze'*Me*Ze);

    %Assemble element matrix
    K11 = [Ee  Re; Re' Ae];
    K12 = [Ce  Le; Le' zeros(size(Ae))];
    Ke = [K11 K12;
          zeros(size(K11)) K11];
    
    %Assemble local solution vectors
    u=x(edof_2d,:);
    psi=y;
    du=dx(edof_2d);
    dpsi=dy;    

    %Evaluate reaction forces
    forces(e,1:mdim_2d*2+12)=( Ke*[ u; psi; du; dpsi] )';

end

end