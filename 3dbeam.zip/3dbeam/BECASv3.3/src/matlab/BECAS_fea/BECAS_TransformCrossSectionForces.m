function [vec]=BECAS_TransformCrossSectionForces(vec,p,alpha)
%********************************************************
% File: BECAS__TransformationVec.m
%   Function to rotate and translate cross section forces and moment
%   vector.
%
% Syntax:
%   [vec]=BECAS_TransformationVec(vec,p1,p2,alpha)
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   Matlab figure
%
% Calls:
%
% Revisions:
%   Version 1.0    22.10.2012   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%Matrix translation
[ T ] = BECAS_CrossSectionTranslationMatrix( p );

%Transform matrix'

vec=T'*vec;

%Matrix rotation
[ R ] = BECAS_CrossSectionRotationMatrix( alpha );

vec=R'*vec;

end