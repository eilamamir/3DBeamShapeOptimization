function [ GlobalElement, MaterialElement ] = BECAS_CalcStressesElementCenter( strain, utils )
%********************************************************
% File: BECAS_CalcStressesElementCenter
%   Function to calculate the stresses at element center for given strain 
%   results.
%
% Syntax:
%   [ GlobalElement, MaterialElement ] = 
%   BECAS_CalcStressesElementCenter( strain, utils )
%
% Input:
%   strain : Structure with strain values calculated at element centers and
%            Gauss points as given by BECAS_RecoverStrains.
%   utils  : Structure with input data, useful arrays, and constants.
%
% Output:
%   GlobalElement : (neX6) array of stresses at element center in the global
%                    coordinate system.
%   MaterialElement : (nex6) array of stresses at element center in the 
%                      material coordinate system.
%
% Calls:
%
% Date:
%   Version 1.0    21.09.2012   Jos� Pedro Blasques
%   Version 1.1    01.10.2012   Jos� Pedro Blasques: Corrected a bug
%   associated with the reordering of the material constitutive matrix when
%   determining the stresses in the local coord. sys..
%   Version 1.2    21.10.2013   Jos� Pedro Blasques: Added the possibility
%   doing the calculations only for a small portion of the elements defined
%   in the list util.edetail.

% (c) DTU Wind Energy
%********************************************************

%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
end

flag_cs.material = 0;
flag_cs.global = 0;
%Flag for ccoordinate system depending on input strains
if isfield(strain,'MaterialElement')
    flag_cs.material = 1;
end
if isfield(strain,'GlobalElement')
    flag_cs.global = 1;
end

%% Initialize variables
GlobalElement=zeros(ne_2d,6);
MaterialElement=zeros(ne_2d,6);

%Mapping from global to material coord. sys. because that is the coord. 
% sys. in which the strains are given
edof=[2 6 5 3 4 1];

%Reordering to match strains in material coordinate system
Qm(edof,edof,:)=utils.Qm;

aaa = strain.MaterialElement';
for counter=1:ne_2d
    e=el_2d(counter);
    
    %% Build material constitutive matrices
    %Build material constitutive matrix in global coordinate system
    Qe_global=utils.Q(:,:,e);
    %Build material constitutive matrix in local coordinate system
    Qe_material=Qm(:,:,e);
    
    %% Stresses at elements
    if flag_cs.global
        %Element stresses in the global coordinate system
        GlobalElement(counter,:)=Qe_global*strain.GlobalElement(counter,:)';
    end
    if flag_cs.material
        %Element stresses in the material coordinate system
        MaterialElement(counter,:)=Qe_material*aaa(:,counter);
        MaterialElement(counter,:)=Qe_material*strain.MaterialElement(counter,:)';
    end
    
end


end