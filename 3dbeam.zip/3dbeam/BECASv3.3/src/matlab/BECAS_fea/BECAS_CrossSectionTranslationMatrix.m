function [ T2 ] = BECAS_CrossSectionTranslationMatrix( p )
%BECAS_TRANSLATIONMATRIX Summary of this function goes here
%   Detailed explanation goes here


%Matrix translation
T2=eye(6);
T2(1,6)=p(2);T2(2,6)=-p(1);T2(3,4)=-p(2);T2(3,5)=p(1);

end

