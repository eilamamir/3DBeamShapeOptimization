function [pr_2d]=BECAS_ReorderNodalPositions(utils)
%Reorganize nodal positions - 2D
pr_2d=zeros((utils.max_nnpe_2d-1)*2+2,utils.ne_2d);
for ii=1:utils.ne_2d
    nnpe_2d = utils.element(utils.etype(ii)).nnpe_2d;
    pr_2d(1:nnpe_2d*2,ii) = reshape(utils.nl_2d( utils.el_2d(ii,2:nnpe_2d+1),2:3)',[],1);
end
end
