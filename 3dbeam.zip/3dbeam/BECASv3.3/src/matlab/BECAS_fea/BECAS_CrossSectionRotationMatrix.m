function [ R1 ] = BECAS_CrossSectionRotationMatrix( alpha )
%BECAS_ROTATIONMATRIX Summary of this function goes here
%   Detailed explanation goes here

c=cosd(alpha);
s=sind(alpha);

R11=[c   s  0;
    -s  c  0;
    0   0  1];
R1=[R11      zeros(3);
    zeros(3) R11];

end

