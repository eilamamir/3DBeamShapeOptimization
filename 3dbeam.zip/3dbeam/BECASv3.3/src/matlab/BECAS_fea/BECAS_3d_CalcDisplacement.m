function [ disp3d ] = BECAS_3d_CalcDisplacement( fm0, solutions, utils )
%********************************************************
% File: BECAS_3d_CalcDisp.m
%   Function to determine the displacement of the for and aft face of a
%   cross section modelled using 3D solid finite elements based on the
%   solutions from BECAS. It assumes that the variation is linear within
%   the slice.
%
% Syntax:
%   [ disp3d ] = BECAS_3d_CalcDisp( fm0, solutions, utils )
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
%   fm0     :  Array with cross section forces and moments.
%   solutions : Structure with the warping fields which are the solutions
%               to the cross section analysis problem.
% Output:
%   disp3d    : Vector with nodal displacements of the for and aft face of
%               the cross section slice.
% 
% Calls:
%
% Date:
%   Version 1.0    01.03.2013   Jos� Pedro Blasques: first version of the
%   this file was written for the validation of the VCCT calculations.
%
% (c) DTU Wind Energy
%********************************************************

%Calculate displacements
xi0=0.5;

%Aft face
disp3d=solutions.X*fm0' - (1-xi0)*utils.deltaz*( solutions.dX*fm0' + utils.Zg*solutions.Y*fm0' ) ;

%Forward face
disp3d(end+1:end*2)=solutions.X*fm0' + xi0*utils.deltaz*( solutions.dX*fm0' + utils.Zg*solutions.Y*fm0' ) ;

end

