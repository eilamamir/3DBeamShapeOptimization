function [ SNe, SZe, Be ] = BECAS_IntegrateStrainDisplacementMatrices( utils, e, xxs, yys )

% Calculate element matrices
if(utils.etype(e) == 1)
    [ xxb, yyb ] = BECAS_Q4_InterpPos( utils.pr_2d(:,e), xxs, yys );
    %Evaluate Jacobian - 2D
    [ iJ, detJ ] = BECAS_Q4_Jacobian( xxs, yys, utils.pr_2d(:,e) );
    %Evaluate the element matrices
    [ SNe ] = BECAS_Q4_SNe( xxs, yys );
    [ SZe ] = BECAS_Q4_SZe( xxb, yyb );
    [ Be ] = BECAS_Q4_Be( xxs, yys, iJ );
elseif(utils.etype(e) == 2 || utils.etype(e) == 3)
    %Nodal coordinates of cross section element in cross section
    %coordinate system
    [ xxb, yyb ] = BECAS_Q8_InterpPos( utils.pr_2d(:,e), xxs, yys );
    %Evaluate Jacobian - 2D
    [ iJ, detJ ] = BECAS_Q8_Jacobian( xxs, yys, utils.pr_2d(:,e) );
    %Evaluate the element stiffness matrices
    [ SNe ] = BECAS_Q8_SNe( xxs, yys );
    [ SZe ] = BECAS_Q8_SZe( xxb, yyb );
    [ Be ] = BECAS_Q8_Be( xxs, yys, iJ );
elseif(utils.etype(e) == 4)
    %Nodal coordinates of cross section element in cross section
    %coordinate system
    [ xxb, yyb ] = BECAS_T6_InterpPos( utils.pr_2d(:,e), xxs, yys );
    %Evaluate Jacobian - 2D
    [ iJ, detJ ] = BECAS_T6_Jacobian( xxs, yys, utils.pr_2d(:,e) );
    %Evaluate the element stiffness matrices
    [ SNe ] = BECAS_T6_SNe( xxs, yys );
    [ SZe ] = BECAS_T6_SZe( xxb, yyb );
    [ Be ] = BECAS_T6_Be( xxs, yys, iJ );
end

end