function [vec]=BECAS_TransformationVec(vec,p1,p2,alpha)
%********************************************************
% File: BECAS__TransformationVec.m
%   Function to rotate and translate cross section forces and moment
%   vector.
%
% Syntax:
%   [vec]=BECAS_TransformationVec(vec,p1,p2,alpha)
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   Matlab figure
%
% Calls:
%
% Revisions:
%   Version 1.0    22.10.2012   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%Matrix translation
T2=eye(6);
%T2(1,6)=p1(2);T2(2,6)=-p1(1);T2(3,4)=-p2(2);T2(3,5)=p2(1);
T2(6,1)=-p1(2);T2(6,2)=p1(1);
T2(4,3)=p2(2);T2(5,3)=-p2(1);

%Transform matrix'
vec=(T2\eye(6))*vec;

%Matrix rotation
c=cosd(alpha);
s=sind(alpha);

R11=[c   s  0;
    -s  c  0;
    0   0  1];
R1=[R11      zeros(3);
    zeros(3) R11];

vec=R1'*vec;

end