function [ K11, H, G22 ] = BECAS_Assemble_Ks( varargin )
%********************************************************
% File: BECAS_Assemble_Ks.m
%   Function to assemble the global 2D finite element matrices
%   associated with the determination of the cross section
%   stiffness matrix.
%
% Syntax:
%   [ Ag, Rg, Lg, Mg, Cg, Eg, Dg ] = BECAS_Assemble_Ks( utils )
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
% Output:
%   Ag      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Rg      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Lg      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Mg      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Cg      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Eg      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Dg      :  Sub-matrix of cross section equilibrium equations
%              holding the constraint equations (see Documentation)
% Calls:
%
% Date:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    24.08.2013   Jos� Pedro Blasques: Matrices R and L are
%   now obtained based on operations with Zg on the M and C matrices. This
%   is according to the relations presented in the paper "Ghiringhelli,
%   G. L., & Mantegazza, P. (1986) Linear, straight and untwisted
%   anisotropic beam section properties from solid finite elements.
%   Composites Engineering, 4(12), 1225�1239". Thing is about 20% faster :)
%   Version 1.2    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

%% Initialization
%Store utils structure
utils = varargin{1};

%Initialize arrays and vectors for sparse storage
%MEC
nMECsum=0;
for e=1:utils.ne_2d
    nMECsum = nMECsum + (utils.element(utils.etype(e)).mdim_2d)^2;
end
iMEC=zeros(nMECsum,1);
jMEC=zeros(nMECsum,1);
vM=zeros(nMECsum,1);
vE=zeros(nMECsum,1);
vC=zeros(nMECsum,1);

%% Call each element of the 2D FE mesh in turn
indMEC=1;
for e=1:utils.ne_2d
    %Defining constants to make equations readable
    nnpe_2d = utils.element(utils.etype(e)).nnpe_2d;
    mdim_2d = utils.element(utils.etype(e)).mdim_2d;
    
    %Assemble material constitutive matrix for element e
    Qe=utils.Q(:,:,e);
    
    %Evaluate element matrices for the different element types
    %Build from presol
    %Build from element integration
    if(utils.etype(e) == 1)
        [Me,Ee,Ce]  = BECAS_Q4(e,Qe,utils);
    elseif(utils.etype(e) == 2 || ...
            utils.etype(e) == 3)
        [Me,Ee,Ce]  = BECAS_Q8(e,Qe,utils);
    elseif(utils.etype(e) == 4)
        [Me,Ee,Ce]  = BECAS_T6(e,Qe,utils);
    end
    
    %Build M,E, and C matrices
    nMEC = mdim_2d^2;
    lenMEC = indMEC : indMEC + nMEC-1;
    
    %Mapping from local to global DOF
    edof_2d=zeros(mdim_2d,1);
    for i=1:nnpe_2d
        for j=1:mdim_2d/nnpe_2d
            edof_2d(mdim_2d/nnpe_2d*(i-1)+j) = mdim_2d / nnpe_2d * (utils.el_2d(e,i+1)-1)+j;
        end
    end
    
    %Assemble i and j indices
    onesM = ones(size(Me,1),1);
    [ma,na] = size(edof_2d); [mb,nb] = size(onesM);
    kronRows = reshape( permute( reshape( onesM(:)*edof_2d(:).', [mb nb ma na] ), [1 3 2 4] ), [ma*mb na*nb] );
    [ma,na] = size(edof_2d); [mb,nb] = size(onesM');
    kronCols = reshape( permute( reshape( onesM(:)*edof_2d(:).', [mb nb ma na] ), [1 3 2 4] ), [ma*mb na*nb] );
    
    iMEC(lenMEC) = reshape(kronRows,nMEC,1);
    jMEC(lenMEC) = reshape(kronCols,nMEC,1);
    
    %Assemble v values
    vM(lenMEC) = reshape(Me,nMEC,1);
    vE(lenMEC) = reshape(Ee,nMEC,1);
    vC(lenMEC) = reshape(Ce,nMEC,1);

    %Advance the index according to the number of entries in current
    %element matrix - set for handling multiple element types
    indMEC = indMEC + nMEC;
    
end

%% Assemble global matrices
Mg=sparse(iMEC,jMEC,vM);
Eg=sparse(iMEC,jMEC,vE);
Cg=sparse(iMEC,jMEC,vC);

%Build remaining A, R and L matrices
Rg=sparse(Cg'*utils.Zg);
% Rg=sparse(Cg*utils.Zg);

Lg=sparse(Mg*utils.Zg);
Ag=sparse(utils.Zg'*Mg*utils.Zg);

%Build constraint matrix
Dg = sparse(utils.Zg');

%% Build block matrices
%Ensure symmetry
Eg=(Eg+Eg')./2;
Ag=(Ag+Ag')./2;
Mg=(Mg+Mg')./2;

%Auxiliary constants
nEx=size(Eg,1);

%Block matrices
% K = [K11, K12; 0, K11]
% K12 = H^T-H
% G = [K11, 0; K12^T, K11]

K11 = [Eg  Rg        Dg';
    Rg' Ag        zeros(6);
    Dg  zeros(6) zeros(6)];

H = [Cg           Lg        zeros(nEx,6);
    zeros(6,nEx) zeros(6) zeros(6);
    zeros(6,nEx) zeros(6) zeros(6)];

G22=[ Mg            zeros(nEx,6) zeros(nEx,6);
    zeros(6,nEx) zeros(6)     zeros(6);
    zeros(6,nEx) zeros(6)     zeros(6);];

end

