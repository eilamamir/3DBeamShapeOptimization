function [ utils ] = BECAS_3d_Extrude_S20( utils )

%Extrude list of nodal positions
for n=1:utils.ndiv+1
    %y components
    utils.nl_3d(1+(n-1)*utils.nn_2d:utils.nn_2d*n,2)=utils.nl_2d(:,2);
    %z components
    utils.nl_3d(1+(n-1)*utils.nn_2d:utils.nn_2d*n,3)=utils.nl_2d(:,3);
    %x components
    utils.nl_3d(1+(n-1)*utils.nn_2d:utils.nn_2d*n,4)=utils.deltaz/utils.ndiv*(n-1);
    %Node numbering
    utils.nl_3d(1+(n-1)*utils.nn_2d:utils.nn_2d*n,1)=utils.nl_2d(:,1)+utils.nn_2d*(n-1);
end

%Extrude element connectivity table
for n=1:utils.ndiv
    for e=1:utils.ne_2d
        nnpe_3d = utils.element(utils.etype(e)).nnpe_3d;
        utils.el_3d(e+(n-1)*utils.ne_2d,1)=utils.el_2d(e,1)+utils.ne_2d*(n-1);
        utils.el_3d(e+(n-1)*utils.ne_2d,2:nnpe_3d/2+1)=utils.el_2d(e,2:nnpe_3d/2+1)+utils.nn_2d*(n-1);
        utils.el_3d(e+(n-1)*utils.ne_2d,nnpe_3d/2+2:end)=utils.el_2d(e,2:nnpe_3d/2+1)+utils.nn_2d*n;
    end
end

%Extrude etype
utils.etype_3d = repmat(utils.etype,utils.ndiv,1);

%Reorganize nodal positions - 3D
utils.pr_3d=zeros((utils.max_nnpe_3d-1)*2+2,utils.ne_3d);
for ii=1:utils.ne_3d
    for i=1:utils.element(utils.element(utils.etype_3d(ii)).etype).nnpe_3d
        utils.pr_3d((i-1)*3+1:(i-1)*3+3,ii)=utils.nl_3d(utils.el_3d(ii,i+1),2:4);
    end
end

%Extrude material properties
utils.Q=repmat(utils.Q,1,1,utils.ndiv);
utils.Qm=repmat(utils.Qm,1,1,utils.ndiv);

end


