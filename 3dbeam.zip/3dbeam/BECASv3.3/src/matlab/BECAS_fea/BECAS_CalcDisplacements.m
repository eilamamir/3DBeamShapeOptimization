function [s,v,u]=BECAS_CalcDisplacements( ub, fm0, utils, solutions  )
%********************************************************
% File: BECAS_CalcDisplacements.m
%   Function to calculate the total displacements at each node of the cross
%   section based on the beam finite element displacements.
%
% Syntax:
%   [s,v,u]=BECAS_CalcDisplacements( ub, fm0, utils, solutions  )
%
% Input:
%  ub : (6x1) array holding the displacements and rotations of a given node
%       of the beam finite element model.
%  fm0 : (1x6) array holding the cross section forces and moments.
%  utils : Structure with all inputdata and other data necessary (see
%          BECAS_utils).
%  solutions : Structural holding the solution arrays to the cross section 
%              linear system of equatons (see BECAS_Constitutive_Ks).
%
% Output:
%  s : (dofx1) array holding the total displacement of each node in the 
%       cross section
%  v : (dofx1) array holding the rigid body contribution to the 
%      displacement of each node in the cross section.
%  u : (dofx1) array holding the warping contribution to the 
%      displacement of each node in the cross section.
%
% Calls:
%
%
% Revisions:
%   Version 1.0    14.01.2013   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%Warping displacement
u=solutions.X*fm0';

%Rigid body motions
v=utils.Zg*ub;

%Total displacement
s=v+u;

end
