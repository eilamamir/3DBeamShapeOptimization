function [ QgMat, QmMat, density ] = ...
    BECAS_RotateElementMaterialConstMatrix( utils )
%********************************************************
% File: BECAS_RotateElementMaterialConstMatrix.m
%   Function to determine the material constitutive matrix at each
%   element of the cross section FE mesh. The procedure includes
%   determining the 3D materia constitutive matrx and rotate it to
%   account for the fiber and fiber plane orientation. All the
%   matrices are storde in three column vectors for sparse storage.
%
% Syntax:
%   [ iQ, jQ, vQ, density ] = BECAS_RotateElementMaterialConstMatrix( utils )
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
% Output:
%   iQ, jQ, vQ : Material constitutive matrix for each
%                element in the cross section FE mesh
%                stored in sparse format
%   density : Material density at each element of the cross section
%             FE mesh
%
% Calls:
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%Initialize arrays
nQ=(6)*(6);
QgMat = zeros(6,6,utils.ne_2d);
QmMat = zeros(6,6,utils.ne_2d);
density=zeros(utils.ne_2d,1);

for e=1:utils.ne_2d
    
    nmat=utils.emat(e,2);
    
    %Store density
    density(e)=utils.matprops(nmat,10);
    
    %EVERYTHING HERE IS IN BOOK ORDERING NOT BECAS
    %Material stiffness matrix in material coordinate system
    [ Qm, Sm ] = BECAS_ElementMaterialConsitutiveMatrix( utils, e );
    
    %Fiber orientations
    cf=cosd(-utils.emat(e,3));
    sf=sind(-utils.emat(e,3));
    %Material constitutive matrix
    [Qg]=BECAS_ElemRotateLayer(Qm,cf,sf);

    %Fiber plane orientations
    cp=cosd(-utils.emat(e,4));
    sp=sind(-utils.emat(e,4));
    %Material constitutive matrix
    [Qg]=BECAS_ElemRotateFiberPlane(Qg,cp,sp);
    
    %Make sure Qm is symmetric to remove tiny tiny discrepancies
    QmMat(:,:,e)=(Qm+Qm')./2;
    QgMat(:,:,e)=(Qg+Qg')./2;
    
end

end
