function [GlobalElement,MaterialElement]=BECAS_CalcStrainsElementCenter(varargin)
%********************************************************
% File: BECAS_CalcStrainsElementCenter
%   Function to calculate the strains at element centers for a given load
%   (forces and moments) vector.
%
% Syntax:
%   [GlobalElement,MaterialElement]=
%    BECAS_CalcStrainsElementCenter(theta0,solutions,utils)
%
% Input:
%   theta0  :  1x6 Load (forces and moments) vector
%   solutions : Structure containing the warping solutions arrays X, Y, dX
%               and dY returned by BECAS_Constitutive_Ks
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   GlobalElement : (neX6) array of strains at element center in the global
%                    coordinate system.
%   MaterialElement : (nex6) array of strains at element center in the
%                      material coordinate system.
%
% Calls:
%
% Date:
%   Version 1.0    21.09.2012   Jos� Pedro Blasques
%   Version 2.0    24.10.2012   Jos� and Robert: Corrected material
%   rotation. Finally it is right!
%   Version 2.1    21.10.2013   Jos� Pedro Blasques: Added the possibility
%   doing the calculations only for a small portion of the elements defined
%   in the list util.edetail.
%   Version 2.1    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%   Version 2.2    05.07.2016   Jos� Pedro Blasques: Rearranged to
%   accomodate pre-stored strain displacement matrices. 
%
% (c) DTU Wind Energy
%********************************************************

%Get input
theta0 = varargin{1};
solutions = varargin{2};
utils = varargin{3};

%Check if matrices have been preintegrated
presolExist = 0;
if isfield(utils,'presol')
    presolExist = 1;
end

%Check if calculating only for detail
if isfield(utils,'edetail')
    ne_2d=size(utils.edetail,1);
    el_2d=utils.edetail;
else
    ne_2d=utils.ne_2d;
    el_2d=utils.el_2d(:,1);
end

%% Initialize arrays
%Element strains
GlobalElement=zeros(ne_2d,6);
MaterialElement=zeros(ne_2d,6);
%Gauss point position
xxs=0;
yys=0;

%Pre multiply the warping by the load vector
Xtheta=full(solutions.X*theta0');
dXtheta=full(solutions.dX*theta0');
Ytheta=full(solutions.Y*theta0');

%Looping elements
for counter=1:ne_2d
    e=el_2d(counter);
    
    
    %% Evaluate strain displacement matrices
    if presolExist
        %Defining constants to make equations readable
        mdim_2d = utils.element(utils.etype(e)).mdim_2d;
        %Get strain displacement matrices
        if(utils.etype(e) == 1)
            iSNe =6 ; jSNe =12 ;
            iSZe =6 ; jSZe =6 ;
            iBe = 6; jBe =12 ;
        elseif(utils.etype(e) == 2 || utils.etype(e) == 3)
            iSNe =6 ; jSNe =24 ;
            iSZe =6 ; jSZe =6 ;
            iBe = 6; jBe =24 ;
        elseif(utils.etype(e) == 4)
            iSNe =6 ; jSNe =18 ;
            iSZe =6 ; jSZe =6 ;
            iBe = 6; jBe =18 ;
        end
        SNe = utils.presol.SNe(1:iSNe,1:jSNe,e);
        SZe = utils.presol.SZe(1:iSZe,1:jSZe,e);
        Be = utils.presol.Be(1:iBe,1:jBe,e);
        %Get edof
        edof_2d = utils.presol.edof_2d(1:mdim_2d,e);
    else
        %Defining constants to make equations readable
        nnpe_2d = utils.element(utils.etype(e)).nnpe_2d;
        mdim_2d = utils.element(utils.etype(e)).mdim_2d;
        
        %Interpolate element matrices
        [ SNe, SZe, Be ] = BECAS_IntegrateStrainDisplacementMatrices( utils, e, xxs, yys );
        
        %Assemble edof mapping array
        edof_2d=zeros(mdim_2d,1);
        for i=1:nnpe_2d
            for j=1:mdim_2d/nnpe_2d
                edof_2d(mdim_2d/nnpe_2d*(i-1)+j) = mdim_2d/nnpe_2d * (utils.el_2d(e,i+1)-1)+j;
            end
        end
    end
    
    %% Strains in global coordinate system
    GlobalElement(counter,:) = SZe*Ytheta + (Be*Xtheta(edof_2d))+ (SNe*dXtheta(edof_2d)) ;
    
    %% Rotate strains to material coordinate system
    MaterialElement(counter,:) = BECAS_RotateStressStrainComponents( utils, e, GlobalElement(counter,:), presolExist );
    
end

% Reorder to match material coordinate system
edof=[2 6 5 3 4 1];
MaterialElement(:,edof)=MaterialElement;


end

