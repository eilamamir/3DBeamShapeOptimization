function [ utils ] = BECAS_UtilsNoMessages( varargin )
%********************************************************
% File: BECAS_Utils.m
%   This function generates the Matlab structure utils. which holds all the
%   input data and a number of other useful constants and arrays. The data
%   structure utils. is present in most BECAS functions.
%
% Syntax:
%   [ utils ] = BECAS_Utils( options, variable_arguments )
%
% Input:
%   options.foldername:  foldername where the BECAS input files are located
%   options.etype:  Element type definition.
%   variable_arguments: requires at least 4 arguments to directly pass the
%       input arrays. In this case no input files are read:
%       nl_2d  : Matrix of nodal coordinates for cross section FE mesh
%       el_2d  : Matrix of element connectivity for cross section FE mesh
%       emat   : Matix of element material attribution
%       matprops : Matrix of material properties
%       failMat : Matrix with material failure properties (optional)
%
% Output:
%   utils.  :  Structure holding the following arrays.
%   .nl_2d  : Matrix of nodal coordinates for cross section FE mesh
%   .el_2d  : Matrix of element connectivity for cross section FE mesh
%   .emat   : Matix of element material attribution
%   .matprops : Matrix of material properties
%   .ne_2d  : Number of elements in the cross section FE mesh
%   .nn_2d  : Number of nodes in the cross section FE mesh
%   .etype  : Constant indicating element type
%   .nnpe_2d: Constant indicating the number of nodes per element in
%             the cross section FE mesh
%   .mdim_2d: Constant indicating the dimension of the element
%             stiffness matrix for the selected element type
%   .gpoints: Number of Gauss integration points to be used with
%             selected element type
%   .mapnn  : Constant indicating the total number of mapped nodes
%   .mapinputdata.el_2d : Matrix of mapped element connectivity for cross
%               section FE mesh
%   .mapel4mat: Matrix of mapped element order for material properties
%   .nmat   : Constant indicating the total number of materials in
%             matprop
%   .pr_2d  : Matrix holding the nodal positions for each element
%   .ElCent : Matrix holding the element centroids for all elements in
%             the FE mesh
%   .ElArea : Arrays holding the areas of each element in the cross
%             section FE mesh
%   .GQ     : Matrix with positions of Gauss points and respective weights
%   .iQ, .jQ, .vQ : Material constitutive matrix for each
%                   element in the cross section FE mesh
%                   stored in sparse format
%   .density: Material density at each element of the cross section
%             FE mesh
%   .deltaz : 3D slice element length for crack propagation
%   .nncf   : Node numbers to identify crack position using VCCT (nn crack
%             front, nn in front of crac side 1, nn in front of crack side
%             2)
%   .ecf    : Element number to identify crack position for crack
%             propagation using VCCT
%
% Calls:
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    20.09.2012   Jos� Pedro Blasques: the input is now the
%   structure inputdata. The inputdata.etype string variable has been
%   included. The new element type Q8R has been included.
%   Version 1.2    28.09.2012   Jos� Pedro Blasques: the BECAS_CheckInput
%   function has been included. The inputdata structure is eliminated and
%   the input is now only the foldername. The input files are now loaded in
%   this function. Header is now printed in this function.
%   Version 1.3    29.09.2012   Jos� Pedro Blasques: The input is now the
%   structure options. This is so that it is possible to control the
%   element type which was impossible in version 1.2.
%   Version 1.4    08.10.2012   Jos� Pedro Blasques: Fixed bug related to
%   checking etype.
%   Version 1.5    13.12.2012   Jos� Pedro Blasques: Included input for the
%   strength analysis routines FAILMAT.in.
%   Version 1.6    11.01.2013   Jos� Pedro Blasques: Introducing parameters
%   for crack analysis using VCCT
%   Version 1.7    15.01.2013   Vladimir Fedorov: A new format for material
%   strength characteristics
%   Version 1.8    08.05.2013   Jos� Pedro Blasques and Vladimir Fedorov:
%   Corrected the exist command so that it checks for the existence of
%   FAILMAT.in in the current directory and not on set pathes.
%   Version 1.9    17.10.2013   David R.S. Verelst: Added Octave
%   compatibility and variable input arguments to pass the input arrays
%   instead of reading them from the input files
%   Version 1.10    25.11.2013   Jos� Pedro Blasques: Included T6 elements.
%   Constants associated with each element are now defined in separate
%   files associated with each of the elements. The utils.gpoints now
%   indicates the total number of Gauss points. The Gauss points positions
%   and weights are now defined in element functions previously mentioned.
%   As a result it is possible to eliminate one of the gauss point loops in
%   the evaluation of the element stiffness matrices. Removed call to
%   BECAS_GaussQuad.
%   Version 1.11    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%   Version 1.12    29.10.2014   Jos� Pedro Blasques: Fixed how things were
%   working when specifying non sequential elements and node numbers. Now
%   the element and node numbers in the input files are only labels. The
%   user is then free to specify whatever order and number in all input
%   files. BECAS uses an internal numbering whcih is more convenient for
%   coding. The utils.mapel* is not used anymore. utils.elabel and
%   utils.nlabel are created. Also, etype is now a two column vector
%   [label,type] so that the order need not match that of E2D.in.
%   Version 1.13    11.11.2015   Jos� Pedro Blasques: Added functionalities
%   to control the output to HAWC2.
%   Version 1.14    06.07.2016   Jos� Pedro Blasques: Added the
%   functionalities associated with the fatigue damage analysis module.
%   Included a function to calculate Zg which is now stored in utils
%   instead of being calculated at different places in the code. Added the
%   new input csloads.
%
% (c) DTU Wind Energy
%********************************************************

%Print header
%BECAS_PrintHeader

%% Input
% First optional input argument always has to be options. Do this for
% backwards compatibility.
options = varargin{1};

%fprintf(1,'> Started building working arrays...');
%Manage folder names
originalFolder = pwd;
utils.foldername=options.foldername;

%Storing input data
%cd (utils.foldername)
% optionally do not load the input files if they are given as inputs
if nargin > 4
    npos = varargin{2};
    elconn = varargin{3};
    emat = varargin{4};
    utils.matprops = varargin{5};
    if nargin == 6
        utils.failMat = varargin{6};
    end
    if nargin == 7
        etype = varargin{7};
    end
    if nargin == 8
        edetail = varargin{8};
    end
    if nargin == 9
        utils.csloads = varargin{9};
    end    
    %Importdata is not implemented in octave, use load instead
elseif exist('OCTAVE_VERSION') ~= 0
    npos=load('N2D.in');
    elconn=load('E2D.in');
    emat=load('EMAT.in');
    utils.matprops=load('MATPROPS.in');
    if( exist('./FAILMAT.in','file')>0 )
        utils.failMat = BECAS_ParseFailMat(load('FAILMAT.in'));
    end
    if( exist('./ETYPE.in','file')>0 )
        etype = load('ETYPE.in');
        options.etype = 'file';
    end
    if( exist('./EDETAIL.in','file')>0 )
        edetail = load('EDETAIL.in');
    end
    if( exist('./LOADS.in','file')>0 )
        utils.csloads = load('LOADS.in');
    end    
else
    npos=importdata('N2D.in');
    elconn=importdata('E2D.in');
    emat=importdata('EMAT.in');
    utils.matprops=importdata('MATPROPS.in');
    if( exist('./FAILMAT.in','file')>0 )
        utils.failMat = BECAS_ParseFailMat(importdata('FAILMAT.in'));
    end
    if( exist('./ETYPE.in','file')>0 )
        etype = importdata('ETYPE.in');
        options.etype = 'file';
    end
    if( exist('./EDETAIL.in','file')>0 )
        edetail = importdata('EDETAIL.in');
    end
    if( exist('./LOADS.in','file')>0 )
        utils.csloads = importdata('LOADS.in');
    end
end
cd(originalFolder)

%Useful integers for 2D analysis
utils.ne_2d=size(elconn,1); %Number of elements
utils.nn_2d=size(npos,1); %Number of nodes
utils.nmat=size(utils.matprops,1); %Number of materials

%% Mapping node and element numbers and respective labels
%Element and node mapping
%Map node numbers
%TODO: check error messages, check paraview
%is returning the right node and element numbers.
% elconn = [1 4 7 5 8 0 ; 5 10 4 12 5 19];
% npos = [4 4 0;7 7 0;10 10 0;12 12 0;5 5 0;8 8 0;19 19 0;];

%Map element connectivity table
%Turn element connectivity table to vector
argin = elconn(:,2:end);
vecform = reshape(argin,[],1); %Turn into vector
%Find all zeros
idx_vecform_zeros = vecform==0;%Take out the zeros
%Find all nonzeros
idx_vecform_nonzeros = ~idx_vecform_zeros;
%Remove zeros so not to mess up the indexing
vecform_nonzeros = vecform(idx_vecform_nonzeros);
%Node numbering mapping from labels to internal
idxmap_nonzeros(unique(vecform_nonzeros))=1:size(unique(vecform_nonzeros),1);
%Determine vector using new numbering
aaa = idxmap_nonzeros(vecform_nonzeros);
%Put the zeros back
bbb = zeros(numel(vecform),1);
bbb(idx_vecform_nonzeros) = aaa;
%Reshape back to matrix
argout = reshape(bbb,[],size(argin,2)); %Turn back into matrix
%Store element connectivity table using internal numbering for elements and
%nodes
utils.el_2d = [(1:size(elconn,1))' argout];
%Store element labels
utils.elabel = elconn(:,1);
%Element mapping from labels to internal
utils.mapen_labls2int(elconn(:,1),1)=utils.el_2d(:,1);

%Nodal positions
mapnn = idxmap_nonzeros(npos(:,1));
[B,IX] = sort(mapnn);
utils.nl_2d = [mapnn(IX)' npos(IX,2:end)];
%Nodal labels
utils.nlabel = npos(IX,1);
%Sotre nodal mapping from labels to internal
utils.mapnn_labls2int(:,1) = idxmap_nonzeros;

%Material properties
%Check if ordering is the same as emat
if isequal(emat(:,1),utils.elabel)
    utils.emat = emat;
else
    %Determine idx for sorting element labels in ascending order
    [ascend_elabel, idx_elabel] = sort(utils.elabel);
    %Determine idx for sorting emat element labels in ascending order
    [ascend_emat, idx_emat] = sort(emat(:,1));
    %Check that the same element labels exist in both
    if (ascend_elabel ~= ascend_emat)
        error('something:anything','Error in EMAT.in: some elements in EMAT.in are not defined in E2D.in' );
    end
    %Order emat according to ascend_emat order of label number
    emat_sorted = emat(idx_emat,:);
    %Reorder emat_sorted to the order of the labels
    utils.emat = emat_sorted(idx_elabel,:);
end

%Element type list
if exist('etype')
    %Check if ordering is the same as emat
    if isequal(etype(:,1),utils.elabel)
        utils.type = etype(:,2);
    else
        %Determine idx for sorting element labels in ascending order
        [ascend_elabel, idx_elabel] = sort(utils.elabel);
        %Determine idx for sorting emat element labels in ascending order
        [ascend_etype, idx_etype] = sort(etype(:,1));
        %Check that the same element labels exist in both
        if ~isequal(ascend_elabel,ascend_etype)
            error('something:anything','Error in ETYPE.in: some elements in ETYPE.in are not defined in E2D.in' );
        end
        %Order emat according to ascend_emat order of label number
        emat_sorted = etype(idx_emat,:);
        %Reorder emat_sorted to the order of the labels
        utils.etype = etype_sorted(idx_elabel,2);
    end
end

%Detail elements
if exist('edetail')
    %Find if all elements in detail exist in the element connect. table
    [lia, lib]=ismember(edetail,utils.elabel);
    if all(lia)
        utils.edetail = utils.mapen_labls2int(edetail);
    else
        error('something:anything','Error in EDETAIL.in: some elements in EDETAIL.in are not defined in E2D.in' );
    end
end

%% Checks

% Check input
check = BECAS_CheckInput( options, utils );

%% Element properties
%Load element properties
%Q4
[ utils ] = BECAS_Q4_Utils( utils );
%Q8
[ utils ] = BECAS_Q8_Utils( utils );
%Q8R
[ utils ] = BECAS_Q8R_Utils( utils );
%T6
[ utils ] = BECAS_T6_Utils( utils );

%Finding maximum number of some element properties
utils.max_ngpoints = max([utils.element(:).gpoints]);
utils.max_nnpe_2d = max([utils.element(:).nnpe_2d]);
utils.max_mdim_2d = max([utils.element(:).mdim_2d]);

%Setting etype
if check.exist_etype %If defined by user and not input by file or array t
    if strcmp(options.etype,'Q4')
        %Quad4
        utils.etype(1:utils.ne_2d)=1;
    elseif strcmp(options.etype,'Q8')
        %Quad8
        utils.etype(1:utils.ne_2d)=2;
    elseif strcmp(options.etype,'Q8R')
        %Quad8 with reduced integration
        utils.etype(1:utils.ne_2d)=3;
    elseif strcmp(options.etype,'T6')
        %Quad8 with reduced integration
        utils.etype(1:utils.ne_2d)=4;
    end
else %Not defined by user and default is used based on ELIST file
    if(size(utils.el_2d,2)==5) %In case the user has not added zeros for the extra nodes
        %Quad4
        utils.etype(1:utils.ne_2d)=1;
    elseif(size(utils.el_2d,2)>5)
        utils.etype=zeros(utils.ne_2d,1);
        for e=1:utils.ne_2d
            if(utils.el_2d(e,6)==0) %In case the user has added zeros for the extra nodes
                %Quad4
                utils.etype(e)=1;
            else
                if(utils.el_2d(e,8)==0) %In case the user has added zeros for the extra nodes
                    %Tri6 with reduced integration
                    utils.etype(e)=4;
                else
                    %Quad8
                    utils.etype(e)=2;
                end
            end
        end
    end
end


%% Element area and centroids
%FIXME: This should not be here since. This is calculated again in a different
%way when the cross section properties are evaluated. The calculations give
% same result but the code is messy this way.

%Calculate centroid of cross section elements
[utils.ElCent]=BECAS_ElemCenter(utils);

%Calculate area of each element
[utils.ElArea]=BECAS_ElemArea(utils);

%% Crack propagation:
%Node numbers for crack propagation using VCCT
if isfield(options,'nncf')
    utils.nncf=utils.mapnn_labls2int(options.nncf);
end
%Element number for crack propagation using VCCT
if isfield(options,'ecf')
    utils.ecf=utils.mapen_labls2int(options.ecf);
end

%% Fatigue
fatigueExists = 0;
if isfield(options,'MeanCorrectionMethod')
    fatigueExists = 1;
    utils.fatigue.MeanCorrectionMethod = options.MeanCorrectionMethod;
else
    %warning('Missing options.fatigue.MeanCorrectionMethod. Setting MeanCorrectionMethod = NoMean. See documentation.');
    utils.fatigue.MeanCorrectionMethod = 'NoMean';
end


%% BECAS 3D
%Element length for crack propagation analysis
if isfield(options,'deltaz')
    utils.deltaz=options.deltaz;
end
%Number of element slices in the 3D model
if isfield(options,'ndiv')
    utils.ndiv=options.ndiv;
else
    utils.ndiv=1;
end

%% Output to HAWC2
%Set flag to control output to HAWC2
if isfield(options,'hawc2_beam')
    if strcmp(options.hawc2_beam,'iso')
        utils.hawc2_flag = 1;
    elseif strcmp(options.hawc2_beam,'aniso')
        utils.hawc2_flag = 0;
    else
        fprintf(1,'\n');
        warning('MyComponent:incorrectHAWC2flag',...
            'Unknown string for options.hawc2_version. Setting default options.hawc2_version=iso. See documentation.')
        utils.hawc2_flag = 0;
    end
else
    utils.hawc2_flag = 0;
end

%% Build Zg matrix which is used for building the system matrices
[ utils.Zg ] = BECAS_Zg( utils );

%% Material properties
%Generate element constitutive matrices according to local coordinate
%system
[ utils.Q, utils.Qm, utils.density ] = BECAS_RotateElementMaterialConstMatrix(utils);

%% Other
%Store nodal positions for each element in a vector
[utils.pr_2d]=BECAS_ReorderNodalPositions(utils);

%fprintf(1,'DONE! \n');


end




