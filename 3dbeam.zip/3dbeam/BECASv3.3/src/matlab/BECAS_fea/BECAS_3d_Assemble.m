function [ M, C, E, R, L, A, D ] = BECAS_3d_Assemble( Kgs, utils )
%********************************************************
% File: BECAS_3D_Assemble.m
%   Function to assemble the global 2D finite element matrices
%   associated with the determination of the cross section
%   stiffness matrix.
%
% Syntax:
%   [ M, C, E, R, L, A, D ] = BECAS_3D_Assemble( Kgs, utils )
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
% Output:
%   A       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   R       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   L       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   M       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   C       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   E       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   D       :  Sub-matrix of cross section equilibrium equations
%              holding the constraint equations (see Documentation)
% Calls:
%
% Date:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 2.0    04.07.2013   Jos� Pedro Blasques: Corrected the 
%   definition of the C and R matrices. Matrices have been validated 
%   against BECAS 2D. 
%
% (c) DTU Wind Energy
%********************************************************

%Build auxiliary matrices based on 3D FE global stiffness matrix
K11=sparse(Kgs(1:utils.nn_3d/2*3,1:utils.nn_3d/2*3));
K22=sparse(Kgs(utils.nn_3d/2*3+1:utils.nn_3d/2*3*2,utils.nn_3d/2*3+1:utils.nn_3d/2*3*2));
K12=sparse(Kgs(1:utils.nn_3d/2*3,utils.nn_3d/2*3+1:utils.nn_3d/2*3*2));
K21=sparse(K12');

%Build BECAS matrices based on auxiliary matrices
M=sparse(( (K11+K22) - 2*(K12+K21) )*utils.deltaz/6);
C=sparse(1/2*( (K11-K22) - (K12-K21) ));
E=sparse((K11 + K22 + K12 + K21)*1/utils.deltaz);

%Build remaining BECAS matrices
R=-sparse(C*utils.Zg);
L=sparse(M*utils.Zg);
A=sparse(utils.Zg'*M*utils.Zg);

C=-C';

%Constraint matrices
[ D ] = BECAS_ConstraintMatrix( utils );

end