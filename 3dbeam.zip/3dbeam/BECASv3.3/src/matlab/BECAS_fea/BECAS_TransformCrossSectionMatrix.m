function [ M ] = BECAS_TransformCrossSectionMatrix( M, p, alpha )
%********************************************************
% File: BECAS_TransformationMat.m
%   Function to rotate and translate cross section consitutive matrices.
%
% Syntax:
%   [ M ] = BECAS_TransformCrossSectionMatrix( M, p, alpha )
%
% Input:
%   M    :  Cross section constitutive matrix
%   p    :  Translation vector
%   alpha:  Angle of rotation
%
% Output:
%   M    :  Rotated and translated matrix
%
% Calls:
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    21.01.2013   Jos� Pedro Blasques: introduced functions
%   BECAS_TranslationMatrix and BECAS_RotationMatrix to improve
%   portability.
%
% (c) DTU Wind Energy
%********************************************************

%Matrix translation
[ T2 ] = BECAS_CrossSectionTranslationMatrix( p );

%Translation operation
M=T2'*M;M=M*T2;

%Matrix rotation
[ R1 ] = BECAS_CrossSectionRotationMatrix( alpha );

%Rotation operation
M=R1*M*R1';

end