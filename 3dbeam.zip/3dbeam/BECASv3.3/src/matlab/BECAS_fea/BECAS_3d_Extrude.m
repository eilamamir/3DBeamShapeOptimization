function [ utils ] = BECAS_3d_Extrude( utils )

%Meshgen - 3D mesh generator by extrusion of 2D mesh for BECAS

%Mesh size
%Beam geometry
xmax = max(utils.nl_2d(:,2));
xmin = min(utils.nl_2d(:,2));
ymax = max(utils.nl_2d(:,3));
ymin = min(utils.nl_2d(:,3));
csW = xmax-xmin;          %CS width, m
csH = ymax-ymin;          %CS height, m
%Beam discretization
enW = sqrt(utils.ne_2d);          %Number of elements along the CS width
enH = sqrt(utils.ne_2d);          %Number of elements along the CS height
%Beam dimensions, m [CS width, CS height, beam length]
dim3D   = abs([csW, csH, utils.deltaz]);
%Beam discretization [CS enX, CS enY, beam enL]
discr3D = abs([enW, enH, utils.ndiv]);

%Extrude square mesh
if utils.etype_3d(1) == 1 || utils.etype_3d(1) == 3
        mesh3D = BECAS_Gen3dMeshS8(utils.rho_3d, dim3D, discr3D, utils.nl_2d(:,2:end)');
elseif utils.etype_3d(1) == 4
        mesh3D = BECAS_Gen3dMeshS12(utils.rho_3d, dim3D, discr3D);
elseif utils.etype_3d(1) == 2
        mesh3D = BECAS_Gen3dMeshS20(utils.rho_3d, dim3D, discr3D);
end;
utils.nl_3d = [ [1:size(mesh3D.nodes,2)]' mesh3D.nodes'];
utils.nn_3d = size(mesh3D.nodes,2);
utils.el_3d = [ [1:size(mesh3D.elements,2)]' mesh3D.elements'];
utils.ne_3d = size(mesh3D.elements,2);

if utils.etype_3d(1) == 1 || utils.etype_3d(1) == 3
    for i = 1:utils.sec_const.nsec
        utils.sec_const.nl_3d{i} = mesh3D.sec_const.nl_3d{utils.sec_const.ind_ndiv(i)};
    end
elseif utils.etype_3d(1) == 4 || utils.etype_3d(1) == 2
    for i = 1:utils.sec_const.nsec
        utils.sec_const.nl_3d{i} = mesh3D.sec_const.nl_3d{utils.sec_const.ind_ndiv(i)*2-1};
    end
end

utils.sec_const.nl_3d_corner = mesh3D.sec_const.nl_3d_corner;

%Extrude general mesh
% if utils.etype_3d(1) == 1 || utils.etype_3d(1) == 3
%     [ utils ] = BECAS_3d_Extrude_S8( utils );
% elseif utils.etype_3d(1) == 2
%     [ utils ] = BECAS_3d_Extrude_S20( utils );
% end

%Extrude material properties
utils.Q=repmat(utils.Q,1,1,utils.ndiv);
utils.Qm=repmat(utils.Qm,1,1,utils.ndiv);

%Reorganize nodal positions - 3D
utils.pr_3d=zeros((utils.max_nnpe_3d-1)*2+2,utils.ne_3d);
for ii=1:utils.ne_3d
    for i=1:utils.element(utils.element(utils.etype_3d(ii)).etype).nnpe_3d
        utils.pr_3d((i-1)*3+1:(i-1)*3+3,ii)=utils.nl_3d(utils.el_3d(ii,i+1),2:4);
    end
end


end


