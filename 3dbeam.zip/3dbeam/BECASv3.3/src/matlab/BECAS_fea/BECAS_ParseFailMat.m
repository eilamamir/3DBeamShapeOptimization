function [failMat] = BECAS_ParseFailMat( failMatArray )
%Function parsing array of material strength parameters. It is only called
%in BECAS_Utils.m .
% Input:
%   failMatArray  : Raw array of material parameters
% Output:
%   failMat.  : Array [1 x nMat] of structures of material parameters
%     .fcFlag - Flag of failure criterion
%     .st     - Tensile strengths, [1x3]
%     .t      - Shear strength, [1x3]
%     .sc     - Compressive strengths, [1x3]
%     .et     - Maximum tensile strains, [1x3]
%     .g      - Maximum shear strains, [1x3]
%     .ec     - Maximum compressive strains, [1x3]
%     .m      - slope SN curve for fatigue calculations, [1x3]
%
% Revisions:
%
% version 0.1:  08.05.2013 Jos� Pedro Blasques: Moved this function which
% was part of BECAS_Utils to here as a separate function.
% version 1.0:  15.07.2013 Jos� Pedro Blasques: added fix -abs(sc) to
% guarantee that the compressive strength values are always negative. This
% ensures that the Tsai-Wu failure criteria expression returns correct
% results.
% version 1.1:  05.07.2016 Jos� Pedro Blasques: Added the fatigue damage
% analysis parameters
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Number of materials given
nMat = size(failMatArray,1);

%Material property initialization
failMat(1:nMat) = ...
    struct('fcFlag',0, 'st',[0;0;0], 't',[0;0;0] ,'sc',[0;0;0], 'et',[0;0;0], ...
    'g',[0;0;0], 'ec',[0;0;0], 'm',0 , 'smp',0, 'K',0 );

%Checking if max. strain parameters are input
isStrainsInput = size(failMatArray, 2) > 11;
%Info message if they are missing
if ~isStrainsInput
    fprintf(1,'\n');
    fprintf(1,'INFO Message from BECAS_Utils: \n')
    fprintf(1,'Max. strain material parameters are propabibly missing...Continuing...');
end;

%Checking if max. strain parameters are input
isFatigueInput = size(failMatArray, 2) >19;
%Info message if they are missing
if ~isFatigueInput
    fprintf(1,'\n');
    fprintf(1,'INFO Message from BECAS_Utils: \n')
    fprintf(1,'Fatigue damage material parameters are propabibly missing...Continuing...');
end;

%Parsing data for each material
for matNo = 1:nMat
    %failure criterion flag
    failMat(matNo).fcFlag = failMatArray(matNo,1);
    
    %Tensile strengths
    failMat(matNo).st = failMatArray(matNo, 2:4);
    %Shear strengths
    failMat(matNo).t = failMatArray(matNo, 5:7);
    %Compressive strengths
    failMat(matNo).sc = -abs(failMatArray(matNo, 8:10));
    
    %Skipping strains if they are not input
    if isStrainsInput
        %Maximum tensile strains
        failMat(matNo).et = failMatArray(matNo, 11:13);
        %Maximum shear strains
        failMat(matNo).g = failMatArray(matNo, 14:16);
        %Maximum compressive strains
        failMat(matNo).ec = -abs(failMatArray(matNo, 17:19));
    end
    %Skipping fatigue damage parameters if they are not input
    if isFatigueInput
        %Slope SN curve
        failMat(matNo).m = failMatArray(matNo, 20);
        %Mean stress at peak of CLD
        failMat(matNo).smp = failMatArray(matNo, 21);
        %Curve fitting parameter
        failMat(matNo).K = failMatArray(matNo, 22);
    end
end;

end