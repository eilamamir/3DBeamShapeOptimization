function [ GlobalGauss, MaterialGauss ] = BECAS_CalcStressesGaussPoints( strain, utils )
%********************************************************
% File: BECAS_CalcStressesGaussPoints
%   Function to calculate the stresses at Gauss points for given strain 
%   results.
%
% Syntax:
%   [ GlobalGauss, MaterialGauss ] = 
%    BECAS_CalcStressesGaussPoints( strain, utils )
%
% Input:
%   strain : Structure with strain values calculated at element centers and
%            Gauss points as given by BECAS_RecoverStrains.
%   utils  : Structure with input data, useful arrays, and constants.
%
% Output:
%   GlobalGauss : (ne,(6*GaussPoints)) array of stresses at Gauss points in
%                  the global coordinate system.
%   MaterialGauss : (ne,(6*GaussPoints)) array of stresses Gauss points in 
%                    the material coordinate system.
%
% Order of Gauss points
% Q4
% -----------
% | 2     4 |
% |         |
% | 1     3 |
% -----------
% Q8
% -----------
% | 3  6  9 |
% | 2  5  8 |
% | 1  4  7 |
% -----------
%
% Calls:
%
% Date:
%   Version 1.0    21.09.2012   Jos� Pedro Blasques
%   Version 1.1    01.10.2012   Jos� Pedro Blasques: Corrected a bug
%   associated with the reordering of the material constitutive matrix when
%   determining the stresses in the local coord. sys..
%   Version 1.3    21.10.2013   Jos� Pedro Blasques: Added the possibility
%   doing the calculations only for a small portion of the elements defined
%   in the list util.edetail.
%   Version 1.2    25.11.2013   Jos� Pedro Blasques: removed one of the
%   loops on the gauss points which now are defined in BECAS_Utils.
%   Version 1.3    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
end

%% Initialize variables
GlobalGauss=zeros(ne_2d,6*utils.max_ngpoints);
MaterialGauss=zeros(ne_2d,6*utils.max_ngpoints);

%Mapping from global to material coord. sys. because that is the coord. 
% sys. in which the strains are given
edof=[2 6 5 3 4 1];

for counter=1:ne_2d
    e=el_2d(counter);
    
    %Defining constants to make equations readable
    gpoints = utils.element(utils.etype(e)).gpoints;
    
    %% Build material constitutive matrices
    %Build material constitutive matrix in global coordinate system
    Qe_global=utils.Q(:,:,e);
    %Build material constitutive matrix in local coordinate system
    Qe_material=utils.Qm(:,:,e);
    %Reordering to match strains in material coordinate system
    Qe_material(edof,edof)=Qe_material;
    
    %% Stresses at gauss points
    %Stack material constitutive matrices
    if(utils.etype(e) == 1 || utils.etype(e) == 3)
        Qng_global=blkdiag(Qe_global,Qe_global,Qe_global,Qe_global);
        Qng_material=blkdiag(Qe_material,Qe_material,Qe_material,Qe_material);
    elseif(utils.etype(e) == 2)
        Qng_global=blkdiag(...
            Qe_global,Qe_global,Qe_global,...
            Qe_global,Qe_global,Qe_global,...
            Qe_global,Qe_global,Qe_global);
        Qng_material=blkdiag(...
            Qe_material,Qe_material,Qe_material,...
            Qe_material,Qe_material,Qe_material,...
            Qe_material,Qe_material,Qe_material);
    elseif(utils.etype(e) == 4)
        Qng_global=blkdiag(...
            Qe_global,Qe_global,Qe_global,...
            Qe_global,Qe_global,Qe_global,...
            Qe_global);
        Qng_material=blkdiag(...
            Qe_material,Qe_material,Qe_material,...
            Qe_material,Qe_material,Qe_material,...
            Qe_material);
    end
    
    %Gauss point stresses in global coordinate system
    GlobalGauss(counter,1:gpoints*6)=Qng_global*strain.GlobalGauss(counter,1:gpoints*6)';
    %Gauss point stresses in material coordinate system
    MaterialGauss(counter,1:gpoints*6)=Qng_material*strain.MaterialGauss(counter,1:gpoints*6)';
    
end


end