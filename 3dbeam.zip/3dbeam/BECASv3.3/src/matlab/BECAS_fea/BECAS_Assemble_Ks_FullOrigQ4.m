function [ K, G, H ] = BECAS_Assemble_Ks_FullOrigQ4( varargin )
%********************************************************
% File: BECAS_Assemble_Ks_FullOrig.m
%   Function to assemble the global 2D finite element matrices
%   associated with the determination of the cross section
%   stiffness matrix.
%   based on the BECAS code from DTU wind energy
%   and the paper: "Multi Material Topology Optimization of Laminated
%   Composite Beam Cross Sections by J.P. Blasques and M. Stolpe
% Syntax:
%   [ K, G, H ] = BECAS_Assemble_Ks_FullOrig( utils )
% The syntax is folowing the exact definitions from the paper. Rather than
% the official BECAS libraries which provide K11, G22 and H. Tough, H is
% provided as well to be consistent with the rest of the BECAS sub
% routines.
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
% Output:
%% Calls:
% K - the stiffness matrix of the unit loading problem required to find
% unit displacements: W
% G - Submatrix used to calculate the compliance matrix Fs
% H - A sub matrix used for calculating W in the BECAS format
%********************************************************

%% Initialization
%Store utils structure
utils = varargin{1};

% %Initialize arrays and vectors for sparse storage
% %MEC
% nMECsum=0;
% nSECsum = 0;
% for e=1:utils.ne_2d
%     nMECsum = nMECsum + (utils.element(utils.etype(e)).mdim_2d)^2;
%     nSECsum = nSECsum + (utils.element(utils.etype(e)).mdim_2d)*6;
% end
% iMEC=zeros(nMECsum,1);
% iSEC = zeros(nSECsum,1);
% jMEC=zeros(nMECsum,1);
% jSEC = zeros(nSECsum,1);
% vM=zeros(nMECsum,1);
% vE=zeros(nMECsum,1);
% vC=zeros(nMECsum,1);
% vR = zeros(nSECsum,1);
% vL = zeros(nSECsum,1);
% VA = zeros(nSECsum,1);

%% Call each element of the 2D FE mesh in turn
% indMEC=1;
% indSEC = 1;
ndof = utils.nn_2d*3;
Mg = zeros(ndof,ndof);
Eg = zeros(ndof,ndof);
Cg = zeros(ndof,ndof);
Rg = zeros(ndof,6);
Lg = zeros(ndof,6);
Ag = zeros(6);

for e=1:utils.ne_2d
    %Defining constants to make equations readable
    
    nnpe_2d = utils.element(utils.etype(e)).nnpe_2d;
    mdim_2d = utils.element(utils.etype(e)).mdim_2d;
    
    %Assemble material constitutive matrix for element e
    Qe=utils.Q(:,:,e);
    
    %Evaluate element matrices for the different element types
    %Build from presol
    %Build from element integration
    if(utils.etype(e) == 1)
        %[Me,Ee,Ce]  = BECAS_Q4(e,Qe,utils);
        [ Me, Ee, Ce, Re, Le, Ae ] = BECAS_Q4_AllSubMats( e, Qe, utils );
%     elseif(utils.etype(e) == 2 || ...
%             utils.etype(e) == 3)
%         [Me,Ee,Ce]  = BECAS_Q8(e,Qe,utils);
%     elseif(utils.etype(e) == 4)
%         [Me,Ee,Ce]  = BECAS_T6(e,Qe,utils);
    end
    
    %Build M,E, and C matrices
%     nMEC = mdim_2d^2;
%     nSEC = mdim_2d*6;
%     lenMEC = indMEC : indMEC + nMEC-1;
%     lenSEC = indSEC : indSEC + nSEC - 1;
    
    %Mapping from local to global DOF
    edof_2d=zeros(mdim_2d,1);
    for i=1:nnpe_2d
        for j=1:mdim_2d/nnpe_2d
            edof_2d(mdim_2d/nnpe_2d*(i-1)+j) = mdim_2d / nnpe_2d * (utils.el_2d(e,i+1)-1)+j;
        end
    end
    
    %Assemble i and j indices
%     onesM = ones(size(Me,1),1);
%     onesS = ones(size(Re,2),1);
%     [ma,na] = size(edof_2d); [mb,nb] = size(onesM);
%     kronRows = reshape( permute( reshape( onesM(:)*edof_2d(:).', [mb nb ma na] ), [1 3 2 4] ), [ma*mb na*nb] );
%     kronRowSE = onesS(:)*edof_2d(:).';
%     kronRowSE = kronRowSE(:);
%     %kronColSE = repmat(edof_2d(:)',[1,6])';
% 
%     
%     [ma,na] = size(edof_2d); [mb,nb] = size(onesM');
%     kronCols = reshape( permute( reshape( onesM(:)*edof_2d(:).', [mb nb ma na] ), [1 3 2 4] ), [ma*mb na*nb] );
%     
%     iMEC(lenMEC) = reshape(kronRows,nMEC,1);
%     iSEC(lenSEC) = reshape(kronRowSE,nSEC,1);
%     jMEC(lenMEC) = reshape(kronCols,nMEC,1);
%     %jSEC = repmat([1:6]',nSEC,1);
%     
%     %Assemble v values
%     vM(lenMEC) = reshape(Me,nMEC,1);
%     vE(lenMEC) = reshape(Ee,nMEC,1);
%     vC(lenMEC) = reshape(Ce,nMEC,1);
%     
%     vR(lenSEC) = reshape(Re,nSEC,1);
%     vL(lenSEC) = reshape(Le,nSEC,1);
% 
%     %Advance the index according to the number of entries in current
%     %element matrix - set for handling multiple element types
%     indMEC = indMEC + nMEC;
%     indSEC = indSEC + nSEC;
    
    Mg(edof_2d,edof_2d) = Mg(edof_2d,edof_2d) + Me;
    Eg(edof_2d,edof_2d) = Eg(edof_2d,edof_2d) + Ee;
%     Cg(edof_2d,edof_2d) = Cg(edof_2d,edof_2d) + Ce';
    Cg(edof_2d,edof_2d) = Cg(edof_2d,edof_2d) + Ce;
    
    Rg(edof_2d,:) = Rg(edof_2d,:) + Re;
    Lg(edof_2d,:) = Lg(edof_2d,:) + Le;
    Ag = Ag + Ae;
end

%% Assemble global matrices
% Mg=sparse(iMEC,jMEC,vM);
% Eg=sparse(iMEC,jMEC,vE);
% Cg=sparse(iMEC,jMEC,vC);
% 
% %Build remaining A, R and L matrices
 Rgg=sparse(Cg'*utils.Zg);
% Lg=sparse(Mg*utils.Zg);
% Ag=sparse(utils.Zg'*Mg*utils.Zg);

%Build constraint matrix
Dg = sparse(utils.Zg');

%% Build block matrices
%Ensure symmetry
Eg=(Eg+Eg')./2;
Ag=(Ag+Ag')./2;
Mg=(Mg+Mg')./2;

%Auxiliary constants
nEx=size(Eg,1);

%Block matrices
% K = [K11, K12; 0, K11]
% K12 = H^T-H
% G = [K11, 0; K12^T, K11]

K11 = [Eg ,  Rg     ,     Dg';
       Rg',  Ag     ,     zeros(6);
       Dg , zeros(6),     zeros(6)];

K12 = [Cg' - Cg    ,    -Lg ,zeros(nEx,6);
       Lg'         ,zeros(6),zeros(6)    ;
       zeros(6,nEx),zeros(6),zeros(6)    ];

G11 = [Eg ,  Rg     ,     zeros(nEx,6);
       Rg',  Ag     ,     zeros(6);
       zeros(6,nEx) , zeros(6),     zeros(6)];

G12 = [Cg          ,    Lg ,zeros(nEx,6);
       Lg'         ,zeros(6),zeros(6)    ;
       zeros(6,nEx),zeros(6),zeros(6)    ];   

G22=[Mg          ,  zeros(nEx,6), zeros(nEx,6);
     zeros(6,nEx),  zeros(6)    , zeros(6)    ;
     zeros(6,nEx),  zeros(6)    , zeros(6)    ];
 
 K = [K11,K12;zeros(nEx+12),K11];
 G = [G11,G12;G12',G22];

H = [Cg           Lg        zeros(nEx,6);
    zeros(6,nEx) zeros(6) zeros(6);
    zeros(6,nEx) zeros(6) zeros(6)];


end

