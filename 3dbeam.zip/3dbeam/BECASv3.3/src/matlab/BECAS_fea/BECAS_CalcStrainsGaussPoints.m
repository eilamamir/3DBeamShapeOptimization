function [ GlobalGauss, MaterialGauss ] = ...
    BECAS_CalcStrainsGaussPoints(theta0,solutions,utils)
%********************************************************
% File: BECAS_CalcStrainsGaussPoints
%   Function to calculate the strains at Gauss points for a given load
%   (forces and moments) vector.
%
% Syntax:
%   [ GlobalGauss, MaterialGauss ] = ...
%    BECAS_CalcStrainsGaussPoints(theta0,solutions,utils)
%
% Input:
%   theta0  :  1x6 Load (forces and moments) vector
%   solutions : Structure containing the warping solutions arrays X, Y, dX
%               and dY returned by BECAS_Constitutive_Ks
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   strain.GlobalGauss : (ne,(6*GaussPoints)) array of strains at Gauss
%                        points in the global coordinate system.
%   strain.MaterialGauss : (ne,(6*GaussPoints)) array of strains Gauss
%                          points in the material coordinate system.
%
% Order of Gauss points
% Q4
% -----------
% | 2     4 |
% |         |
% | 1     3 |
% -----------
% Q8
% -----------
% | 3  6  9 |
% | 2  5  8 |
% | 1  4  7 |
% -----------
% T6
% 5
% | \
% 6  4
% | 7 \
% 1--2--3
%
% Calls:
%
% Date:
%   Version 1.0    21.09.2012   Jos� Pedro Blasques
%   Version 1.1    01.10.2012   Jos� Pedro Blasques: corrected a bug
%   related to the way the strains in the local coordinate system were
%   being reordered to match the local coordinate system.
%   Version 1.2    24.10.2012   Jos� and Robert: Corrected material
%   rotation. Finally it is right!
%   Version 1.3    21.10.2013   Jos� Pedro Blasques: Added the possibility
%   doing the calculations only for a small portion of the elements defined
%   in the list util.edetail.
%   Version 1.3    25.11.2013   Jos� Pedro Blasques: removed one of the
%   loops on the gauss points which now are defined in BECAS_Utils.
%   Version 1.4    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
end

%% Initialize variables
%Nodal strains
GlobalGauss=zeros(ne_2d,6*utils.max_ngpoints);
MaterialGauss=zeros(ne_2d,6*utils.max_ngpoints);

%Pre multiply the warping by the load vector
Xtheta=full(solutions.X*theta0');
dXtheta=full(solutions.dX*theta0');
Ytheta=full(solutions.Y*theta0');

%% Evaluate nodal strains
for counter=1:ne_2d
    e=el_2d(counter);
    
    %Defining constants to make equations readable
    nnpe_2d = utils.element(utils.etype(e)).nnpe_2d;
    mdim_2d = utils.element(utils.etype(e)).mdim_2d;    
    gpoints = utils.element(utils.etype(e)).gpoints;
    
    %% Assemble edof mapping array
    edof_2d=zeros(mdim_2d,1);
    for i=1:nnpe_2d
        for j=1:mdim_2d/nnpe_2d
            edof_2d(mdim_2d/nnpe_2d*(i-1)+j) = mdim_2d /nnpe_2d * (utils.el_2d(e,i+1)-1)+j;
        end
    end
    %% Build rotation matrices
    %Fiber and fiber plane rotation matrices
    [ f_rot ] = BECAS_FiberRotationMatrix( utils.emat(e,3) );
    [ p_rot ] = BECAS_FiberPlaneRotationMatrix( utils.emat(e,4) );
    
    %% Loop gauss points
    for v=1:gpoints     %Iterate gauss points along the length
        xxs = utils.element(utils.etype(e)).xxg(v);    %X position of Gauss point
        yys = utils.element(utils.etype(e)).yyg(v);    %Y position of Gauss point
        if(utils.etype(e) == 1)
            [ xxb, yyb ] = BECAS_Q4_InterpPos( utils.pr_2d(:,e), xxs, yys );
            %Evaluate Jacobian - 2D
            [ iJ, detJ ] = BECAS_Q4_Jacobian( xxs, yys, utils.pr_2d(:,e) );
            %Evaluate the element matrices
            [ SNe ] = BECAS_Q4_SNe( xxs, yys );
            [ SZe ] = BECAS_Q4_SZe( xxb, yyb );
            [ Be ] = BECAS_Q4_Be( xxs, yys, iJ );
        elseif(utils.etype(e) == 2 || utils.etype(e) == 3)
            %Nodal coordinates of cross section element in cross section
            %coordinate system
            [ xxb, yyb ] = BECAS_Q8_InterpPos( utils.pr_2d(:,e), xxs, yys );
            %Evaluate Jacobian - 2D
            [ iJ, detJ ] = BECAS_Q8_Jacobian( xxs, yys, utils.pr_2d(:,e) );
            %Evaluate the element stiffness matrices
            [ SNe ] = BECAS_Q8_SNe( xxs, yys );
            [ SZe ] = BECAS_Q8_SZe( xxb, yyb );
            [ Be ] = BECAS_Q8_Be( xxs, yys, iJ );
        elseif(utils.etype(e) == 4)
            %Nodal coordinates of cross section element in cross section
            %coordinate system
            [ xxb, yyb ] = BECAS_T6_InterpPos( utils.pr_2d(:,e), xxs, yys );
            %Evaluate Jacobian - 2D
            [ iJ, detJ ] = BECAS_T6_Jacobian( xxs, yys, utils.pr_2d(:,e) );
            %Evaluate the element stiffness matrices
            [ SNe ] = BECAS_T6_SNe( xxs, yys );
            [ SZe ] = BECAS_T6_SZe( xxb, yyb );
            [ Be ] = BECAS_T6_Be( xxs, yys, iJ );
        end
        
        %% Strains in global coordinate system
            GlobalGauss(counter,1+(v-1)*6:6+(v-1)*6)=SZe*Ytheta+Be*Xtheta(edof_2d)+SNe*dXtheta(edof_2d);
        
        %% Strains in local coordinate system
        %Rotate stresses
        StrainMat=horzcat(...
                [ GlobalGauss(counter,1+(v-1)*6); 0.5*GlobalGauss(counter,3+(v-1)*6); 0.5*GlobalGauss(counter,4+(v-1)*6) ],...
                [ 0.5*GlobalGauss(counter,3+(v-1)*6); GlobalGauss(counter,2+(v-1)*6); 0.5*GlobalGauss(counter,5+(v-1)*6) ],...
                [ 0.5*GlobalGauss(counter,4+(v-1)*6); 0.5*GlobalGauss(counter,5+(v-1)*6); GlobalGauss(counter,6+(v-1)*6) ]);
        StrainMat=p_rot*StrainMat*p_rot';
        StrainMat=f_rot*StrainMat*f_rot';
        %Stresses in local coordinate system
            MaterialGauss(counter,1+(v-1)*6:6+(v-1)*6)=...
            [ StrainMat(1,1) StrainMat(2,2) 2*StrainMat(1,2)...
            2*StrainMat(1,3) 2*StrainMat(2,3) StrainMat(3,3)]';
        
    end
end

%Reorder to match material coordinate system
edof=[2 6 5 3 4 1];
gmmap=[];
for i=1:utils.max_ngpoints
    gmmap=[gmmap edof+(i-1)*6];
end
MaterialGauss(:,gmmap)=MaterialGauss;

end
