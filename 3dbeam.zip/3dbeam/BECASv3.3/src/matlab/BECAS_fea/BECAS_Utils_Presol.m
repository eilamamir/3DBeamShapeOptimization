function [ utils ] = BECAS_Utils_Presol( utils, options )
%BECAS_FATIGUE_UTILS Summary of this function goes here
%   Detailed explanation goes here

%Check if calculating only for detail
if isfield(utils,'edetail')
    ne_2d=size(utils.edetail,1);
    el_2d=utils.edetail;
else
    ne_2d=utils.ne_2d;
    el_2d=utils.el_2d(:,1);
end

%Initialize variables (setting to the maximum matrix size)
utils.presol.SNe = zeros(6,24,utils.ne_2d);
utils.presol.SZe = zeros(6,6,utils.ne_2d);
utils.presol.Be = zeros(6,24,utils.ne_2d);
utils.presol.f_rot = zeros(3,3,utils.ne_2d);
utils.presol.p_rot = zeros(3,3,utils.ne_2d);
utils.presol.edof_2d=zeros(24,utils.ne_2d);
utils.presol.fp_rot = zeros(3,3,utils.ne_2d);

%Gauss point position
xxs=0;
yys=0;

for counter=1:ne_2d
    e=el_2d(counter);
    
    %Defining constants to make equations readable
    nnpe_2d = utils.element(utils.etype(e)).nnpe_2d;
    mdim_2d = utils.element(utils.etype(e)).mdim_2d;
    
    %Finding the size of matrices FIXME: only working for meshes with all
    %elements of the same type
    if(utils.etype(e) == 1)
        iSNe =6; jSNe =12;
        iSZe =6; jSZe =6;
        iBe = 6; jBe =12;
    elseif(utils.etype(e) == 2 || utils.etype(e) == 3)
        iSNe =6; jSNe =24;
        iSZe =6; jSZe =6;
        iBe = 6; jBe =24;
    elseif(utils.etype(e) == 4)
        iSNe =6; jSNe =18;
        iSZe =6; jSZe =6;
        iBe = 6; jBe =18;
    end
    
    %Evaluate strain displacement matrices
    [ utils.presol.SNe(1:iSNe,1:jSNe,e), utils.presol.SZe(1:iSZe,1:jSZe,e), utils.presol.Be(1:iBe,1:jBe,e) ] = ...
        BECAS_IntegrateStrainDisplacementMatrices( utils, e, xxs, yys );
    
    %Evaluate rotation matrices
    [ utils.presol.f_rot(:,:,e) ] = BECAS_FiberRotationMatrix( utils.emat(e,3) );
    [ utils.presol.p_rot(:,:,e) ] = BECAS_FiberPlaneRotationMatrix( utils.emat(e,4) );
    utils.presol.fp_rot(:,:,e) = utils.presol.f_rot(:,:,e)*utils.presol.p_rot(:,:,e);
    
    %build edof
    for i=1:nnpe_2d
        for j=1:mdim_2d/nnpe_2d
            utils.presol.edof_2d(mdim_2d/nnpe_2d*(i-1)+j,e) = mdim_2d /nnpe_2d * (utils.el_2d(e,i+1)-1)+j;
        end
    end
    
end

end

