function [ Q_prime ] = BECAS_RotateStressStrainComponents( utils, e, Q, presolExist )

% Build rotation matrices
if presolExist
    fp_rot = utils.presol.fp_rot(:,:,e);
else
    [ f_rot ] = BECAS_FiberRotationMatrix( utils.emat(e,3) );
    [ p_rot ] = BECAS_FiberPlaneRotationMatrix( utils.emat(e,4) );
    fp_rot = f_rot*p_rot;
end

% Rotate strains to material coordinate system
StrainTensor = reshape([Q(1) 0.5*Q(3) 0.5*Q(4) 0.5*Q(3) Q(2) 0.5*Q(5) 0.5*Q(4) 0.5*Q(5) Q(6)] , 3, 3);
StrainTensor=(fp_rot*StrainTensor)*fp_rot';

% Strains in material coordinate system
Q_prime=[...
    StrainTensor(1,1) StrainTensor(2,2) 2*StrainTensor(1,2)...
    2*StrainTensor(1,3) 2*StrainTensor(2,3) StrainTensor(3,3)];

end