function [ G, Grot ] = BECAS_VCCT( disp, forces, utils )
%********************************************************
% File: BECAS_VCCT.m
%   Function to calculate strain energy release rate at a given node using
%   the Virtual Crack Closure Technique.
%
% Syntax:
%   [ G ] = BECAS_VCCT( disp, forces, utils )
%
% Input:
%  disp - (ndof x 1) vector of nodal displacements (typically U*theta).
%  forces - (ne x nnpe*3) vector of internal nodal forces at each element
%  as calculated by BECAS_CalcNodalForces.
%  utils - structure holding general input and useful arrays.
%
% Output:
% G - (3x1) array with GI, GII, and GIII strain energy release rates.
%
% Revisions:
%   Version 1.0    23.09.2014   Jos� Pedro Blasques
%   Version 1.1    30.09.2014   Jos� Pedro Blasques: strain energy release
%   rates are now evaluated in the crack coordinate system.
%
% (c) DTU Wind Energy
%********************************************************

%Determine orientation of crack c.sys.
if ( utils.etype(utils.ecf(1))==1 )
    ivec = [utils.nl_2d(utils.nncf(1),2) utils.nl_2d(utils.nncf(1),3) 0];
    jvec = [utils.nl_2d(utils.nncf(2),2) utils.nl_2d(utils.nncf(2),3) 0];
    x1 = (ivec-jvec)/norm(ivec-jvec);
elseif ( utils.etype(utils.ecf(1))==2 )
    ivec = [utils.nl_2d(utils.nncf(1),2) utils.nl_2d(utils.nncf(1),3) 0];
    kvec = [utils.nl_2d(utils.nncf(3),2) utils.nl_2d(utils.nncf(3),3) 0];
    x1 = (ivec-kvec)/norm(ivec-kvec);
end
z1 = [0 0 1];
y1 = cross(z1,x1);

%Rotation matrix
Grot=[x1' y1' z1']';

if ( utils.etype(utils.ecf(1))==1 )
    %Element length along x or y
    deltax=abs(utils.nl_2d(utils.nncf(2),2)-utils.nl_2d(utils.nncf(3),2));
    deltay=abs(utils.nl_2d(utils.nncf(2),3)-utils.nl_2d(utils.nncf(3),3));
    %Total length
    deltaa1=sqrt(deltax^2+deltay^2);
    %Element length along x or y
    deltax=abs(utils.nl_2d(utils.nncf(1),2)-utils.nl_2d(utils.nncf(2),2));
    deltay=abs(utils.nl_2d(utils.nncf(1),3)-utils.nl_2d(utils.nncf(2),3));
    %Total length
    deltaa2=sqrt(deltax^2+deltay^2);
    %Area
    deltaL=deltaa1;
    
    %Force at crack tip
    fcind=find(utils.el_2d(utils.ecf(1),2:end)==utils.nncf(2));
    fc_1=[forces(utils.ecf(1),(fcind-1)*3+1:fcind*3)   forces(utils.ecf(1),end-5:end)];
    fcind=find(utils.el_2d(utils.ecf(2),2:end)==utils.nncf(2));
    fc_2=[forces(utils.ecf(2),(fcind-1)*3+1:fcind*3)   forces(utils.ecf(2),end-5:end)];
    fc=fc_1+fc_2;
    
    %Displacement in front of crack tip
    u1=disp((utils.nncf(3)-1)*3+1:(utils.nncf(3))*3);
    u2=disp((utils.nncf(4)-1)*3+1:(utils.nncf(4))*3);
    deltau=u1-u2;
    
    %Rotate displacements and forces to crack coord. sys.
    deltau=Grot*deltau;
    fc=Grot*fc(1:3)';

    %Strain energy release rate
    G(2)=-1/(2*deltaL)*fc(1)*deltau(1) ;
    G(1)=-1/(2*deltaL)*fc(2)*deltau(2) ;
    G(3)=-1/(2*deltaL)*fc(3)*deltau(3) ;
    
elseif ( utils.etype(utils.ecf(1))==2 )
    
    %Element length along x or y
    deltax=abs(utils.nl_2d(utils.nncf(3),2)-utils.nl_2d(utils.nncf(5),2));
    deltay=abs(utils.nl_2d(utils.nncf(3),3)-utils.nl_2d(utils.nncf(5),3));
    %Total length
    deltaxy=sqrt(deltax^2+deltay^2);
    %Area
    deltaL=deltaxy;
    
    %Force at crack tip
    fcind=find(utils.el_2d(utils.ecf(1),2:end)==utils.nncf(2));
    
    fc_mid=[forces(utils.ecf(1),(fcind-1)*3+1:fcind*3)   forces(utils.ecf(1),end-5:end)];
    
    fcind=find(utils.el_2d(utils.ecf(1),2:end)==utils.nncf(3));
    fc_1=[forces(utils.ecf(1),(fcind-1)*3+1:fcind*3)   forces(utils.ecf(1),end-5:end)];
    fcind=find(utils.el_2d(utils.ecf(2),2:end)==utils.nncf(3));
    fc_2=[forces(utils.ecf(2),(fcind-1)*3+1:fcind*3)   forces(utils.ecf(2),end-5:end)];
    
    fc_corner=fc_1+fc_2;
    
    %Displacement in front of crack tip
    u1=disp((utils.nncf(4)-1)*3+1:(utils.nncf(4))*3);
    u2=disp((utils.nncf(6)-1)*3+1:(utils.nncf(6))*3);
    
    deltau_mid=u1-u2;
    
    u1=disp((utils.nncf(5)-1)*3+1:(utils.nncf(5))*3);
    u2=disp((utils.nncf(7)-1)*3+1:(utils.nncf(7))*3);
    
    deltau_corner=u1-u2;
    
    %Rotate displacements and forces to crack coord. sys.
    deltau_mid=Grot*deltau_mid;
    deltau_corner=Grot*deltau_corner;
    fc_mid=Grot*fc_mid(1:3)';
    fc_corner=Grot*fc_corner(1:3)';

    %Strain energy release rate
    G(2)=-1/(2*deltaL)*(fc_mid(1)*deltau_mid(1) + fc_corner(1)*deltau_corner(1));
    G(1)=-1/(2*deltaL)*(fc_mid(2)*deltau_mid(2) + fc_corner(2)*deltau_corner(2));
    G(3)=-1/(2*deltaL)*(fc_mid(3)*deltau_mid(3) + fc_corner(3)*deltau_corner(3));
    
end

end

