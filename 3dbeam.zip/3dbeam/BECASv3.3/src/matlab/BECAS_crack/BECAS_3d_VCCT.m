function [ G ] = BECAS_3d_VCCT( disp3d, force3d, utils )

%%
if ( utils.etype==1 )
    %Element length along x or y
    deltax=abs(utils.nl_2d(utils.nncf(1),2)-utils.nl_2d(utils.nncf(2),2));
    deltay=abs(utils.nl_2d(utils.nncf(1),3)-utils.nl_2d(utils.nncf(2),3));
    %Total length
    deltaxy=sqrt(deltax^2+deltay^2);
    %Area
    deltaA=utils.deltaz*deltaxy;
    
    %Force at crack tip
    fcind=find(utils.el_2d(utils.ecf(1),2:end)==utils.nncf(2));
    fc_1=force3d(utils.ecf(1),(fcind-1)*3+1:fcind*3);
    fcind=find(utils.el_2d(utils.ecf(2),2:end)==utils.nncf(2));
    fc_2=force3d(utils.ecf(2),(fcind-1)*3+1:fcind*3);

    fc=fc_1+fc_2;
    
    %Displacement in front of crack tip
    u1=disp3d((utils.nncf(3)-1)*3+1:(utils.nncf(3))*3);
    u2=disp3d((utils.nncf(4)-1)*3+1:(utils.nncf(4))*3);
    deltau=u1-u2;
    
    %Stain energy release rate
    G(1)=1/(2*deltaA)*fc(1)*deltau(1);
    G(2)=1/(2*deltaA)*fc(2)*deltau(2);
    G(3)=1/(2*deltaA)*fc(3)*deltau(3);
    
elseif ( utils.etype==2 )
    
    %Element length along x or y
    deltax=abs(utils.nl_2d(utils.nncf(2),2)-utils.nl_2d(utils.nncf(4),2));
    deltay=abs(utils.nl_2d(utils.nncf(2),3)-utils.nl_2d(utils.nncf(4),3));
    %Total length
    deltaxy=sqrt(deltax^2+deltay^2);
    %Area
    deltaA=utils.deltaz*deltaxy;
    
    %Force at crack tip
    %Face 1
    %Mid
    fcind=find(utils.el_2d(utils.ecf(1),6:9)==utils.nncf(1));
    fc_mid1=force3d(utils.ecf(1),(fcind-1)*3+1 + 24:fcind*3 + 24);
    %Corner
    fcind=find(utils.el_2d(utils.ecf(1),2:5)==utils.nncf(2));
    fc_1=force3d(utils.ecf(1),(fcind-1)*3+1:fcind*3);
    fcind=find(utils.el_2d(utils.ecf(2),2:5)==utils.nncf(2));
    fc_2=force3d(utils.ecf(2),(fcind-1)*3+1:fcind*3);
    fc_corner1=fc_1+fc_2;
    
    %Face 2
    %Mid
    fcind=find(utils.el_2d(utils.ecf(1),6:9)==utils.nncf(1));
    fc_mid2=force3d(utils.ecf(1),(fcind-1)*3+1 + 36:fcind*3 + 36);
    %Corner
    fcind=find(utils.el_2d(utils.ecf(1),2:5)==utils.nncf(2));
    fc_1=force3d(utils.ecf(1),(fcind-1)*3+1 + 12:fcind*3 + 12);
    fcind=find(utils.el_2d(utils.ecf(2),2:5)==utils.nncf(2));
    fc_2=force3d(utils.ecf(2),(fcind-1)*3+1 + 12:fcind*3 + 12);
    fc_corner2=fc_1+fc_2;
    
    %Face12
    fcind=find(utils.el_2d(utils.ecf(1),2:5)==utils.nncf(2));
    fc_1=force3d(utils.ecf(1),(fcind-1)*3+1 + 48:fcind*3 + 48);
    fcind=find(utils.el_2d(utils.ecf(2),2:5)==utils.nncf(2));
    fc_2=force3d(utils.ecf(2),(fcind-1)*3+1 + 48:fcind*3 + 48);
    fc_corner12=fc_1+fc_2;
   
    %Displacement in front of crack tip
    disp_face1=disp3d(1:utils.nn_2d*3);
    disp_face12=disp3d(utils.nn_2d*3+1:end-utils.nn_2d*3);
    disp_face2=disp3d(end-utils.nn_2d*3+1:end);
    %Face 1
    u1=disp_face1((utils.nncf(3)-1)*3+1:(utils.nncf(3))*3);
    u2=disp_face1((utils.nncf(5)-1)*3+1:(utils.nncf(5))*3);
    deltau_mid1=abs(u1-u2);    
    u1=disp_face1((utils.nncf(4)-1)*3+1:(utils.nncf(4))*3);
    u2=disp_face1((utils.nncf(6)-1)*3+1:(utils.nncf(6))*3);
    deltau_corner1=abs(u1-u2); 
    %Face 2    
    u1=disp_face2((utils.nncf(3)-1)*3+1:(utils.nncf(3))*3);
    u2=disp_face2((utils.nncf(5)-1)*3+1:(utils.nncf(5))*3);
    deltau_mid2=abs(u1-u2);    
    u1=disp_face2((utils.nncf(4)-1)*3+1:(utils.nncf(4))*3);
    u2=disp_face2((utils.nncf(6)-1)*3+1:(utils.nncf(6))*3);
    deltau_corner2=abs(u1-u2); 
    %Face 1/2    
    u1=disp_face12((utils.nncf(4)-1)*3+1:(utils.nncf(4))*3);
    u2=disp_face12((utils.nncf(6)-1)*3+1:(utils.nncf(6))*3);
    deltau_corner12=u1-u2; 
    
    %Stain energy release rate
    G(1)=-1/(2*deltaA)*( 1/2*fc_mid1(1)*deltau_mid1(1) + 1/2*fc_corner1(1)*deltau_corner1(1) +...
                         1/2*fc_mid2(1)*deltau_mid2(1) + 1/2*fc_corner2(1)*deltau_corner2(1) +...
                         fc_corner12(1)*deltau_corner12(1));
    G(2)=-1/(2*deltaA)*( 1/2*fc_mid1(2)*deltau_mid1(2) + 1/2*fc_corner1(2)*deltau_corner1(2) +...
                         1/2*fc_mid2(2)*deltau_mid2(2) + 1/2*fc_corner2(2)*deltau_corner2(2) +...
                         fc_corner12(2)*deltau_corner12(2));
    G(3)=-1/(2*deltaA)*( 1/2*fc_mid1(3)*deltau_mid1(3) + 1/2*fc_corner1(3)*deltau_corner1(3) +...
                         1/2*fc_mid2(3)*deltau_mid2(3) + 1/2*fc_corner2(3)*deltau_corner2(3) +...
                         fc_corner12(3)*deltau_corner12(3));

                     
end
end

