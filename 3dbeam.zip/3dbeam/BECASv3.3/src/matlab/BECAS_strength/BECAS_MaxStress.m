function [ failure ] = BECAS_MaxStress( failMat, stress )
%********************************************************
% File: BECAS_MaxStress
%   Function implementing the maximum stress failure criterion according to
%   ANSYS release 14.0 manual, chapter 2.4.3.2.�"Maximum Stress Failure
%   Criteria"
%
% Syntax:
%   [ failure ] = BECAS_MaxStress( failMat, stress )
%
% Input:
%   failMat.  : Array [1 x nMat] of structures of material parameters
%     .fcFlag - Flag of failure criterion (not used here)
%     .st     - Tensile strengths, [1x3]
%     .t      - Shear strengths, [1x3]
%     .sc     - Compressive strengths, [1x3]
%     .et     - Maximum tensile strains, [1x3] (not used here)
%     .g      - Maximum shear strains, [1x3] (not used here)
%     .ec     - Maximum compressive strains, [1x3] (not used here)
%   stress    : Vector of stress components, [1x6]
%
% Output:
%   failure   : Failure parameters for each stress component, [1x6]
%
% Calls:
%
% Date:
%   Version 0.1    15.01.2013  Vladimir Fedorov
%   Version 0.2    16.01.2013  Vladimir Fedorov
%   Version 1.0    15.07.2014   Jos� Pedro Blasques - fixed bug associated 
%   with ordering of strength components. BECAS ordering is now used all 
%   throughout. 
%
% (c) DTU Wind Energy
%********************************************************

%Mapping of components
cdof_st=[1 2 6];
cdof_t=[3 4 5];

%Failure array initialization
failure = zeros(6,1);

%Tensile stresses
st = stress(cdof_st);
%Shear stresses
t = stress(cdof_t);

%Processing normal stress components...
for i = 1:3
  if st(i) >= 0
    failure(cdof_st(i)) = abs( st(i)/failMat.st(i) );
  else
    failure(cdof_st(i)) = abs( st(i)/failMat.sc(i) );
  end;
end;

%... and shear stresses
failure(cdof_t) = abs( t./failMat.t );
return;