function [ failure ] = BECAS_Hashin( failMat, stress )
%********************************************************
% File: BECAS_Hahin
%   Function implementing the failure analysis based on Hashin failure
%   criteria and the Yamada-Sun failure analysis adapted by
%   Chang and Shokrieh.
%
% Syntax:
%   [ failure ] = Hashin( failMat, stress )
%
% Input:
%   failMat.  : Array [1 x nMat] of structures of material parameters
%     .fcFlag - Flag of failure criterion (not used here)
%     .st     - Tensile strengths, [1x3]
%     .t      - Shear strengths, [1x3]
%     .sc     - Compressive strengths, [1x3]
%     .et     - Maximum tensile strains, [1x3] (not used here)
%     .g      - Maximum shear strains, [1x3] (not used here)
%     .ec     - Maximum compressive strains, [1x3] (not used here)
%   stress    : Vector of stress components, [1x6]
%
% Output:
%   failure   : Failure parameter copied to entire vector, [1x7]
%
% Calls:
%
% Date:
%   Version 0.1    01.07.2016  Lucia Escolar
%
% (c) DTU Wind Energy
%********************************************************

%Current stresses
s1 = stress(1);
s2 = stress(2);
s3 = stress(6);
t12 = stress(3);
t13 = stress(4);
t23 = stress(5);

%Strength parameters
s1t = failMat.st(1);
s1c = failMat.sc(1);
s2t = failMat.st(2);
s2c = failMat.sc(2);
s3t = failMat.st(3);
s3c = failMat.sc(3);
t12tc = failMat.t(1);
t13tc = failMat.t(2);
t23tc = failMat.t(3);

failure = zeros(6,1);
%FIXME
%Take out the G12, G13
if s1 > 0
    %Fiber tension
    fTen   = ((s1/s1t)^2 + (t12/t12tc)^2 + (t13/t13tc)^2)^0.5;
    failure(1) = fTen;
elseif s1 < 0
    %Fiber compression & Fiber-matrixShear
    fCom   = (s1/s1c)^0.5;
    failure(1) = fCom;
end

if s2 > 0
    %Matrix tension
    mTen   = ((s2/s2t)^2 + (t12/t12tc)^2 + (t23/t23tc)^2)^0.5;
    failure(2) = mTen;
elseif s2 < 0
    %Matrix compresion
    mCom   = ((s2/s2c)^2 + (t12/t12tc)^2 + (t23/t23tc)^2)^0.5;
    failure(2) = mCom;
end

if s3 > 0
    %Normal tension
    nTen   = ((s3/s3t)^2 + (t13/t13tc)^2 + (t23/t23tc)^2)^0.5;
    failure(3) = nTen;
elseif s3 < 0
    %Normal compresion
    nCom   = ((s3/s3c)^2 + (t13/t13tc)^2 + (t23/t23tc)^2)^0.5;
    failure(3) = nCom;
end

if s1 < 0
    %Fiber-matrixShear
    fmSh = ((s1/s1c)^2 + (t12/t12tc)^2 + (t13^2/t13tc^2)^2)^0.5;
    failure(4) = fmSh;
end

%Maximum of all criteria
failure(5) = max(failure(1:4));

return;