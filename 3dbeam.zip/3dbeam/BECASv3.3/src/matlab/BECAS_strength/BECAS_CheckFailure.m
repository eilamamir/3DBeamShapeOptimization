function [ failure ] = BECAS_CheckFailure( utils, stress, strain )
%********************************************************
% File: BECAS_CheckFailure
%   %Function implementing failure criteria checks.
%
% Syntax:
%   [ failure ] = BECAS_CheckFailure( utils, stress, strain )
%
% Input:
%   utils.  :  Structure holding the following arrays obtained from
%   BECAS_Utils():
%   stress  : Vector of stress components for each of nPts points of nElem
%             elements, [nElem x 6*nPts]
%   strain  : Vector of strain components for each of nPts points of nElem
%             elements, [nElem x 6*nPts]
%
% Output:
%   failure : Calculated failure parameters, [nElem x 6*nPts]
%
% Calls:
%
% Date:
%   Version 0.1    15.01.2013   Vladimir Fedorov
%   Version 0.2    16.01.2013   Vladimir Fedorov
%   Version 1.0    15.07.2014   Jos� Pedro Blasques - Now returning results
%   at Gauss points.
%   Version 1.1    15.07.2014   Jos� Pedro Blasques - fixed bug associated 
%   with ordering of strength components. BECAS ordering is now used all 
%   throughout. 
%
% (c) DTU Wind Energy
%********************************************************

%Number of elements
nElem = size(stress,1);

%Number of points withing the element
nPts = floor( size(stress,2)/6);

%Failure array initialization
failure = zeros(nElem, nPts*6);

%Checking if strength properties are defined. If not leaving function.
if isfield(utils,'failMat')==0
   warning('something:anything','Strength properties are not defined: \n skipping failure analysis')
   return
end

%Going through all the elements
for eNo = 1:nElem
  %Material parameters
  matNo = utils.emat(eNo,2);
  
  %For each point within the element
  for pNo = 1:nPts
    %Current point stress data
    pStress = stress(eNo, 6*pNo-5:6*pNo);
    %Current point strain data
    pStrain = strain(eNo, 6*pNo-5:6*pNo);
    
    %Invoking the desired failure criterion function
    switch utils.failMat(matNo).fcFlag
      case 1 %Maximum strain
        failure(eNo, 6*pNo-5:6*pNo) = BECAS_MaxStrain(utils.failMat(matNo), pStrain);
      case 2 %Maximum stress
        failure(eNo, 6*pNo-5:6*pNo) = BECAS_MaxStress(utils.failMat(matNo), pStress);
      case 3 %Tsai Wu
        failure(eNo, 6*pNo-5:6*pNo) = BECAS_TsaiWu(utils.failMat(matNo), pStress);
      case 4 %Hashin
        failure(eNo, 6*pNo-5:6*pNo) = BECAS_Hashin(utils.failMat(matNo), pStress);
      otherwise %Otherwise use Max stress criterion
        warning('something:anything','\n WARNING Message from BECAS_CheckFailure: \n \n Unknown failure criterion flag (%n). \n Using Maximum stress criterion instead... \n', fcFlags(matNo));
        failure(eNo, 6*pNo-5:6*pNo) = BECAS_MaxStress(utils.failMat(matNo), pStress);
    end;
  end;
end;

return;