function [ failure ] = BECAS_TsaiWu( failMat, stress )
%********************************************************
% File: BECAS_TsaiWu
%   Function implementing the Tsai-Wu failure criterion according to
%   ANSYS release 14.0 manual, chapter 2.4.3.3.�"Tsai-Wu Failure Criteria".
%   or Tsai, S.W. and Hahn, H.T., "Introduction to Composite Materials",
%   Technomic Publishing Co. Inc., (455), 1980.
%   Default coupling coefficients C12 = C13 = C23 = -1 are used.
%
% Syntax:
%   [ failure ] = BECAS_TsaiWu( failMat, stress )
%
% Input:
%   failMat.  : Array [1 x nMat] of structures of material parameters
%     .fcFlag - Flag of failure criterion (not used here)
%     .st     - Tensile strengths, [1x3]
%     .t      - Shear strengths, [1x3]
%     .sc     - Compressive strengths, [1x3]
%     .et     - Maximum tensile strains, [1x3] (not used here)
%     .g      - Maximum shear strains, [1x3] (not used here)
%     .ec     - Maximum compressive strains, [1x3] (not used here)
%   stress    : Vector of stress components, [1x6]
%
% Output:
%   failure   : Failure parameter copied to entire vector, [1x6]
%
% Calls:
%
% Date:
%   Version 0.2    16.01.2013  Vladimir Fedorov
%   Version 1.0    15.07.2014   Jos� Pedro Blasques - fixed bug associated 
%   with ordering of strength components. BECAS ordering is now used all 
%   throughout. 
%
% (c) DTU Wind Energy
%********************************************************

%Current stresses
s1 = stress(1);
s2 = stress(2);
s3 = stress(6);
t12 = stress(3);
t13 = stress(4);
t23 = stress(5);

%Strength parameters
s1t = failMat.st(1);
s1c = failMat.sc(1);
s2t = failMat.st(2);
s2c = failMat.sc(2);
s3t = failMat.st(3);
s3c = failMat.sc(3);
t12tc = failMat.t(1);
t13tc = failMat.t(2);
t23tc = failMat.t(3);

%Coupling parameters (default value: -1)
C12 = -1;
C13 = -1;
C23 = -1;

%Term A
A = -s1^2/(s1t*s1c) - s2^2/(s2t*s2c)  - s3^2/(s3t*s3c) + ...
  + t12^2/(t12tc^2) + t23^2/(t23tc^2) + t13^2/(t13tc^2) + ...
  + C12*s1*s2/sqrt(s1t*s1c*s2t*s2c) + C23*s2*s3/sqrt(s2t*s2c*s3t*s3c) + C13*s1*s3/sqrt(s1t*s1c*s3t*s3c);

%Term B
B = (1/s1t+1/s1c)*s1 + (1/s2t+1/s2c)*s2 + (1/s3t+1/s3c)*s3;

%Failure parameter
failure = ones(1,6).*(A + B);
return;