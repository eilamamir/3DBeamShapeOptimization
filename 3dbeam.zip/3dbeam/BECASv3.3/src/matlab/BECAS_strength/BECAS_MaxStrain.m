function [ failure ] = BECAS_MaxStrain( failMat, strain )
%********************************************************
% File: BECAS_MaxStrain
%   Function implementing the maximum strain failure criterion according to
%   ANSYS release 14.0 manual, chapter 2.4.3.1.�"Maximum Strain Failure
%   Criteria"
%
% Syntax:
%   [ failure ] = BECAS_MaxStrain( failMat, strain )
%
% Input:
%   failMat.  : Array [1 x nMat] of structures of material parameters
%     .fcFlag - Flag of failure criterion (not used here)
%     .st     - Tensile strengths, [1x3] (not used here)
%     .t      - Shear strengths, [1x3] (not used here)
%     .sc     - Compressive strengths, [1x3] (not used here)
%     .et     - Maximum tensile strains, [1x3]
%     .g      - Maximum shear strains, [1x3]
%     .ec     - Maximum compressive strains, [1x3]
%   strain    : Vector of strain components, [1x6]
%
% Output:
%   failure   : Failure parameters for each strain component, [1x6]
%
% Calls:
%
% Date:
%   Version 0.2    16.01.2013  Vladimir Fedorov
%   Version 1.0    15.07.2014   Jos� Pedro Blasques - fixed bug associated 
%   with ordering of strength components. BECAS ordering is now used all 
%   throughout. 
%
% (c) DTU Wind Energy
%********************************************************

%Mapping of components
cdof_t=[1 2 6];
cdof_g=[3 4 5];

%Failure array initialization
failure = zeros(6,1);

%Tensile strains
et = strain(cdof_t);
%Shear strains
g = strain(cdof_g);

%Processing normal strain components...
for i = 1:3
  if et(i) >= 0
    failure(cdof_t(i)) = abs( et(i)/failMat.et(i) );
  else
    failure(cdof_t(i)) = abs( et(i)/failMat.ec(i) );
  end;
end;

%... and shear stresses
failure(cdof_g) = abs( g./failMat.g );

return;