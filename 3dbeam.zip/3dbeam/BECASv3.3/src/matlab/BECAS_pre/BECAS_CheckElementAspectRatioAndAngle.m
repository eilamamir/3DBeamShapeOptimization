function [ ar, inang ] = BECAS_CheckElementAspectRatioAndAngle( utils )
%********************************************************
% File: BECAS_CheckElementAspectRatioAndAngle
%   This function checks the element aspect ratio and inner angles. Used
%   for mesh quality checks
%
% Syntax:
%   [ ar, inang ] = BECAS_CheckElementAspectRatioAndAngle( utils )
%
% Input:
%   utils   :  structure containing the input data.
%
% Output:
%   ar      :  (nex1) array with element aspect ratio
%   inang   :  (nex2) array with minimum and maximum values of inner angles
%              at each corner node for each element.
%
% Calls:
%
% Revisions:
%   Version 1.0    07.11.2012   Jos� Pedro Blasques
%   Version 1.1    12.11.2012   Jos� Pedro Blasques: Now working with non
%   ordered element numbers
%
%
% (c) DTU Wind Energy
%********************************************************
fprintf(1,' Started checking aspect ratio and element inner angles values...');

%Initialize variables
ar = zeros(utils.ne_2d,1);
inang = zeros(utils.ne_2d,2);

for e=1:utils.ne_2d
    
    if(utils.etype(e) == 1 || utils.etype(e) == 2 || ...
            utils.etype(e) == 3)
        %Nodal positions
        n1 = utils.nl_2d( utils.el_2d(e,2), 2:end);
        n2 = utils.nl_2d( utils.el_2d(e,3), 2:end);
        n3 = utils.nl_2d( utils.el_2d(e,4), 2:end);
        n4 = utils.nl_2d( utils.el_2d(e,5), 2:end);
        
        %Vectors at each element face
        v12 = n2-n1;
        v23 = n3-n2;
        v34 = n4-n3;
        v41 = n1-n4;
        
        %Vectors crossing the element
        v13 = n3-n1;
        v24 = n4-n2;
        
        %Aspect ratio
        a1=norm(v13);
        a2=norm(v24);
        ar(e)=max([a1 a2])/min([a1 a2]);
        
        %Interior angles at each corner node
        inang1=acosd(v12*v23'/(norm(v12)*norm(v23)));
        inang2=acosd(v23*v34'/(norm(v23)*norm(v34)));
        inang3=acosd(v34*v41'/(norm(v34)*norm(v41)));
        inang4=acosd(v41*v12'/(norm(v41)*norm(v12)));
        inang(e,1)=max([inang1, inang2, inang3, inang4]);
        inang(e,2)=min([inang1, inang2, inang3, inang4]);
        
    elseif(utils.etype(e) == 4)

        %Nodal positions
        n1 = utils.nl_2d( utils.el_2d(e,2), 2:end);
        n2 = utils.nl_2d( utils.el_2d(e,3), 2:end);
        n3 = utils.nl_2d( utils.el_2d(e,4), 2:end);
        
        %Vectors at each element face
        v12 = n2-n1;
        v23 = n3-n2;
        v31 = n1-n3;
        
        %Length of the sides
        a=norm(v12);
        b=norm(v23);
        c=norm(v31);
        
        %Aspect ratio
        ar(e)=max([a b c])/min([a b c]);
        
        %Interior angles at each corner node
        inang1 =acosd((b^2+c^2-a^2)/(2*b*c));
        inang2 =acosd((a^2+c^2-b^2)/(2*a*c));
        inang3 =acosd((a^2+b^2-c^2)/(2*a*b));
        
        %Maximum and minimum interior angles at each corner node
        inang(e,1)=max([inang1, inang2, inang3]);
        inang(e,2)=min([inang1, inang2, inang3]);
        
    end
   
end

%Check aspect ratio
[val, ind] = max(ar);
if ( val>1E3 )
    fprintf(1,'\n');
    fprintf(1,'Warning message from BECAS_CheckElementAspectRatioAndAngle: \n')
    fprintf(1,'Beware that element %d and maybe other have an aspect ratio above 1000.\n', utils.el_2d(ind(1),1));
    fprintf(1,'This may compromise the quality of your results. \n');
end


%Check inner angle
[maxval, maxind] = max(inang(:,1));
[minval, minind] = min(inang(:,2));
if ( maxval>160 || minval<20 )
    fprintf(1,'\n');
    fprintf(1,'Warning message from BECAS_CheckElementAspectRatioAndAngle: \n')
    fprintf(1,'Beware that element %d and maybe other have an inner angle larger than 160 degrees.\n', utils.el_2d(maxind,1));
    fprintf(1,'This may compromise the quality of your results. \n');
end
