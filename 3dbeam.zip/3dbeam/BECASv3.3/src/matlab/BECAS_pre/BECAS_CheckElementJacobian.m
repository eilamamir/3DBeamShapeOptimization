function [ detJcheck ] = BECAS_CheckElementJacobian( utils )
%********************************************************
% File: BECAS_CheckJacobian
%   This function checks the sign of the Jacobian at each Gauss point. Used
%   for mesh quality checks
%
% Syntax:
%   [ detJ ] = BECAS_CheckJacobian( utils )
%
% Input:
%   utils   :  structure containing the input data.
%
% Output:
%   detJcheck :  (nexgpoints) array with the value of det(J) at each Gauss
%             point. if detJcheck(i)=1, then det(J) in at a gauss point in
%             element i is negative.
%
% Calls:
%
% Revisions:
%   Version 1.0    07.11.2012   Jos� Pedro Blasques
%   Version 1.1    12.11.2012   Jos� Pedro Blasques: fixed the rule for
%   error checking which was not working before even if detJ<0
%   Version 1.2    25.11.2013   Jos� Pedro Blasques: removed one of the
%   loops on the gauss points which now are defined in BECAS_Utils.
%   Version 1.3    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************
fprintf(1,' Started checking Jacobian values...');

%Initialize variables
detJ=ones(utils.ne_2d,utils.max_ngpoints);

ng=0;
for enum=1:utils.ne_2d
    %Start integration
    for n=1:utils.element(utils.etype(enum)).gpoints     %Iterate gauss points along the length
        xxs = utils.element(utils.etype(enum)).xxg(n);    %X position of Gauss point
        yys = utils.element(utils.etype(enum)).yyg(n);    %Y position of Gauss point
        ng=ng+1;
        if(utils.etype(enum) == 1)
            [ iJ, detJ(enum,n) ] = BECAS_Q4_Jacobian( xxs, yys, utils.pr_2d(:,enum) );
        elseif(utils.etype(enum) == 2 || utils.etype(enum) == 3 )
            [ iJ, detJ(enum,n) ] = BECAS_Q8_Jacobian( xxs, yys, utils.pr_2d(:,enum) );
        elseif(utils.etype(enum) == 4)
            [ iJ, detJ(enum,n) ] = BECAS_T6_Jacobian( xxs, yys, utils.pr_2d(:,enum) );
        end
    end
end

%Check if there are any negative det(J)
detJ(detJ<=0)=-1;
detJ(detJ>0)=0;
detJcheck=min(detJ,[],2);
%% Check aspect ratio
[val, ind] = min(detJcheck);
if ( val<0 )
    %Plotting for finding which element has a negative jacobian
    utils.emat(:,2)=detJcheck-1;  %-1 because of the way BECAS_PlotMaterialNumber is organized
    jcplot = BECAS_PlotMaterialNumber( utils );
    %Issue warning
    errormessage='\n ERROR MESSAGE from BECAS_CheckElementJacobian: \n \n Some elements have a negative Jacobian! \n Please check the figure to identify the \n problematic elements (-1 if det(J)<0, 0 otherwise). \n Terminating BECAS \n';
    error('something:anything',errormessage);
end


