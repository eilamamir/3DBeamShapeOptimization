function [ check ] = BECAS_3d_CheckInput( options, utils )
%********************************************************
% File: BECAS_CheckInput.m
%   This function checks the input to BECAS.
%
% Syntax:
%   [ utils ] = BECAS_Utils( inputdata )
%
% Input:
%   utils   :  structure containing the input data.
%
% Output:
%   check   :  structure containing flags from the input check.
%
% Calls:
%
% Revisions:
%   Version 1.0    28.02.2012   Jos� Pedro Blasques
%   Version 1.1    10.10.2012   Jos� Pedro Blasques: Using error function
%   from Matlab. It creates a lotta blood but it is the only way to stop
%   BECAS execution. Checking that element type is compatible with ELIST
%   input.
%   Version 1.2    14.01.2013   Jos� Pedro Blasques: Corrected one of the
%   comments which made no sense.
%   Version 1.3    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

%Check if the etype variable is defined
if isfield(options,'etype_3d')
    check.exist_etype_3d=1;
else
    fprintf(1,'\n');
    fprintf(1,'Warning message from BECAS_CheckInput: \n')
    fprintf(1,'Element type for BECAS 3d is not defined, using default based on ELIST.in...  \n');
    check.exist_etype_3d=0;
end

    
%Check if the etype variable is defined and if so matches the input
errormessage='\n ERROR Message from BECAS_CheckInput: \n \n An element type was specified using options.etype\n which does not match your input in ELIST.in!\n Terminating BECAS \n';
if check.exist_etype_3d
    if strcmp(options.etype_3d,'S8')
       if(size(utils.el_2d,2)>5 && utils.el_2d(1,6)~=0) 
           error('something:anything',errormessage);
       end
    end
    if strcmp(options.etype_3d,'S20')
       if(size(utils.el_2d,2)<9 || utils.el_2d(1,6)==0) 
           error('something:anything',errormessage);
       end
    end  
    if strcmp(options.etype_3d,'SH8')
       if(size(utils.el_2d,2)>5 && utils.el_2d(1,6)~=0) 
           error('something:anything',errormessage);
       end
    end    
    if strcmp(options.etype_3d,'file')
        if (size(utils.etype,1) ~= size(utils.el_2d,1))
            errormessage='\n ERROR Message from BECAS_CheckInput: \n \n The file ETYPE.in and E2D.in files must have the same number of elements \n Terminating BECAS \n';
            error('something:anything',errormessage);
        end
    end
end

