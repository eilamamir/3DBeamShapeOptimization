function [ elcheck ] = BECAS_CheckMesh( utils )
%********************************************************
% File: BECAS_CheckMesh
%   This function calls several others for checking the finite element mesh
%   quality. It is useful to trace problems which may be related to your
%   mesh.
%
% Syntax:
%   [ elcheck ] = BECAS_CheckMesh( utils )
%
% Input:
%   utils   :  structure containing the input data.
%
% Output:
%   elcheck :  structure containing arrays holding information on checks on
%              Jacobian, aspect ratio, and inner angles.
%
% Calls:
%
% Revisions:
%   Version 1.0    07.11.2012   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

fprintf(1,'> Started checking mesh... ')

%% Check Jacobian sign
[ elcheck.detJcheck ] = BECAS_CheckElementJacobian( utils );

%% Check aspect ratio and internal angles
[ elcheck.ar, elcheck.inang ] = BECAS_CheckElementAspectRatioAndAngle( utils );
fprintf(1,'DONE! \n');


end

