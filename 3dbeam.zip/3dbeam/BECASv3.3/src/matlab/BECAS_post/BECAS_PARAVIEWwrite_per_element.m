function [filename] = BECAS_PARAVIEWwrite_per_element(outfilename, header, paraview, partnum, data)
%Write per element data in Ensight Gold format
%   Can be read by Paraview of ESI Ensight
%   This works if data is a list of scalars (nx1) as well if data is 
%   list of vectors (nx3)

%% Open file
fid = fopen(outfilename,'w+');
filename = outfilename; % simply return the outfilename

%% Header
fprintf(fid,'%s\n', header);
fprintf(fid,'part\n');
fprintf(fid,'%10d\n',partnum);

%% Element list

for i=1:length(paraview.etopochange)-1
    j = i + 1;  % write element form etopochange(i) to etopochange(j)
    from = paraview.etopochange(i);
    to =   paraview.etopochange(j) - 1;
    fprintf(fid,'%s\n',paraview.etopo_string{from});
    fprintf(fid,'%12.5e\n',data(from:to,:));
end

fclose(fid);
end




