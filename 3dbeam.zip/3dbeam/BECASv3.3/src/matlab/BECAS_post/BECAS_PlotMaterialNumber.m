function [fighandle] = BECAS_PlotMaterialNumber(utils)
%********************************************************
% File: BECAS_PlotMaterialNumbers.m
%   Function to plot material numbers at each element
%
% Syntax:
%   BECAS_PlotMaterialNumbers( utils )
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   fighandle : Figure number
%
% Calls:
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    21.08.2012   Robert and Jos� : Introduced figure handle
%   and included it as output
%   Version 1.2    09.10.2012   Jos� Pedro Blasques: Edges are now plotted
%   in the same color as the patch. Makes it easier for fine meshes.
%   Version 1.3    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%   Version 1.4    20.08.2014   JPBL; Added the possibility of plotting
%   only a detail based on the input of edetail.
%
% (c) DTU Wind Energy
%********************************************************

%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
end

fighandle = figure;
hold on
colorbar;
colormap;

%Plot elements and color according to material number
for e=1:ne_2d
    i=el_2d(e);
    %Defining constants to make equations readable
    nnpe_2d = utils.element(utils.etype(i)).nnpe_2d;
    vertex_connection = utils.element(utils.etype(i)).vertex_connection;
    %Define vertex or nodal positions
    vertex_list=zeros(nnpe_2d,3);
    for ii=1:nnpe_2d
        for iii=1:2
            vertex_list(ii,iii)=utils.nl_2d(utils.el_2d(i,ii+1),iii+1);
            vertex_list(ii,3)=0;
        end
    end
    %Set patch properties
    facecolor=ones(nnpe_2d,1)*utils.emat(i,2)+1;
    pa=patch('Vertices',vertex_list,...
        'Faces',vertex_connection,...
        'facecolor', 'interp',...
        'edgecolor', 'none',...
        'facealpha', 1);
    set(pa,'FaceVertexCData',facecolor);
end
%Figure properties
box off
hold off
axis off
axis equal
%Figure title
title('Material number');

end