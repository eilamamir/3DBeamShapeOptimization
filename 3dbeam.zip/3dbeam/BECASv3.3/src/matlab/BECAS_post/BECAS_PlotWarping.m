function [fighandle] = BECAS_PlotWarping( utils, dfield, options, cfield )
%********************************************************
% File: BECAS_PlotWarping.m
%   Function plots cross section deformed shape. Build mostly for producing
%   plots for papers.
%
% Syntax:
%   BECAS_PlotWarping( utils, dfield, options, cfield )
%
% Input:
% utils : structure 
% options : structure containing the different options to control the 
%  figure properties.
% options.color : string defining which field is used for coloring elements. 
%  The options are: 'none' (default), 'abs' for absolute displacement, 'ux', 
%  'uy', and 'uz' for x, y, and z component of the displacement, 'material'
%  for material number, 'cfield' for using field in input array cfield. 
% options.scale : scalar for scaling dfield.
% options.cs : string turning coordinate system 'on' (default), or 'off'.
% options.deformed : string controlling if plotted shape is deformed shape
%  ('on') or undeformed ('off', default).
% options.overlay : string to plot overlays to the main images. Options are 
%  'off' (default) or 'undef' in which case the undeformed shape is plotted
%  in the background.
% options.zoom : scalar controlling zoom.
% options.view : two angles according to the matlab view() command.
% options.colorbar : string to control if colorbar is 'on' or 'off'.
% dfield : displacement field.
% cfield : field (typically displacement, strain or stress) used for 
%          coloring the elements.
%
% Revisions:
%   Version 1.0    10.08.2012   Jos� Pedro Blasques: handling multiple
%   element types and detail plotting.
%
% (c) DTU Wind Energy
%********************************************************

%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
   %Nodes in detail
   nl_2d = unique(utils.el_2d(el_2d,2:end));
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
   nl_2d = utils.nl_2d;
end



%% Determine displacement scaling based on cross section dimensions
%Cross section dimensions
maxx=max(utils.nl_2d(:,2));
maxy=max(utils.nl_2d(:,3));
maxs=max(maxx,maxy);
%Ref length
refs=maxs/10;
%Maximum displacement
maxd=max(dfield);
%Scaling ratio
scaledfield=maxd/refs;

%% Calculate total displacement
% TotalDisp=sqrt(dfield(1:3:end,:)^2+dfield(2:3:end,:)^2+dfield(3:3:end,:)^2);
% colormap;

%% Change default axes fonts.
fontname='Times New Roman';
fontsize=12;
% Change default axes fonts.
set(0,'DefaultAxesFontName', fontname)
set(0,'DefaultAxesFontSize', fontsize)

% Change default text fonts.
set(0,'DefaultTextFontname', fontname)
set(0,'DefaultTextFontSize', fontsize)


disp=zeros(3,1);
for ul=1:size(dfield,2)
    fighandle=figure;%ul);
    if(isfield(options,'scale'))
        scalefac=options.scale;
    else
        scalefac=scaledfield(ul)^-1;
    end
    for counter=1:ne_2d
        i=el_2d(counter);
        %Defining constants to make equations readable
        nnpe_2d = utils.element(utils.etype(i)).nnpe_2d;
        vertex_connection = utils.element(utils.etype(i)).vertex_connection;
        %% Initiate vertex position list
        vertex_list_deformed=zeros(nnpe_2d,3);
        vertex_list_undeformed=zeros(nnpe_2d,3);
        for ii=1:nnpe_2d
            for iii=1:2
                disp(iii+1)=utils.nl_2d(utils.el_2d(i,ii+1),iii+1)+...
                    dfield((utils.el_2d(i,ii+1)-1)*3+iii,ul)*scalefac;
                vertex_list_deformed(ii,iii+1)=utils.nl_2d(utils.el_2d(i,ii+1),iii+1)+...
                    dfield((utils.el_2d(i,ii+1)-1)*3+iii,ul)*scalefac;
                vertex_list_undeformed(ii,iii+1)=utils.nl_2d(utils.el_2d(i,ii+1),iii+1);
            end
            disp(3)=dfield((utils.el_2d(i,ii+1)-1)*3+3,ul)*scalefac;
            vertex_list_deformed(ii,1)=dfield((utils.el_2d(i,ii+1)-1)*3+3,ul)*scalefac;
            vertex_list_undeformed(ii,1)=0;
        end
        if( isfield(options,'deformed'))
           if(strcmp(options.deformed,'on'))
               vertex_list=vertex_list_deformed;
           else
               vertex_list=vertex_list_undeformed;
           end
        else
            vertex_list=vertex_list_undeformed;
        end
        if(isfield(options,'color'))
            if(strcmp('abs',options.color))
                %Absolute displacement
                facecolor=repmat(...
                    sqrt( ...
                    dfield((utils.el_2d(i,1+1)-1)*3+1,ul)^2+ ...
                    dfield((utils.el_2d(i,1+1)-1)*3+2,ul)^2+ ...
                    dfield((utils.el_2d(i,1+1)-1)*3+3,ul)^2  ...
                    ),...
                    1,nnpe_2d);
            elseif(strcmp('ux',options.color))
                %x-displacement
                facecolor=repmat( ...
                    dfield((utils.el_2d(i,1+1)-1)*3+1,ul),...
                    1,nnpe_2d);
            elseif(strcmp('uy',options.color))
                %y-displacement
                facecolor=repmat( ...
                    dfield((utils.el_2d(i,1+1)-1)*3+2,ul),...
                    1,nnpe_2d);
            elseif(strcmp('uz',options.color))
                %z-displacement
                facecolor=repmat( ...
                    dfield((utils.el_2d(i,1+1)-1)*3+3,ul),...
                    1,nnpe_2d);
            elseif(strcmp('material',options.color))
                %Material
                facecolor=[ utils.emat(i,2) utils.emat(i,2) utils.emat(i,2) ]'/max(utils.emat(:,2));
            elseif(strcmp('cfield',options.color))
                if(nargin==4)
                    %Field component
                    facecolor=repmat( cfield(counter),1,nnpe_2d);
                else
                    error('ErrorTests:convertTest', ... 
                        'cfield is not defined at input.')
                end
            elseif(strcmp('none',options.color))
                %None
                facecolor='none';
            else
                error('ErrorTests:convertTest', ...
                    'options.cfield value is not valid')
            end
        else
            facecolor='none';
        end
        % Plot patch
        if strcmp('none',facecolor)
            pa=patch('Vertices',vertex_list,'Faces',vertex_connection);
            set(pa,'facecolor','w');
        elseif strcmp('material',options.color)
            pa=patch('Vertices',vertex_list,'Faces',vertex_connection);
            set(pa,'facecolor',facecolor);
        else
            pa=patch('Vertices',vertex_list,'Faces',vertex_connection, 'facecolor', 'flat',  'edgecolor', 'interp');
            set(pa,'FaceVertexCData',facecolor');
        end
        %Overlay undeformed
        if(isfield(options,'overlay'))
            if(strcmp('undef',options.overlay))
                pa=patch('Vertices',vertex_list_undeformed,'Faces',vertex_connection, 'facecolor', 'none','edgecolor', [0.5 0.5 .5]);
            end
        end
    end
    if isfield(options,'view')
        view(options.view(1),options.view(2))
    else
        view(136,10) %default
    end
    xlabel('x')
    ylabel('y')
    zlabel('z')
    if(isfield(options,'colorbar'))
        if(strcmp(options.colorbar,'on'))
            colorbar
        end
    end
    box off
    hold off
    axis equal
    axis off
    if(isfield(options,'zoom'))
        zoom(options.zoom);
    end
end

if(isfield(options,'cs'))
    if(strcmp(options.cs,'on'))
        %Center detail
        xc = mean(utils.nl_2d(nl_2d(:,1),2));
        yc = mean(utils.nl_2d(nl_2d(:,1),3));
        %Plot coordinate system
        figedge=[max(utils.nl_2d(nl_2d(:,1),2:3)) abs(max(max(utils.nl_2d(nl_2d(:,1),2:3))));
            min(utils.nl_2d(nl_2d(:,1),2:3)) abs(min(min(utils.nl_2d(nl_2d(:,1),2:3))))];
        hold on
        line([1E-4*figedge(1,1) 0.4*figedge(1,1)],[xc xc],[yc yc],'color','k','linewidth',1.5)
        text(1.05*0.4*figedge(1,1),xc,yc,'z','fontsize',fontsize,'FontName',fontname)
        line([1E-4*figedge(1,1) 1E-4*figedge(1,1)],[xc figedge(1,1)],[yc yc],'color','k','linewidth',1.5)
        text(0,figedge(1,1),yc,'x','fontsize',fontsize,'FontName',fontname)
        line([1E-4*figedge(1,1) 1E-4*figedge(1,1)],[xc xc],[yc figedge(1,2)],'color','k','linewidth',1.5)
        text(0,xc,figedge(1,2),'y','fontsize',fontsize,'FontName',fontname)
        hold off
    end
end



end