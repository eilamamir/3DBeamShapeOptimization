function [fighandle] = BECAS_PlotElementResults(savefig_flag,utils,ElementResults)
%********************************************************
% File: BECAS_PlotInput.m
%   Function to plot results associated with each element, namely, strains
%   and stresses.
%
% Syntax:
%   [fighandle] = BECAS_PlotElementResults(utils,ElementResults)
%
% Input:
%   savefig_flag :  Flag to save figures (1 for saving)
%   utils   :  Structure with all inputdata and other data necessary (see
%              BECAS_utils).
%   ElementResults  :  (ne x 6) Array with strain or stress results.
%
% Output:
%   fighandle : Figure handle   
%
% Calls:
%
% Revisions:
%   Version 1.0    28.09.2012   Jos� Pedro Blasques
%   Version 1.1    01.10.2012   Jos� Pedro Blasques: Introduced the
%   savefig_flag.
%   Version 1.2    25.11.2012   Jos� Pedro Blasques: Made it work with T6
%   elements.
%   Version 1.3    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%   Version 2.4    20.08.2014   JPBL; Added the possibility of plotting
%   only a detail based on the input of edetail.
%
% (c) DTU Wind Energy
%********************************************************

fprintf(1,'> Started plotting element results...');

%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
end

%Initialize arrays
%Set titles
titleC={'xx','yy','xy','xz','yz','zz'};

%Produce the six figures corresponding to the six strain components
fighandle=figure;
%Loop the six components
for p=1:size(ElementResults,2)
    subplot(2,3,p)
%     fh=figure;
    hold on
    colormap;
    %Define colorbar limits
    caxis([(min(ElementResults(:,p))-0.1*min(ElementResults(:,p))) ...
        (max(ElementResults(:,p))+0.1*abs(max(ElementResults(:,p))))]);
    %Plot patches
    iv=0;
    for counter=1:ne_2d
        i=el_2d(counter);
        %Defining constants to make equations readable
        nnpe_2d = utils.element(utils.etype(i)).nnpe_2d;
        vertex_connection = utils.element(utils.etype(i)).vertex_connection;
        %Define vertex or nodal positions
        vertex_list=zeros(nnpe_2d,3);
        for ii=1:nnpe_2d
            iv=iv+1;
            for iii=1:2
                vertex_list(ii,iii)=utils.nl_2d(utils.el_2d(i,ii+1),iii+1);
                vertex_list(ii,3)=0;
            end
        end
        %Plot patches
        facecolor=ones(nnpe_2d,1)*ElementResults(counter,p);
        pa=patch('Vertices',vertex_list,...
            'Faces',vertex_connection,...
            'facecolor', 'interp',...
            'edgecolor', 'none',...
            'facealpha', 1);
        set(pa,'FaceVertexCData',facecolor);
    end
    %Graphic properties
    title(titleC{p});
    xlabel('x')
    ylabel('y')
    zlabel('z')
    colorbar;
    box off
    hold off
    axis equal
    axis off
    
end

if (savefig_flag)
    saveas(fighandle, 'BECAS_FIG_ElementResults','fig');
end

fprintf(1,'DONE! \n');

end

