function BECAS_PlotElements( utils )
%********************************************************
% File: BECAS_PlotElements.m
%   Function to plot the cross section finite element mesh
%
% Syntax:
%   BECAS_PlotElements( utils )
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   Matlab figure
%
% Calls:
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    21.08.2012   Jos� and Robert : Plotting all nodes
%   (including the midside)
%   Version 1.2    21.10.2013   Jos� Pedro Blasques: Added the possibility
%   doing the calculations only for a small portion of the elements defined
%   in the list util.edetail.
%   Version 1.2    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************


%Check if calculating only for detail
if isfield(utils,'edetail')
   ne_2d=size(utils.edetail,1);
   el_2d=utils.edetail;
else
   ne_2d=utils.ne_2d;
   el_2d=utils.el_2d(:,1);
end

%Start looping elements
iv=0;
for e=1:ne_2d
    i=el_2d(e);
    %Defining constants to make equations readable
    nnpe_2d = utils.element(utils.etype(i)).nnpe_2d;
    vertex_connection = utils.element(utils.etype(i)).vertex_connection;
    vertex_list=zeros(nnpe_2d,3);
    for ii=1:nnpe_2d
        iv=iv+1;
        for iii=1:2
            vertex_list(ii,iii)=utils.nl_2d(utils.el_2d(i,ii+1),iii+1);
        end
        vertex_list(ii,3)=0;
        %Plot node numbers
%         text(utils.nl_2d(utils.el_2d(i,ii+1),2),utils.nl_2d(utils.el_2d(i,ii+1),3),1,num2str(utils.nlabel(utils.el_2d(i,ii+1))));
    end
    patch('Vertices',vertex_list,'Faces',vertex_connection,...
        'FaceColor',[1 1 1],'EdgeColor',[0. 0. 0.],'FaceAlpha', 0);
end

end