function [ outvec ] = BECAS_Becas2Hawc2( filename, r, const, props, utils )
%********************************************************
% File: BECAS_Becas2Hawc2.m
%   This function generates input to HAWC2 based on the cross section
%   analysis results from BECAS
%
% Syntax:
%   BECAS_Becas2Hawc2( filename, r, const, props )
%
% Input:
%   filename:  String holding the name of the file to which the HAWC2 data
%              is output. Set to false (boolean) if no file need to be printed.
%   r       :  Radial position of section
%   const   :  Structure with constitutive matrices (see
%              BECAS_Constitutive*)
%   props   :  Structure with constitutive matrices (see
%              BECAS_CrossSectionProps)
%   utils   :  Structure with all inputdata and other data necessary (see
%              BECAS_utils).
%
% Output:
%    HAWC cross sectional data vector, and optionally optionally
%    that vector to a file with filename
%
% Calls:
%
% Date:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%
%   Version 2.0    07.09.2012   Jos� Pedro Blasques: Removed BECAS_utils
%   and changed the input to receive the utils structure. Changed the ouput
%   to pass the props structure.
%
% (c) DTU Wind Energy
%********************************************************

fprintf(1,'> Started generating input for HAWC2 and writing to BECAS2HAWC2.out...')

if utils.hawc2_flag
    fprintf(1,'> st file for HAWC2 based on original beam model...')
    %Mass per unit length
    mpl= const.Ms(1,1);
    
    %Mass center coordinates with respect to c/2
    xm= props.MassX;
    ym= props.MassY;
    
    %Radius of inertia with respect to elastic center
    p=[ props.ElasticX  props.ElasticY]; theta=rad2deg( props.AlphaPrincipleAxis_ElasticCenter);
    [Msprime]=BECAS_TransformCrossSectionMatrix(const.Ms,p,theta);
    rx=sqrt(Msprime(4,4)/ mpl);
    ry=sqrt(Msprime(5,5)/ mpl);
    
    %Shear center coordinates with respect to c/2
    xs= props.ShearX;
    ys= props.ShearY;
    
    %Modulus of elasticity (averaged)
    p=[ props.ElasticX  props.ElasticY]; theta=rad2deg( props.AlphaPrincipleAxis_ElasticCenter);
    [Ksprime]=BECAS_TransformCrossSectionMatrix(const.Ks,p,theta);
    Em=Ksprime(3,3)/ props.AreaTotal; %
    %Shear modulus (averaged)
    % Em=0;
    Gm=0;
    nQ=(6)*(6);
    for e=1:utils.ne_2d
        Qe=utils.Q(:,:,e);
        Gm=Gm+utils.ElArea(e)*Qe(4,4);
    end
    Gm=Gm/props.AreaTotal;
    
    %Area moment of inertia with respect to principal bending axis
    Ax_ea=Ksprime(4,4)/Em;
    Ay_ea=Ksprime(5,5)/Em;
    
    %Torsional stiffness
    p=[ props.ShearX  props.ShearY]; theta=rad2deg(0);
    [Ksprime]=BECAS_TransformCrossSectionMatrix(const.Ks,p,theta);
    K=Ksprime(6,6)/Gm;
    
    %Shear factor
    kx=Ksprime(1,1)/(Gm* props.AreaTotal);
    ky=Ksprime(2,2)/(Gm* props.AreaTotal);
    
    %Cross section area
    A= props.AreaTotal;
    
    %Structural pitch
    theta_s=rad2deg(props.AlphaPrincipleAxis_ElasticCenter);
    
    %Elastic center position
    xe= props.ElasticX;
    ye= props.ElasticY;
    
    %Output to HAWC2
    outvec=[r mpl xm ym rx ry xs ys Em Gm Ax_ea Ay_ea K kx ky A theta_s xe ye];
    
    %Print to file, but use robust way to construct the full output path
    % Linux uses / to separate folders, Windows uses \
    % only print to a file when filename is not false
    if filename ~= false
        filename=fullfile(pwd, filename);
        fid = fopen(filename,'a+');
        fprintf(fid,'%19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g\n', outvec);
        fclose(fid);
    end
    
else
    fprintf(1,'> st file for HAWC2 based on fully populated stiffness matrix...')
    %Mass per unit length
    mpl= const.Ms(1,1);
    
    %Mass center coordinates with respect to c/2
    xm= props.MassX;
    ym= props.MassY;
    
    %Radius of inertia with respect to elastic center
    p=[ props.ElasticX  props.ElasticY]; theta=rad2deg( props.AlphaPrincipleAxis_ElasticCenter);
    [Msprime]=BECAS_TransformCrossSectionMatrix(const.Ms,p,theta);
    rx=sqrt(Msprime(4,4)/ mpl);
    ry=sqrt(Msprime(5,5)/ mpl);
    
    %Structural pitch
    theta_s=rad2deg(props.AlphaPrincipleAxis_ElasticCenter);
    
    %Elastic center position
    xe= props.ElasticX;
    ye= props.ElasticY;
    
    % Stiffness matrix at the elastic center rotated along principle axis
    [Ksprime]=BECAS_TransformCrossSectionMatrix(const.Ks,p,theta);
    
    %Output to HAWC2
    outvec=[r mpl xm ym rx ry theta_s xe ye ...
        Ksprime(1,1) Ksprime(1,2) Ksprime(1,3) Ksprime(1,4) Ksprime(1,5) Ksprime(1,6)...
        Ksprime(2,2) Ksprime(2,3) Ksprime(2,4) Ksprime(2,5) Ksprime(2,6)...
        Ksprime(3,3) Ksprime(3,4) Ksprime(3,5) Ksprime(3,6)...
        Ksprime(4,4) Ksprime(4,5) Ksprime(4,6)...
        Ksprime(5,5) Ksprime(5,6)...
        Ksprime(6,6)];
    
    %Print to file, but use robust way to construct the full output path
    % Linux uses / to separate folders, Windows uses \
    % only print to a file when filename is not false
    if filename ~= false
        filename=fullfile(pwd, filename);
        fid = fopen(filename,'a+');
        fprintf(fid,'%19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g %19.12g\n', outvec);
        fclose(fid);
    end
    
end

    function [var]=rad2deg(var)
        %Turning radians to degrees
        var=var*180/(pi);
    end

fprintf(1,'DONE! \n');

end
