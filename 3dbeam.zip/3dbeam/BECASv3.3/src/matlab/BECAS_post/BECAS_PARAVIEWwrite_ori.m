function [ Filename1, Filename2, Filename3 ] = BECAS_PARAVIEWwrite_ori(utils, paraview)
% Write unit vectors of material orientation to three files


% Determine unit vector orientations

% Unit vectors are scaled so that they visualize nicely when arrows
% with scale factor
l_char_ele = sqrt(max(utils.ElArea));

vdir=zeros(utils.ne_2d,3,3);
for i=1:utils.ne_2d
    %Fiber rotation
    rmat1=[cosd(paraview.emat(i,4))  -sind(paraview.emat(i,4)) 0;
        sind(paraview.emat(i,4))   cosd(paraview.emat(i,4)) 0;
        0 0 1];
    %Fiber plane rotation
    rmat2=[cosd(paraview.emat(i,3))  0 sind(paraview.emat(i,3));
        0 1 0;
        -sind(paraview.emat(i,3))  0 cosd(paraview.emat(i,3))];
    %Unit vectors, scaled
    vdir(i,:,1)=(rmat1*rmat2*[0;0;1])'*l_char_ele;
    vdir(i,:,2)=(rmat1*rmat2*[1;0;0])'*l_char_ele;
    vdir(i,:,3)=(rmat1*rmat2*[0;1;0])'*l_char_ele;
end

% Write unit vectors to files

Filename1='becas_input.ensi.matori1';
BECAS_PARAVIEWwrite_per_element(Filename1,'BECAS material orientation 1', paraview, 1, vdir(:,:,1));
Filename2='becas_input.ensi.matori2';
BECAS_PARAVIEWwrite_per_element(Filename2,'BECAS material orientation 2', paraview, 1, vdir(:,:,2));
Filename3='becas_input.ensi.matori3';
BECAS_PARAVIEWwrite_per_element(Filename3,'BECAS material orientation 3', paraview, 1, vdir(:,:,3));


end
