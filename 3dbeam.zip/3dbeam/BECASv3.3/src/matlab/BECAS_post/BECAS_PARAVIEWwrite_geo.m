function [Filename] = BECAS_PARAVIEWwrite_geo(utils, paraview, csprops)
% The csprops arguments is optional!
% Centers are only written to the file if csprops is given

%% Open file
Filename='becas_results.ensi.geo';
fid = fopen(Filename,'w+');

%% Header
fprintf(fid,'BECAS input and result data\n');
fprintf(fid,'nodes and elements\n');
fprintf(fid,'node id given\n');
fprintf(fid,'element id given\n');
fprintf(fid,'part\n');
fprintf(fid,'%10d\n',1);
fprintf(fid,'Nodes and elements\n');
fprintf(fid,'coordinates\n');

%% Node list
fprintf(fid,'%10d\n',utils.nn_2d); % number of nodes
fprintf(fid,'%10d\n',utils.nl_2d(:,1));  % node ids
nl_re=reshape(utils.nl_2d(:,2:3),utils.nn_2d,2);
nl_re(:,3)=0;
fprintf(fid,'%12.5e\n',nl_re(:,1)); % x-coords
fprintf(fid,'%12.5e\n',nl_re(:,2)); % y-coords
fprintf(fid,'%12.5e\n',nl_re(:,3)); % z-coords

%% Element list
for i=1:length(paraview.etopochange)-1
    j = i + 1;  % write element form etopochange(i) to etopochange(j)
    from = paraview.etopochange(i);
    to = paraview.etopochange(j)-1;
    numele = to-from+1;  % elements to write
    fprintf(fid,'%s\n',paraview.etopo_string{from}); % topo string
    fprintf(fid,'%10d\n',numele); % number of elements
    fprintf(fid,'%10d\n',utils.elabel(from:to));% element ids
    numnodes = paraview.nnpe_2d(from);
    fprintf(fid,[repmat('%10d',1,numnodes-1) '%10d\n'],paraview.el_2d(from:to,2:numnodes+1)');
end

%% Write centers, if csprops was given
if nargin > 2

    fprintf(fid,'part\n');
    fprintf(fid,'%10d\n',2); % part number
    fprintf(fid,'origin\n');
    fprintf(fid,'coordinates\n');
    fprintf(fid,'%10d\n',1);
    fprintf(fid,'%10d\n',1); % node id     
    fprintf(fid,'%12.5e\n',0.0);
    fprintf(fid,'%12.5e\n',0.0);
    fprintf(fid,'%12.5e\n',0.0);
    
    fprintf(fid,'part\n');
    fprintf(fid,'%10d\n',3);
    fprintf(fid,'elastic center\n');
    fprintf(fid,'coordinates\n');
    fprintf(fid,'%10d\n',1);
    fprintf(fid,'%10d\n',2); % node id     
    fprintf(fid,'%12.5e\n', csprops.ElasticX);
    fprintf(fid,'%12.5e\n', csprops.ElasticY);
    fprintf(fid,'%12.5e\n', 0.0);
    
    fprintf(fid,'part\n');
    fprintf(fid,'%10d\n',4);
    fprintf(fid,'shear center\n');
    fprintf(fid,'coordinates\n');
    fprintf(fid,'%10d\n',1);
    fprintf(fid,'%10d\n',3); % node id     
    fprintf(fid,'%12.5e\n', csprops.ShearX);
    fprintf(fid,'%12.5e\n', csprops.ShearY);
    fprintf(fid,'%12.5e\n', 0.0);
    
    fprintf(fid,'part\n');
    fprintf(fid,'%10d\n',5);
    fprintf(fid,'mass center\n');
    fprintf(fid,'coordinates\n');
    fprintf(fid,'%10d\n',1);
    fprintf(fid,'%10d\n',4); % node id     
    fprintf(fid,'%12.5e\n', csprops.MassX);
    fprintf(fid,'%12.5e\n', csprops.MassY);
    fprintf(fid,'%12.5e\n', 0.0);

end

fclose(fid);
end

