function [Filename1, Filename2] = BECAS_PARAVIEWwrite_el_axes(utils, csprops)

%% Compute vectors
% Scale with characteristic model size

maxx = max(utils.nl_2d(:,2)) - min(utils.nl_2d(:,2));
maxy = max(utils.nl_2d(:,3)) - min(utils.nl_2d(:,3));
char_length_model = max(maxx,maxy);

vec1 = [ cos(csprops.AlphaPrincipleAxis_ElasticCenter);
         sin(csprops.AlphaPrincipleAxis_ElasticCenter);
         0.0]' * char_length_model;
    
vec2 = [ cos(csprops.AlphaPrincipleAxis_ElasticCenter+pi/2);
         sin(csprops.AlphaPrincipleAxis_ElasticCenter+pi/2);
         0.0]' * char_length_model;
    
%% Write to files

Filename1='becas_output.ensi.el_axis1';
BECAS_PARAVIEWwrite_per_node(Filename1,'BECAS elastic axis 1', 3, vec1);

Filename2='becas_output.ensi.el_axis2';
BECAS_PARAVIEWwrite_per_node(Filename2,'BECAS elastic axis 2', 3, vec2);

end
