function [filename] = BECAS_PARAVIEWwrite_per_node(outfilename, header, partnum, data)
%Write per node data in Ensight Gold format
%   Can be read by Paraview of ESI Ensight

%% Open file
fid = fopen(outfilename,'w+');
filename = outfilename; % simply return the outfilename

%% Header
fprintf(fid,'%s\n', header);
fprintf(fid,'part\n');
fprintf(fid,'%10d\n',partnum);
fprintf(fid,'coordinates\n');

%% List of values
fprintf(fid,'%12.5e\n',data);

fclose(fid);
end
