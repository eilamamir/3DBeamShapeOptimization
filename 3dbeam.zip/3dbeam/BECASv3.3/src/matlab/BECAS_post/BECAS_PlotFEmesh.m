function [fighandle] = BECAS_PlotFEmesh( utils )
%********************************************************
% File: BECAS_PlotFEmesh.m
%   Function to plot fiber angles where a vertical line indicates
%   0deg.
%
% Syntax:
%   BECAS_PlotFEmesh( utils )
%
% Input:
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   fighandle : Figure number
%
% Calls:
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    21.08.2012   Robert and Jos� : Introduced figure handle
%   and included it as output
%   Version 1.2    20.08.2014   JPBL; Added the possibility of plotting
%   only a detail based on the input of edetail.
%
% (c) DTU Wind Energy
%********************************************************

fighandle = figure;
hold on
%Plot undeformed shape
BECAS_PlotElements( utils )
%Figure settings
box off
hold off
% axis off
axis equal
%Figure title
title('Finite element mesh');

end