function [ const_ansys ] = BECAS_Becas2ANSYS_APDL( filename, filename_path, sec_num, const )
%********************************************************
% File: BECAS_Becas2ANSYS_APDL.m
%   This function generates input to ANSYS based on the cross section
%   analysis results from BECAS
%
% Syntax:
%   BECAS_Becas2ANSYS_APDL( filename, filename_path, sec_num, const )
%
% Input:
%   filename:  String holding the name of the file to which the ANSYS Beam section data
%              is output. Set to false (boolean) if no file needs to be written.
%   filename_path: path where file is stored
%   sec_num :  number of beam section along axis. 
%              Section number is given by beam section number defined for ANSYS Beam element.
%   
%   const   :  Structure with constitutive matrices (see
%              BECAS_Constitutive*)
%   
% Output:   
%    Besides writing the ANSYS preintegrated composite beam section 
%    to a file the function also returns the constitutive matrices in
%    their reordered form.
%
%********************************************************

%% generate input for APDL file with section data
fprintf(1,'> Generate input for APDL file with section data...');

% Reorder Stiffness Matrix
order_Ks = [3,4,5,6,2,1];
const_ansys.Ks = const.Ks(order_Ks,order_Ks);

% Reorder Mass matrix
order_Ms = [3,1,2,6,4,5];
const_ansys.Ms = const.Ms(order_Ms,order_Ms);

%Print to file, but use robust way to construct the full output path
% Linux uses / to separate folders, Windows uses \
% only print to a file when filename is not false
if filename ~= false
    filename=fullfile(filename_path, filename);
    fid = fopen(filename,'a+');
    
    fprintf(fid,'!! START: Define ANSYS Preintegrated Beam Section for Section ID %i\n\n', sec_num);
    fprintf(fid,'sectype,%i,comb,matrix\n', sec_num);
    % write Stiffness Matrix Information
    fprintf(fid,'! Define Stiffness Matrix for Section ID %i\n', sec_num);
    APDL_Identifier = 'cbmx';
    BECAS_ANSYSWriteStiMassForSection( const_ansys.Ks , APDL_Identifier, fid);
    % write Mass Matrix Information
    fprintf(fid,'\n\n! Define Mass Matrix for Section ID %i\n', sec_num);
    APDL_Identifier = 'cbmd';
    BECAS_ANSYSWriteStiMassForSection( const_ansys.Ms , APDL_Identifier, fid);
    
    fprintf(fid,'\n!! END: Define Section for Section ID %i\n\n\n', sec_num);
    
    fclose(fid);
end

fprintf(1,'DONE! \n');

end
