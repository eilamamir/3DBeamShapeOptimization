function BECAS_ANSYSWriteStiMassForSection( M , APDL_Identifier, fid)
%********************************************************
% File: BECAS_ANSYSWriteStiMassForSection.m
%   Function to write cross section stiffness and mass matrix data 
%   in ANSYS APDL format.
%
% Input:
%   M                 : Matrix to write to file
%   APDL_Identifier   : Identifier of Mass or Stiffness for definition of section of PI Beam
%   fid               : Identifier of the file to write to
% 
%********************************************************

for CRow = 1:length(M)
    fprintf(fid,'%s,%i,', APDL_Identifier,CRow);
    for CCol = 1:length(M(CRow,:))
        if CCol >= CRow
            if CCol ~= length(M(CRow,:))
                fprintf(fid,'%e,', M(CRow,CCol));
            else
                fprintf(fid,'%e\n', M(CRow,CCol));
            end
        end
    end
end

end