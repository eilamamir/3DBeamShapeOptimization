function [ utils ] = BECAS_Q8R_Utils( utils )
%********************************************************
% File: BECAS_Q8R_Jacobian.m
%   Function to set some properties of the Q8R element.
%
% Syntax:
%   [ utils ] = BECAS_Q8R_Utils( utils )
%
% Input:
% utils
%
% Output:
% utils
%
% Calls:
%
% Date:
%   Version 1.0    25.11.2013   Jos� Pedro Blasques
%   Version 1.1    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

utils.element(3).etype_string='Q8R';
utils.element(3).etype=3;
utils.element(3).nnpe_2d=8; %Number of nodes per element
utils.element(3).etopo_string='quad8';
utils.element(3).etopo=23;  %Using VTK numbering
utils.element(3).mdim_2d=24; %Number of dof per element
utils.element(3).gpoints=4; %Number of gauss points
utils.element(3).xxg = [  -0.577350269              -0.577350269               0.577350269               0.577350269];
utils.element(3).yyg = [ -0.577350269               0.577350269              -0.577350269               0.577350269];
utils.element(3).wg = [1 1 1 1];
utils.element(3).vertex_connection = [1 5 2 6 3 7 4 8];
utils.element(3).gpointsOrder = [1 3 4 2];

end