function [ utils ] = BECAS_Q8_Utils( utils )
%********************************************************
% File: BECAS_Q8_Jacobian.m
%   Function to set some properties of the Q8 element.
%
% Syntax:
%   [ utils ] = BECAS_Q8_Utils( utils )
%
% Input:
% utils
%
% Output:
% utils
%
% Calls:
%
% Date:
%   Version 1.0    25.11.2013   Jos� Pedro Blasques
%   Version 1.1    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

utils.element(2).etype_string='Q8';
utils.element(2).etype=2;
utils.element(2).nnpe_2d=8; %Number of nodes per element
utils.element(2).etopo_string='quad8';
utils.element(2).etopo=23;  %Using VTK numbering
utils.element(2).mdim_2d=24; %Number of dof per element
utils.element(2).gpoints=9; %Number of gauss points
utils.element(2).xxg = [ -0.774596669  -0.774596669  -0.774596669  0  0  0  0.774596669  0.774596669  0.774596669];
utils.element(2).yyg = [ -0.774596669   0  0.774596669 -0.774596669  0 0.774596669  -0.774596669  0  0.774596669];
utils.element(2).wg = [ 0.308641975308642         0.493827160493827         0.308641975308642         0.493827160493827         0.790123456790123         0.493827160493827         0.308641975308642 0.493827160493827         0.308641975308642];
utils.element(2).vertex_connection = [1 5 2 6 3 7 4 8];
utils.element(2).gpointsOrder = [1 7 9 3 4 8 6 2];

end