function [ x, y ] = BECAS_T6_InterpPos( pr, xxs, yys )
%********************************************************
% File: BECAS_T6_InterpPos.m
%   Function to map a location in the isoparametric
%   coordinate system into the problem coordinate system
%   using a T6 element.
%
% Syntax:
%   [ x, y ]=BECAS_T6_InterpPos( pr, xx, yy )
%
% Input:
%   pr      :  Vector of nodal positions for element e
%   xx, yy  :  Isoparametric coordinates
%
% Output:
%   x, y    :  Problem coordinates
%
% Calls:
%
% Date:
%   Version 1.0    21.11.2013   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

t1 = 1 - xxs - yys;
t2 = yys * t1;
t5 = xxs * yys;
t8 = xxs * t1;
t11 = 2 * yys;
t13 = yys * (t11 - 1);
t15 = 2 * xxs;
t17 = xxs * (t15 - 1);
t20 = t1 * (1 - t15 - t11);
x = t13 * pr(5) + t17 * pr(3) + 4 * t2 * pr(11) + t20 * pr(1) + 4 * t5 * pr(9) + 4 * t8 * pr(7);
y = t13 * pr(6) + t17 * pr(4) + 4 * t2 * pr(12) + t20 * pr(2) + 4 * t5 * pr(10) + 4 * t8 * pr(8);


end