function [ utils ] = BECAS_T6_Utils( utils )
%********************************************************
% File: BECAS_T6_Jacobian.m
%   Function to set some properties of the T6 element.
%
% Syntax:
%   [ utils ] = BECAS_T6_Utils( utils )
%
% Input:
% utils
%
% Output:
% utils
%
% Calls:
%
% Date:
%   Version 1.0    25.11.2013   Jos� Pedro Blasques
%   Version 1.1    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

utils.element(4).etype_string='T6';
utils.element(4).etype=4;
utils.element(4).nnpe_2d=6; %Number of nodes per element
utils.element(4).etopo_string='tria6';
utils.element(4).etopo=22;  %Using VTK numbering
utils.element(4).mdim_2d=18; %Number of dof per element
utils.element(4).gpoints=7; %Number of gauss points
utils.element(4).xxg = [ 0    	1/2	1    	1/2	0    	0    	1/3];
utils.element(4).yyg = [0    	0    	0    	1/2	1    	1/2	1/3];
utils.element(4).wg = [1/40	1/15	1/40	1/15	1/40	1/15	9/40];
utils.element(4).vertex_connection = [1 4 2 5 3 6];
utils.element(4).gpointsOrder = [1 2 3 4 5 6];

end