function [ Me, Ee, Ce ] = BECAS_T6( enum, Qe, utils )
%********************************************************
% File: BECAS_Q8.m
%   Function to evaluate the 2D finite element matrices
%   using the Q8 elements (two-dimensional four node
%   elements)
%
% Syntax:
%   [ Me, Ee, Ce ] = BECAS_Q8( enum, Qe, utils )
% Input:
%   enum    :  Number of element in 2D FE mesh
%   Qe      :  Material consitutive matrix for element enum
%   utils   :  Structure with input data, useful arrays, and
%              constants
% Output:
%   Me      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Ce      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Ee      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
% Calls:
%
% Date:
%   Version 1.0    21.11.2013   Jos� Pedro Blasques
%   Version 1.1    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

%Initialize arrays
gw=zeros(utils.element(utils.etype(enum)).gpoints,1);
SNa=zeros(6*utils.element(utils.etype(enum)).gpoints,18);
Ba=zeros(6*utils.element(utils.etype(enum)).gpoints,18);

%Start integration
ng=0;
for n=1:utils.element(utils.etype(enum)).gpoints     %Iterate gauss points along the length
    xxs = utils.element(utils.etype(enum)).xxg(n);    %X position of Gauss point
    yys = utils.element(utils.etype(enum)).yyg(n);    %Y position of Gauss point
    wg = utils.element(utils.etype(enum)).wg(n);
    %Evaluate Jacobian - 2D
    [ iJ, detJ ] = BECAS_T6_Jacobian( xxs, yys, utils.pr_2d(:,enum) );
    %Evaluate the element stiffness matrices
    [ SN ] = BECAS_T6_SNe( xxs, yys );
    [ B ] = BECAS_T6_Be( xxs, yys, iJ );
    % Building matrix of matrices
    ng=ng+1;
    SNa(1+(ng-1)*6:ng*6,:)=SN;
    Ba(1+(ng-1)*6:ng*6,:)=B;
    gw(ng)=wg*detJ;
end

%Assemble matrix of constitutive matrices multiplied by the Gauss weights
%and jacobian determinant
Qa=blkdiag(Qe*gw(1),Qe*gw(2),Qe*gw(3),Qe*gw(4),Qe*gw(5),Qe*gw(6),Qe*gw(7));

%Obtain FE matrices
Me=(Qa*SNa)'*SNa;
Ee=Ba'*Qa*Ba;
Ce=Ba'*Qa*SNa;

end