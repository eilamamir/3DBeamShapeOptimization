function [ iJ, detJ ] = BECAS_T6_Jacobian( xxs, yys, pr )
%********************************************************
% File: BECAS_Q8_Jacobian.m
%   Function to evaluate the Jacobian of the T6 element.
%
% Syntax:
%   [ iJ, detJ ] = BECAS_T6_Jacobian( xxs, yys, pr )
%
% Input:
%   xx, yy  :  Isoparametric coordinates
%   pr      :  Vector of nodal positions for element e
%
% Output:
%   iJ      :  Inverse of Jacobian matrix
%   detJ    :  Determinant of Jacobian matrix
% Calls:
%
% Date:
%   Version 1.0    21.11.2013   Jos� Pedro Blasques
%
%
% (c) DTU Wind Energy
%********************************************************

%Evalaute Jacobian matrx
t2 = 4 * yys * pr(11);
t5 = 1 - xxs - yys;
t9 = 4 * xxs * pr(7);
t10 = 2 * xxs;
t11 = t10 - 1;
t15 = 2 * yys;
t16 = 1 - t10 - t15;
t17 = t16 * pr(1);
t19 = 2 * t5 * pr(1);
t22 = 4 * yys * pr(12);
t28 = 4 * xxs * pr(8);
t32 = t16 * pr(2);
t34 = 2 * t5 * pr(2);
t40 = t15 - 1;
J(1,1) = t11 * pr(3) + 4 * t5 * pr(7) + 2 * xxs * pr(3) + 4 * yys * pr(9) - t17 - t19 - t2 - t9;
J(1,2) = t11 * pr(4) + 4 * t5 * pr(8) + 2 * xxs * pr(4) + 4 * yys * pr(10) - t22 - t28 - t32 - t34;
J(1,3) = 0;
J(2,1) = t40 * pr(5) + 4 * t5 * pr(11) + 4 * xxs * pr(9) + 2 * yys * pr(5) - t17 - t19 - t2 - t9;
J(2,2) = t40 * pr(6) + 4 * t5 * pr(12) + 4 * xxs * pr(10) + 2 * yys * pr(6) - t22 - t28 - t32 - t34;
J(2,3) = 0;
J(3,1) = 0;
J(3,2) = 0;
J(3,3) = 1;

%Evaluate determinant of Jacobian
detJ=J(1,1)*J(2,2)-J(1,2)*J(2,1);

%Evaluate inverse
%iJ=J\eye(3);
iJ=eye(3); iJ(1,1)=1/detJ*J(2,2); iJ(1,2)=-1/detJ*J(1,2); iJ(2,1)=-1/detJ*J(2,1); iJ(2,2)=1/detJ*J(1,1);

end