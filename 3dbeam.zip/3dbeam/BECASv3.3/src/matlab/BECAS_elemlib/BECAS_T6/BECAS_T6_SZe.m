function [ SZ ] = BECAS_T6_SZe( xxb, yyb )
%********************************************************
% File: BECAS_T6_SZe.m
%   Function to evaluate matrix SZ for element T6 (see
%   documentation).
%
% Syntax:
%   [ SZ ]=BECAS_T6_SZe( xxb, yyb )
%
% Input:
%   xxb, yyb :  Global coordinates
%
% Output:
%   SZ       :  SZ matrix
%
% Calls:
%
% Date:
%   Version 1.0    21.11.2013   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************
SZ(1,1) = 0;
SZ(1,2) = 0;
SZ(1,3) = 0;
SZ(1,4) = 0;
SZ(1,5) = 0;
SZ(1,6) = 0;
SZ(2,1) = 0;
SZ(2,2) = 0;
SZ(2,3) = 0;
SZ(2,4) = 0;
SZ(2,5) = 0;
SZ(2,6) = 0;
SZ(3,1) = 0;
SZ(3,2) = 0;
SZ(3,3) = 0;
SZ(3,4) = 0;
SZ(3,5) = 0;
SZ(3,6) = 0;
SZ(4,1) = 1;
SZ(4,2) = 0;
SZ(4,3) = 0;
SZ(4,4) = 0;
SZ(4,5) = 0;
SZ(4,6) = -yyb;
SZ(5,1) = 0;
SZ(5,2) = 1;
SZ(5,3) = 0;
SZ(5,4) = 0;
SZ(5,5) = 0;
SZ(5,6) = xxb;
SZ(6,1) = 0;
SZ(6,2) = 0;
SZ(6,3) = 1;
SZ(6,4) = yyb;
SZ(6,5) = -xxb;
SZ(6,6) = 0;


end