function [ Zg ] = BECAS_Zg( utils )
%********************************************************
% File: BECAS_Zg.m
%   Function to assemble matrix Zg which is a stack of Z matrices for each
%   node in the FE mesh.
%
% Syntax:
%   [ Zg ] = BECAS_Zg( utils )
%
% Input:
%   utils  :  Structure with input data, useful arrays, and
%              constants
% Output:
%   Zg     :  Sub-matrix of cross section equilibrium equations
%              holding the constraint equations (see Documentation)
% Calls:
%
% Date:
%   Version 1.0    09.01.2013   Jos� Pedro Blasques
%
% (c) DTU Wind Energy
%********************************************************

%Building Z matrix
Zg=zeros(3*utils.nn_2d,6);
Zg(1:3:end,1)=1;
Zg(2:3:end,2)=1;
Zg(3:3:end,3)=1;
for i=1:utils.nn_2d
    Zg((i-1)*3+1,6)=-utils.nl_2d(i,3);
    Zg((i-1)*3+2,6)=utils.nl_2d(i,2);
    Zg((i-1)*3+3,4)=utils.nl_2d(i,3);
    Zg((i-1)*3+3,5)=-utils.nl_2d(i,2);
end

end