function [ Ixx, Iyy, Ixy, ...
    Axx, Ayy, Axy, Area, Ax, Ay, ...
    Mass, MassX, MassY ] = BECAS_Q4_ElementMassProps( enum, utils )
%********************************************************
% File: BECAS_Q4_ElementMassProps.m
%   Function to determine the element mass properties:
%   mass moments of inertia, area moments, center of area, mass and
%   center of mass. Interpolation is according to Q4 element.
%
% Syntax:
%   [ Ixx, Iyy, Ixy, ...
%       Axx, Ayy, Axy, Area, Ax, Ay, ...
%       Mass, MassX, MassY ] = BECAS_Q4_ElementMassProps( enum, utils )
%
% Input:
%   enum    :  Number of element in cross section FE mesh
%   utils   :  Structure with input data, useful arrays, and
%              constants
%
% Output:
%   Ixx, Iyy, Ixy :  Element moment of inertia
%   Axx, Ayy, Axy :  Element moment of inertia
%   Area    :  Element area
%   AreaX, AreaY :  Coordinates of element area center
%   Mass    :  Element mass per unit length
%   MassX, MassY :  Coordinates of element mass center
%
% Calls:
%
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    25.11.2013   Jos� Pedro Blasques: removed one of the
%   loops on the gauss points which now are defined in BECAS_Utils.
%   Version 1.2    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%   Version 1.3    15.01.2015   Jos� Pedro Blasques: Corrected bug with a
%   missing square in the second moment of area. Thank you to Michael
%   Filipe at Aerovelo for the heads up.
%
% (c) DTU Wind Energy
%********************************************************

%Initialize arrays
Ixx=0;Iyy=0;Ixy=0;
Axx=0;Ayy=0;Axy=0;Area=0;
Ax=0;Ay=0;
Mass=0;MassX=0;MassY=0;

%Start integration
for n=1:utils.element(utils.etype(enum)).gpoints      %Iterate gauss points along the length
    xxs = utils.element(utils.etype(enum)).xxg(n);    %X position of Gauss point
    yys = utils.element(utils.etype(enum)).yyg(n);    %Y position of Gauss point
    wg = utils.element(utils.etype(enum)).wg(n);      %Weight from Gauss quadrature
    %Nodal coordinates of cross section element in cross section
    %coordinate system
    [ xxb, yyb ] = BECAS_Q4_InterpPos( utils.pr_2d( :, enum ), xxs, yys );
    %Evaluate Jacobian - 2D
    [ iJ, detJ ] = BECAS_Q4_Jacobian( xxs, yys, utils.pr_2d( :, enum ) );
    %Sum each contribution and multiply by Gauss weights and determinant of
    %Jacobian
    %Moments of Inertia
    Iyy = Iyy + xxb^2*utils.density(enum)*wg*detJ;
    Ixx = Ixx + yyb^2*utils.density(enum)*wg*detJ;
    Ixy = Ixy + xxb*yyb*utils.density(enum)*wg*detJ;
    %Area moments
    Ayy = Ayy + xxb^2*wg*detJ;
    Axx = Axx + yyb^2*wg*detJ;
    Axy = Axy + xxb*yyb*wg*detJ;
    %Total area
    Area = Area + wg*detJ;
    %Center of area
    Ay = Ay + yyb*wg*detJ;
    Ax = Ax + xxb*wg*detJ;
    %Total Mass
    Mass = Mass + utils.density(enum)*wg*detJ;
    %Mass center
    MassX = MassX + xxb*utils.density(enum)*wg*detJ;
    MassY = MassY + yyb*utils.density(enum)*wg*detJ;
    
end

end
