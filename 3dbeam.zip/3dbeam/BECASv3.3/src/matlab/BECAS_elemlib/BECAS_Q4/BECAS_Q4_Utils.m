function [ utils ] = BECAS_Q4_Utils( utils )
%********************************************************
% File: BECAS_Q4_Jacobian.m
%   Function to set some properties of the Q4 element.
%
% Syntax:
%   [ utils ] = BECAS_Q4_Utils( utils )
%
% Input:
% utils
%
% Output:
% utils
%
% Calls:
%
% Date:
%   Version 1.0    25.11.2013   Jos� Pedro Blasques
%   Version 1.1    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
%
% (c) DTU Wind Energy
%********************************************************

utils.element(1).etype_string='Q4';
utils.element(1).etype=1;
utils.element(1).etopo_string='quad4';
utils.element(1).etopo=9;  %Using VTK numbering
utils.element(1).nnpe_2d=4; %Number of nodes per element
utils.element(1).mdim_2d=12; %Number of dof per element
utils.element(1).gpoints=4; %Number of gauss points
utils.element(1).xxg = [ -0.577350269              -0.577350269               0.577350269               0.577350269];
utils.element(1).yyg = [ -0.577350269               0.577350269              -0.577350269               0.577350269];
utils.element(1).wg = [1 1 1 1];
utils.element(1).vertex_connection = [1 2 3 4];
utils.element(1).gpointsOrder = [1 3 4 2];

end