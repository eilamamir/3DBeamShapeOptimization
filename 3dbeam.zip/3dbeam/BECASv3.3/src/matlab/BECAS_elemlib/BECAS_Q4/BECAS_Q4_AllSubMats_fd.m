function [ Me, Ee, Ce, Re, Le, Ae ] = BECAS_Q4_AllSubMats( enum, Qe, utils )
%********************************************************
% File: BECAS_Q4.m
%   Function to evaluate the 2D finite element matrices
%   using the Q4 elements (two-dimensional four node
%   elements)
%
% Syntax:
%   [ Me, Ee, Ce ] = BECAS_Q4( enum, Qe, utils )
% Input:
%   enum    :  Number of element in 2D FE mesh
%   Qe      :  Material consitutive matrix for element enum
%   utils   :  Structure with input data, useful arrays, and
%              constants
% Output:
%   Me      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Ce      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   Ee      :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
% Calls:
%
% Date:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%   Version 1.1    06.09.2012   Jos� Pedro Blasques: Moved most of the
%   matrix matrix multiplications outside the loop. Now SN, SZ and B are
%   assembled into larger matrices. The routine is about two times faster
%   this way.
%   Version 1.2    25.08.2013   Jos� Pedro Blasques: A, R, and L matrices
%   are not evaluated here any longer. Instead the relations from "Ghiringhelli,
%   G. L., & Mantegazza, P. (1986) Linear, straight and untwisted
%   anisotropic beam section properties from solid finite elements.
%   Composites Engineering, 4(12), 1225�1239" are used in
%   BECAS_Assemble_Ks. The assembly time was reduced by 3 secs from 17 to
%   14 secs (20% faster) for the Detailed WT cross section example.
%   Version 1.3    25.11.2013   Jos� Pedro Blasques: removed one of the
%   loops on the gauss points which now are defined in BECAS_Utils.
%   Version 1.4    30.11.2013   Jos� Pedro Blasques: Rewrote to accomodate
%   for multiple elements. Using new utils.element.field syntax for element
%   properties.
%
% (c) DTU Wind Energy
%********************************************************

%Initialize variables
gw=zeros(utils.element(utils.etype(enum)).gpoints,1);
SNa=zeros(6*utils.element(utils.etype(enum)).gpoints,12);
Ba=zeros(6*utils.element(utils.etype(enum)).gpoints,12);

%Start integration
ng=0;
for n=1:utils.element(utils.etype(enum)).gpoints     %Iterate gauss points along the length
    xxs = utils.element(utils.etype(enum)).xxg(n);    %X position of Gauss point
    yys = utils.element(utils.etype(enum)).yyg(n);    %Y position of Gauss point
    wg = utils.element(utils.etype(enum)).wg(n);
    %Evaluate Jacobian - 2D
    [ iJ, detJ ] = BECAS_Q4_Jacobian( xxs, yys, utils.pr_2d(:,enum) );
    %Evaluate the element matrices
    [ SN ] = BECAS_Q4_SNe( xxs, yys );
    [ B ] = BECAS_Q4_Be( xxs, yys, iJ );
    % Building matrix of matrices
    ng=ng+1;
    SNa(1+(ng-1)*6:ng*6,:)=SN;
    Ba(1+(ng-1)*6:ng*6,:)=B;
    gw(ng)=wg*detJ;
end

%Assmeble matrix of constitutive matrices multiplied by the Gauss weights
%and jacobian determinant
Qa=blkdiag(Qe*gw(1),Qe*gw(2),Qe*gw(3),Qe*gw(4));

%Obtain FE matrices
Me=(Qa*SNa)'*SNa;
Ee=Ba'*Qa*Ba;
Ce=Ba'*Qa*SNa;

%finiding specific active element DOFs
an = utils.el_2d(enum,2:5)'; %active nodes of element e
ad = [an(1)*3-2:3*an(1),an(2)*3-2:3*an(2),an(3)*3-2:3*an(3),an(4)*3-2:3*an(4)]'; %active dofs

Re=Ce*utils.Zg(ad,:);
Le=Me*utils.Zg(ad,:);
Ae=utils.Zg(ad,:)'*Me*utils.Zg(ad,:);

end