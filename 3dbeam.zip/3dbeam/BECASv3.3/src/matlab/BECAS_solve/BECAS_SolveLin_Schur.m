function [ Ks, w, dw, facMat ] = BECAS_SolveLin_Schur( K11, H, G22 )
%********************************************************
% File: BECAS_SolveLin.m
%   Function to solve the linear system of equations associated
%   with the cross section equilibrium equations using Schur complement and
%   lu factorization.
%
% Syntax:
%   [ Ks, X1, Y1, X0, Y0 ] = BECAS_SolveLin( M, C, E, R, L, A, D )
% Input:
%   A       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   R       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   L       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   M       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   C       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   E       :  Sub-matrix of cross section equilibrium equations
%              (see Documentation)
%   D       :  Sub-matrix of cross section equilibrium equations
%              holding the constraint equations (see Documentation)
% Output:
%   Ks      :  Cross section stiffness matrix
%   X1      :  Matrix of solutions dX/dz to cross section equilibrium
%              equations ( du/dz = dX/dz * theta )
%   Y1      :  Matrix of solutions dY/dz to cross section equilibrium
%              equations ( dpsi/dz = dY/dz * theta )
%   X0      :  Matrix of solutions X to cross section equilibrium
%              equations ( u = X * theta )
%   Y0      :  Matrix of solutions Y to cross section equilibrium
%              equations ( psi = Y * theta )
% Calls:
%
%
% Revisions:
%   Version 1.0    07.02.2012   Jos� Pedro Blasques
%
%   Version 1.1    27.08.2012   Jos� and Robert: Using the Schur complement
%   of E and lu factorization. Things seem to work but for some problems
%   Matlab issues a warning about S being singular. No issues when
%   factorizing E. Many of the matrices are gathered using horzcat which is
%   faster.
%
%   Version 1.2    04.09.2012   Jos�: Solved the problem with the
%   singularity by using a differet partition of the system matrix. This
%   implementation is about 100 times faster than the normal
%   BECAS_SolveLin and should use less memory. Preordering for decreased
%   bandwidth has also been included based on symrcm (Cuthill-McKee
%   algorithm). Thank you to Mathias Stolpe and Anders Melchior-Hansen for
%   guidance.
%
%
% (c) DTU Wind Energy
%********************************************************

%Auxiliary constants
nEx=size(K11,1)-12;
nAx=6;


%% Build matrices for Schur complement calculation

%Set size of sub matrices for Schur complement method
nrow=18;
nrowl=nrow-1;

%Breaking matrices for reducing bandwidth
As = K11(1:end-nrow,1:end-nrow);
Bs=K11(end-nrow+1:end,1:end-nrow);
Cs=K11(end-nrow+1:end,end-nrow+1:end);

%Factorize and determine Schur complement
[facMat.S, facMat.Ls, facMat.Us, facMat.Ps, facMat.Qs, ...
    facMat.p, facMat.pinv] = BECAS_SolveFactorize(As, Bs, Cs);
   

%% Solving first linear system to determine dX and dY

%Build right hand side
T=zeros(6);
T(1,5)=-1;
T(2,4)=1;
rhs = sparse([ zeros(nEx,6); T' ; zeros(6)]);

%Build f and g
f = rhs(1:end-nrow,:);
g = rhs(end-nrowl:end,:);

[dw] = BECAS_SolveSubProbSchur(f,g,Bs,facMat);

%% Solving second linear system to determine X and Y

%Build right hand side using first solutions
rhs = sparse([ zeros(nEx,6); eye(6) ; zeros(6)]) - (H'-H)*dw;

%Build f and g
f = rhs(1:end-nrow,:);
g = rhs(end-nrowl:end,:);

[w] = BECAS_SolveSubProbSchur(f,g,Bs,facMat);

%% Evaluate compliance matrix and stiffness matrix
%Compliance matrix

Fs=w'*(K11*w+H'*dw) + dw'*(H*w+G22*dw);

%Stiffness matrix
Ks=Fs\eye(6);

end


% G=[E            R        zeros(nEx,6) C'           zeros(nEx,6) zeros(nEx,6);
%     R'           A        zeros(6)     L'           zeros(6)     zeros(6);
%     zeros(6,nEx) zeros(6) zeros(6)     zeros(6,nEx) zeros(6)     zeros(6);
%     C            L        zeros(nEx,6) M            zeros(nEx,6) zeros(nEx,6);
%     zeros(6,nEx) zeros(6) zeros(6)     zeros(6,nEx) zeros(6)     zeros(6);
%     zeros(6,nEx) zeros(6) zeros(6)     zeros(6,nEx) zeros(6)     zeros(6);];
