function [S, Ls, Us, Ps, Qs, p, pinv] = BECAS_SolveFactorize2(As, Bs, Cs)

%Reordering for sparsity
% p=symrcm(As);
% n=size(p,2);
% pinv=zeros(1,n);
% pinv(p)=1:n;

%Factorizing
[Ls,Us,Ps,Qs]=lu(As);

%Schur complement method
S=Ls\(Ps*Bs(:,p)');
S=Us\S;
S=Qs*S;

S=Cs-Bs(:,p)*S;

end