function [lhs] = BECAS_SolveSubProbSchur(f,g,Bs,facMat)

%Determine As^-1*f
rhs = f;
Asf = BackForSubs(rhs,facMat);

%Determine q
rhs = g-Bs*Asf;
q = facMat.S\rhs;

%Determine p
rhs = f - Bs'*q;
p = BackForSubs(rhs,facMat);

%Assemble solution vector
lhs=[p; q];

end

function [lhs] = BackForSubs(rhs,facMat)

lhs = facMat.Ls\(facMat.Ps*rhs(facMat.p,:));
lhs = facMat.Us\lhs;
lhs = facMat.Qs*lhs;
lhs = lhs(facMat.pinv,:);

end