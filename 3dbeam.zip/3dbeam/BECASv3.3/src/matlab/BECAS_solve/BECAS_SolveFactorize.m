function [S, Ls, Us, Ps, Qs, p, pinv] = BECAS_SolveFactorize(As, Bs, Cs)

%Reordering for sparsity
p=symrcm(As);
n=size(p,2);
pinv=zeros(1,n);
pinv(p)=1:n;

%Factorizing
[Ls,Us,Ps,Qs]=lu(As(p,p));

%Schur complement method
S=Ls\(Ps*Bs(:,p)');
S=Us\S;
S=Qs*S;

S=Cs-Bs(:,p)*S;

end