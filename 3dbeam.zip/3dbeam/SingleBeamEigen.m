function SingleBeamEigen(dx,dy,dz,nmem,npts,nelx,nely,E,nu,rho,volfrac,BCs)
 
%A single 3D beam shape optimization of the fundamental frequency maximization problem
% used in 'Free form shape optimization of three dimensional beams using cross section analysis'
% https://doi.org/10.1016/j.ijsolstr.2023.112331
% it uses a high order arbitrary cross section beam calculated numerically
% where its design is updated using shape optimization process. For more
% details see the aforementioned paper.
%
%Inputs:
%   dx,dy,dz - the rectangular physical dimensions
%   nmem - number of beam members.
%   npts - number of control points of the bspline curve that represents the cross section's boundary
%   nelx,nely - number of cross section's planar elements
%   E   - modulus of elasticity
%   nu  - Poisson ratio.
%   rho - physical density
%   volfrac - the volume fraction
%   BCs: cf - one side fully clampped and one free (like a cabtilever)
%        ps - one side is pinned, i.e. all translational as well as
%        twisting DOFs are zero in one side and one side the axial DOF is
%        free.
%        pp - pinned pinned similarly as ps but both sides are pinned.
%        cc - clampped-clammped: all 6 DOFs in both sides are set to zero.


error('Change the path on next line and uncomment it, and then comment the line of this message');
[basepath]='C:\your_full_dir_path'; % please update your user dir here
addpath(genpath(fullfile(basepath,'BeamCalcBECAS')));
addpath(genpath(fullfile(basepath,'BECASv3.3')));
addpath(genpath(fullfile(basepath,'bsplines')));
addpath(genpath(fullfile(basepath,'MMA subroutines')));
addpath(genpath(fullfile(basepath,'Misc')));
addpath(genpath(fullfile(basepath,'postProcessing')));


%% Building the physical domain
% dx = 1; dy = 1; dz = 4; grid = [3,3,3]; nseg = 2;

close all;
Vol = dx*dy*dz;
gsdata = beamconstruct(dz,nmem);
nnodes = gsdata.nnodes;
membersg = cell(nmem,1);

for nm = 1:nmem %attributing geometrical properties to each member object - not needed for a single axial beam, yet I kept it here...
   membersg{nm}.L = gsdata.L(nm); %member length
   membersg{nm}.nodes = gsdata.memconnect(nm,:);
   membersg{nm}.IX = gsdata.IX(gsdata.memconnect(nm,:),:);
   membersg{nm}.Rt = eye(18); %Because the local and global frames coincide we use here the 18x18 eye matrix as a 'rotaion matrix'
end

Vstar = volfrac*Vol;
nelem = nelx*nely; %# of elements for cross section calc.
dsc = nelem*100; %discretization of the bspline - derivied from the 2d FE discretization of the cross section
spord = 4; % polynomial order - 1 of the bspline basis function
ndofs = 6*nnodes;
alldofs = 1:ndofs;

switch BCs
    case 'cf' %one side fixed all 6 DOFs
        fixednodes = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)))'; 
        fixeddofs = sort([6*fixednodes-5,6*fixednodes-4,6*fixednodes-3,6*fixednodes-2,6*fixednodes-1,6*fixednodes]); %all 6 DOFs fixed
        desmem = 1:nmem;
        markdesmem = 1:nmem-1;
    case 'pp' % simply supported both sides - all translation dofs are fixed together with twisting dofs
        fixednodes = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)) | gsdata.IX(:,3)==max(gsdata.IX(:,3)))';
        fixeddofs = sort([6*fixednodes-5,6*fixednodes-4,6*fixednodes-3,6*fixednodes]); %all translational DOFs fixed  as well as torsion DOF (simply - supported)
        if logical(mod(nmem,2)) %odd number of members - 1 middle member out of the design
            nondesmem = find(gsdata.memconnect(:,2) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))));            
        else % even number of members - 2 middle members out of the design
            nondesmem = find(gsdata.memconnect(:,3) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))) | gsdata.memconnect(:,1) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))));           
        end
        markdesmem = setdiff(1:nmem,nondesmem);
        desmem = 1:nmem;
    case 'ps' %one side pinned one side simply supported i.e. axial translation free
        fixednodes1 = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)))';
        fixednodes2 = find(gsdata.IX(:,3)==max(gsdata.IX(:,3)))';
        fixeddofs1 = [6*fixednodes1-5,6*fixednodes1-4,6*fixednodes1-3,6*fixednodes1];
        fixeddofs2 = [6*fixednodes2-5,6*fixednodes2-4,6*fixednodes2];
        fixeddofs = sort([fixeddofs1,fixeddofs2]);
        if logical(mod(nmem,2)) %odd number of members - 1 middle member out of the design
            nondesmem = find(gsdata.memconnect(:,2) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))));            
        else % even number of members - 2 middle members out of the design
            nondesmem = find(gsdata.memconnect(:,3) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))) | gsdata.memconnect(:,1) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))));           
        end
        markdesmem = setdiff(1:nmem,nondesmem);
        desmem = 1:nmem;
    case 'cc'
        fixednodes = find(gsdata.IX(:,3)==min(gsdata.IX(:,3)) | gsdata.IX(:,3)==max(gsdata.IX(:,3)))';
        fixeddofs = sort([6*fixednodes-5,6*fixednodes-4,6*fixednodes-3,6*fixednodes-2,6*fixednodes-1,6*fixednodes]); %all 6 DOFs fixed    
        if logical(mod(nmem,2)) %odd number of members - 1 middle member out of the design
            nondesmem = find(gsdata.memconnect(:,2) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))));            
        else % even number of members - 2 middle members out of the design
            nondesmem = find(gsdata.memconnect(:,3) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))) | gsdata.memconnect(:,1) == find(gsdata.IX(:,3) == median(gsdata.IX(:,3))));            
        end
        markdesmem = setdiff(1:nmem,nondesmem);
        desmem = 1:nmem;
    otherwise
        error('not a legal boundary condition');
end

freedofs = setdiff(alldofs,fixeddofs);

%% Setting design variables and box constraints

%box constraints for all members:
boxdiag = sqrt(dx^2+dy^2);
circr = min(dx,dy)/10;
Vtmp = 0;
theta0 = 0; %inclined angle of cpts positioning
px = zeros(npts,1); py = zeros(npts,1);
xmin = - ones(npts,1); xmax = ones(npts,1);
ymin = - ones(npts,1); ymax = ones(npts,1);
%Setting initial cross section shape as a circular cross section IAW with the volume fraction (a bit less than V*)
VstartRatio = 1; %initial volume to start with w.r.t. V* to calculate the initial shape
while Vtmp/Vstar < VstartRatio && (min(px) > min(xmin) || min(py) > min(ymin) || max(px) < max(xmax) || max(py) < max(ymax)) %|| Ainit<0.1*boxx*boxy

    [px,py,xmin,xmax,ymin,ymax] = CircCpts(npts,circr,theta0*pi/180,0,0,dx,dy,1e-6*min([dx,dy]));
    [Lpinit,~,~,~] = contpolygon(px,py);    
    [~,~,~,~,~,~,Ainit,~,~] = ClosedUnclampedBspline([px;py],spord,dsc); %construction of B-spline
    Vtmp = Ainit*sum(gsdata.L);
    circr = 1.05*circr;
end

%setting constant mass matrix for the small preserved additional mass:
[~,~,~,~,~,~,Ams,Sms,Ims] = ClosedUnclampedBspline([px',py']',spord,dsc); %construction of B-spline
Msconst = ConsistentBeamMassCalc(Ams,Ims,Sms,rho*1e-3); 
[~,Mbconst] =  BeamGaussIntegM(eye(6),Msconst,gsdata.L(1),3);

% fixedbounds = [min(xmin),max(xmax),min(ymin),max(ymax)];
figure;
plot(px,py,'o'); hold on;
plot([xmin;xmax],[py;py],'r+:'); plot([px;px],[ymin;ymax],'r+:'); pause(3);
svarnew_bar = (repmat([px,py],[1,nmem]))'; %list of crossectional PHYSICAL design variables in 1 column
varmin = (repmat([xmin,ymin],[1,nmem]))'; 
varmax = (repmat([xmax,ymax],[1,nmem]))';
nvar = length(svarnew_bar); % # of cross section variables 2 x # of control points x # of members
svarnew = (svarnew_bar - varmin)./(varmax - varmin); %vector of MATHEMATICAL design variables to be used in the optimization algorithm

SampPts = 100; %discretization of the b-spline polynomials

%% Setting values of the optimization properties


%MMA parameters

nv = nvar; %# of varialbes
mc = 3;    %# of constraints
a0mma = 1;              % Constant
amma = zeros(mc,1);      % Constant
cmma = 1e3*ones(mc,1);  % Constant
dmma = zeros(mc,1);      % Constant
svarold1 = svarnew;       % Initial xold1;
svarold2 = svarnew;       % Initial xold2;
low = nan(nv,1);         % Initial lower asymptotes 
upp = nan(nv,1);         % Initial upper asymptotes
scaling = 0.01; %scaling value (usually good is: 1e-3 or 1e-2)
fcsmovemma = 0.075/(abs(Ainit/(dx*dy)))^0.5;   %external move limit proportional to bounding box size costheta_init
movemmavec = zeros(nvar,1);
updateratio_cs = 0.05;

%propertied for the cross section geometry regulation
pn1 = 8; %power of the pnorm summation for the side length constraint
pn2 = 8; %power of the pnorm summation for the control polygon's cosine angle constraint
pn3 = 8; %power pf the pnorm summation for the minimum eigenfrequency

Lepsi = 1e-4*boxdiag; %constraint over the lengths of the control polygon sides
AngLim = 1.0; %control polygon vertex angle limit: cos(theta)

%parameters for the rectifier function that ensures non negative cross section area
A0 = 0; %This was once a min. cross section area threshold. This feature is inactive for a single axial beam 

%initializing variables and starting optimization process
maxit = 150;
stopcseps = 1e-3; %commonly in the range: 1e-2-1e-3
changecs = 1;
changecsold = changecs;


%% Initializing variables and execiting the optimization loop
loop = 0;
g1col = zeros(maxit,1);
g2col = zeros(maxit,1);
g3col = zeros(maxit,1);
fcol = zeros(maxit,1);
gcolest = zeros(maxit,1);
changsizeecol = zeros(maxit,1);
mmainitcol = zeros(maxit,1);
lambdacol = zeros(maxit,10);
Phicol = zeros(maxit,ndofs,10);
tstart = cputime;
figure;
fprintf('Optimization process started\n');
fprintf('----------------------------\n');
    if strcmp(BCs,'ps')
        fprintf('BCs.: pinned.---sup.\n');
        [w,~] = EigFreqCircCrossSec(Vstar,dz , E, nu, rho, nmem, 'ps');
        wcyl = w(1);
        fprintf('cylindrical fund. freq: w_cyl = %4.3f\n',wcyl);
    elseif strcmp(BCs,'cc')
        fprintf('BCs.: fixed---fixed.\n');
        [w,~] = EigFreqCircCrossSec(Vstar,dz , E, nu, rho, nmem, 'cc');
        wcyl = w(1);
        fprintf('cylindrical fund. freq: w_cyl = %4.3f\n',wcyl);        
    elseif strcmp(BCs,'cf')
        fprintf('BCs.: fixed---free\n');
        [w,~] = EigFreqCircCrossSec(Vstar,dz , E, nu, rho, nmem, 'cf');
        wcyl = w(1);
        fprintf('cylindrical fund. freq: w_cyl = %4.3f\n',wcyl);
    else
        fprintf('BCs.: sup.---sup.\n');
        [w,~] = EigFreqCircCrossSec(Vstar,dz , E, nu, rho, nmem, 'pp');
        wcyl = w(1);
        fprintf('cylindrical fund. freq: w_cyl = %4.3f\n',wcyl);
    end

while (loop < maxit)  && (changecs > stopcseps) %&& (changegs > stopgseps)
    tic
    %% Iteration initiation
    loop = loop + 1;
    if (changecsold > changecs) && (changecs > stopcseps)
        fcsmovemma  = fcsmovemma*(1-updateratio_cs);
    end
    clf; 
    varnum = 1;
    dg = zeros(nvar,1);
    dgLm = zeros(nvar,1);
    dgangm = zeros(nvar,1);
    Lp = ones(nmem*npts,1)*mean(Lpinit);
    costhetap1 = zeros(nmem*npts,1);
    V = 0;
    %% Physical design update shape and stiffness calculations

    svarnew_bar = varmin + svarnew.*(varmax - varmin); % x_bar of x - relation between mathematical and physical variables    

    %plotting the physical domain box
    mincorner = [-dx/2,-dy/2,-dz/2];
    maxcorner = [dx/2,dy/2,dz/2];
    DomainPlot(mincorner,maxcorner);
    %design update to each beam member: shape and stiffness, global volume
    %summation and move limit adaptation including realtime visualization and
    %reporting
    for nm = 1:nmem
        membersg{nm}.px = svarnew_bar(2*npts*(nm-1)+1:npts*(2*nm-1));
        membersg{nm}.py = svarnew_bar(npts*(2*nm-1)+1:2*npts*nm);

        %calculation of the cross section geometric boundary using b-spline
        [membersg{nm}.sp,membersg{nm}.N,membersg{nm}.dN,xi0,xi1,~,membersg{nm}.A,membersg{nm}.S,membersg{nm}.I] = ClosedUnclampedBspline([membersg{nm}.px,membersg{nm}.py]',spord,dsc); %construction of B-spline
        membersg{nm}.Ar = membersg{nm}.A; %Ar used to be a rectifiered mapped area calculation when we tried to apply a rectifier function, but since we implemented a regulated area move limits it hasn't been needed anymore.
        membersg{nm}.dArdA = 1;
        %constrution of the cross section boundary
        membersg{nm}.dxi = linspace(xi0,xi1,dsc);
        membersg{nm}.Cs = membersg{nm}.N'*[membersg{nm}.px',membersg{nm}.px(1:spord)';membersg{nm}.py',membersg{nm}.py(1:spord)']'; %Bspline explicit parametric curve
        membersg{nm}.dCs = membersg{nm}.dN'*[membersg{nm}.px',membersg{nm}.px(1:spord)';membersg{nm}.py',membersg{nm}.py(1:spord)']'; %Bderivative of the spline explicit parametric curve

        %construction of the 2D FE mesh and physical cross section identification      
        minbound = min([min(membersg{nm}.px),max(membersg{nm}.px),min(membersg{nm}.py),max(membersg{nm}.py)]);
        maxbound = max([min(membersg{nm}.px),max(membersg{nm}.px),min(membersg{nm}.py),max(membersg{nm}.py)]);
        membersg{nm}.polybounds = [minbound,maxbound,minbound,maxbound];

        [membersg{nm}.eldata.elconnect,membersg{nm}.eldata.nx,membersg{nm}.eldata.ny] = BuildFixedGrid(membersg{nm}.polybounds,nelx,nely); %building fixed grid inside the boundaries of the polygon
        membersg{nm}.eldata.nelx = nelx; membersg{nm}.eldata.nely = nely;
        membersg{nm}.eldata.nnodes = length(membersg{nm}.eldata.nx);
        membersg{nm}.eldata.nel = membersg{nm}.eldata.nelx*membersg{nm}.eldata.nely;
        
        %calculation properties of the cross section on the 2D FE mesh
        [membersg{nm}.eldata.in,membersg{nm}.eldata.on] = inpoly([membersg{nm}.eldata.nx,membersg{nm}.eldata.ny],[membersg{nm}.Cs(:,1),membersg{nm}.Cs(:,2)]); %identification of cross section internal and external nodes
        membersg{nm}.eldata = eldensity(membersg{nm}.eldata,membersg{nm}.N,membersg{nm}.dN,membersg{nm}.Cs,membersg{nm}.dCs,membersg{nm}.dxi); %calculation  of the FEs densities

        %Calculation of the cross section structural properties using BECAS: Ks, utils, csSol and all required submatrices
        [membersg{nm}.utils,membersg{nm}.Ks,membersg{nm}.csSol,membersg{nm}.submats] = BECAS_BeamConstitutiveCalculation(E,nu,membersg{nm}.eldata);       
        %calculating consistenr mass marix directly IAW Blasques 'Multi-material topology optimization' and Hodges et. al., 'Nonlinear composite beam theory'
        membersg{nm}.Ms = ConsistentBeamMassCalc(membersg{nm}.Ar,membersg{nm}.I,membersg{nm}.S,rho);

        %FE intergration along the beam (quadratic shape functions)
        [membersg{nm}.KbLoc,~] =  BeamGaussIntegM(membersg{nm}.Ks,membersg{nm}.Ms,membersg{nm}.L,2);
        [~,membersg{nm}.MbLoc] =  BeamGaussIntegM(membersg{nm}.Ks,membersg{nm}.Ms,membersg{nm}.L,3);
        if ~ismember(nm,markdesmem)
            membersg{nm}.MbLoc = membersg{nm}.MbLoc + Mbconst;
        end

        V = V + membersg{nm}.L*membersg{nm}.Ar; %physical volume calculation with penalization over non-physical geometry ('negative' cross section)

        % Realtime reporting: plotting to screen
        RealTimePlot(membersg,nm,SampPts);

        %updating MMA solver external move limit to fit the size of the cross section
        movemmavec(2*npts*(nm-1)+1:npts*(2*nm-1)) = fcsmovemma*(abs(membersg{nm}.A/(dx*dy))).^0.5;
        movemmavec(npts*(2*nm-1)+1:2*npts*nm) = fcsmovemma*(abs(membersg{nm}.A/(dx*dy))).^0.5;

    end

    %calculation of eigenvalues and vectors and essentially the objective function
    
    K = StiffAssemblyFull(membersg,gsdata); K = (K+K')/2; %stiffness assembly of all members
    M = MassAssemblyFull(membersg,gsdata);  M = (M+M')/2; %mass assembly of all members
    
    Phi = zeros(ndofs);
    Lambda = zeros(ndofs);
    [Phi(freedofs,freedofs),Lambda(freedofs,freedofs)] = eig(K(freedofs,freedofs),M(freedofs,freedofs)); %solving the eigenproblem results with Phi - matrix of eigenvectors and Lambda - diagonal matrix of eigenvalues
    lambda = diag(Lambda);
    mass_scales = zeros(ndofs,1);
    mass_scales(freedofs) = sqrt(diag(Phi(freedofs,freedofs)'*M(freedofs,freedofs)*Phi(freedofs,freedofs)).^(-1));

    Phi = Phi*diag(mass_scales); %scaling eigenvectors to comply with mass orthonormality condition;
    PhiMPhi = Phi'*M*Phi; PhiMPhi(PhiMPhi<1e-7) = 0; %#ok<NASGU> %mass orthonoramlity check 
    
    %sorting eigenvalues and modes so lambda_{i-1} < lambda_{i} < lambda_{i+1}...    
    lambda = lambda(freedofs);
    Phi = Phi(:,freedofs);
    [lambdasort,indsort] = sort(lambda);
    lambdasort10 = lambdasort(1:10);
    indsort10 = indsort(1:10);
    Phisort10 = Phi(:,indsort10);
   
    lambdacol(loop,:) = lambdasort10';
    Phicol(loop,:,:) = Phisort10; %comulative 10 lowest eigenvalues
    lambda_bar = sum(lambdasort10.^(-pn3))^(-1/pn3); %smooth minimum eigenvalue utilizing p-norm summation

    f = lambda_bar^(-1); %the objective function: the reciprocal of the smoothed min. eigenvalue
    fcol(loop) = f;

    %% Sensitivity analysis of all response functionals and calculation of geometrical constraints
    df = zeros(nvar,1);
    for nm = 1:nmem
        if ismember(nm,desmem)
            %derivatives calculation: the constitutive properties w.r.t density and the density of each element w.r.t. design variables
            [membersg{nm}.dA,membersg{nm}.dS,membersg{nm}.dI] = CrossecSens([membersg{nm}.px';membersg{nm}.py'],spord,membersg{nm}.N,membersg{nm}.dN); %dA/dx
            dKs = BECAS_dKs(membersg{nm}.utils,membersg{nm}.Ks,membersg{nm}.csSol,membersg{nm}.submats); %dKs/drhoe derivatives of the beam stiffness w.r.t. density of each element
            dMs = ConstMassSens(membersg{nm}.dA,membersg{nm}.dS,membersg{nm}.dI,membersg{nm}.Ar,membersg{nm}.S,rho);
            drhoe = DensSens(membersg{nm}.eldata,membersg{nm}.N,spord); %drhoe/dx - derivatives of the density w.r.t. c.p. coordinates
            membersg{nm}.dAr = membersg{nm}.dArdA*membersg{nm}.dA; %dAr/dA*dA/dx
            %identifying the active dofs for later assembly of the
            %derivatives of the stiffness and mass matrices
            actnodes = gsdata.memconnect(nm,:);
            actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
                       actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
                       actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];

            %calculation the derivatives of the global stiffness matrix, the global mass matrix and the volume constraint
            for ip = 1:2*npts
                dKb = zeros(18);
               
                %allocating derivatives from all planar elements
                for e = 1:membersg{nm}.eldata.nel
                    dKb_drhoe = zeros(18);
                    if drhoe(e,ip) ~= 0
                        %local stiffness matrix derivatives w.r.t. density map
                        [dKb_drhoe,~] =  BeamGaussIntegM(dKs(:,:,e),[],membersg{nm}.L,2);
                    end
                    %applying chain rule such that: dKb/ds = dKb/drho*drho/ds - where s is the c.pt coordinate variable indexed: ip.
                    dKb = dKb + dKb_drhoe*drhoe(e,ip);
                end
                %for the mass it's much simpler as the derivatives are directly calculated from the cross section's properties:
                [~,dMb] = BeamGaussIntegM([],dMs(:,:,ip),membersg{nm}.L,3);
                %derivatives of the objective function:
                sum_dlambda_dxi = 0;
                for idof = 1:length(lambdasort10)
                        dlambda_i_dxj = Phisort10(actdofs,idof)'*(dKb - lambdasort10(idof).*dMb)*Phisort10(actdofs,idof);  %dlambda_i_dxj = phi_i^T*(dK/dxj - lambda_i*dM/dxj)*phi_i
                        sum_dlambda_dxi = sum_dlambda_dxi + lambdasort10(idof)^(-(pn3+1))*dlambda_i_dxj;  %sum(lambda_i^(-(p+1))*dlambda_i_dxj
                end
                df(varnum) =  - (varmax(varnum) - varmin(varnum))*sum(lambda.^(-pn3))^(1/pn3-1)*sum_dlambda_dxi;
                varnum = varnum + 1;
            end
            
            %volume constraint's derivative calculation w.r.t. cross section design variabels
            dsvar_tmp1 = varmax(2*npts*(nm-1)+1:npts*(2*nm-1)) - varmin(2*npts*(nm-1)+1:npts*(2*nm-1));
            dsvar_tmp2 = varmax(  npts*(2*nm-1)+1:2*npts*nm  ) - varmin(  npts*(2*nm-1)+1:2*npts*nm  );
            dg(2*npts*(nm-1)+1:npts*(2*nm-1)) = dsvar_tmp1.*membersg{nm}.L.*membersg{nm}.dAr(1:npts);
            dg(npts*(2*nm-1)+1:2*npts*nm)     = dsvar_tmp2.*membersg{nm}.L.*membersg{nm}.dAr(npts+1:2*npts);
           
            %calculating control polygon properties to include in geometrical constraints
            if membersg{nm}.Ar > A0
                [Lp((nm-1)*npts+1:nm*npts),costhetap1((nm-1)*npts+1:nm*npts),dLp,dcosthetap1] = contpolygon(membersg{nm}.px',membersg{nm}.py');
                Lp1 = Lp((nm-1)*npts+1:nm*npts); %Li
                Lp2 = [Lp1(2:end);Lp1(1)]; %Li+1
                Lp1dLpdLx = Lp1.^(-pn1-1).*diag(dLp(:,1:npts)); %dLi^(p-1)*dLi/dxi
                Lp1dLpdLy = Lp1.^(-pn1-1).*diag(dLp(:,npts+1:2*npts)); %dLi^(p-1)*dLi/dyi
                Lp2dLpdLx = Lp2.^(-pn1-1).*[-diag(dLp(2:npts,2:npts));-dLp(1,1)]; %dLi+1^(p-1)*dLi+1/dxi
                Lp2dLpdLy = Lp2.^(-pn1-1).*[-diag(dLp(2:npts,npts+2:2*npts));-dLp(1,npts+1)]; %dLi+1^(p-1)*dLi+1/dyi
                %summing and placing the derivatives of the geometrical constraints in a design-variable-wise order
                dgLm(2*npts*(nm-1)+1:npts*(2*nm-1)) = Lp1dLpdLx + Lp2dLpdLx; %(dLi^(p-1)*dLi/dxi + dLi+1^(p-1)*dLi+1/dxi
                dgLm(npts*(2*nm-1)+1:2*npts*nm) = Lp1dLpdLy + Lp2dLpdLy; %(dLi^(p-1)*dLi/dyi + dLi+1^(p-1)*dLi+1/dyi
                dgangm(2*npts*(nm-1)+1:npts*(2*nm-1)) = sum((costhetap1((nm-1)*npts+1:nm*npts).^(pn2-1)).*dcosthetap1(:,1:npts));
                dgangm(npts*(2*nm-1)+1:2*npts*nm) = sum((costhetap1((nm-1)*npts+1:nm*npts).^(pn2-1)).*dcosthetap1(:,1+npts:2*npts));
            else
                Lp((nm-1)*npts+1:nm*npts) = ones(npts,1)*Lepsi*100;
                dgLm(2*npts*(nm-1)+1:npts*(2*nm-1)) = ones(npts,1)*1e-6;
                dgLm(npts*(2*nm-1)+1:2*npts*nm) = ones(npts,1)*1e-6;
                dgangm(2*npts*(nm-1)+1:npts*(2*nm-1)) = ones(1,npts)*1e-6;
                dgangm(npts*(2*nm-1)+1:2*npts*nm) = ones(1,npts)*1e-6;
            end
            membersg{nm}.Lp = Lp((nm-1)*npts+1:nm*npts);
            membersg{nm}.costheta = costhetap1((nm-1)*npts+1:nm*npts) - 1;
       end
    end
    
    gL  = sum(Lp.^-pn1).^(1/pn1);  %p-norm summation of all polygon side lengths
    dgL = -sum((Lp).^(-pn1)).^(1/pn1-1).*dgLm.*(varmax(1:nvar)-varmin(1:nvar)); %derivatives of the min. polygon side length constraints

    gang = sum(costhetap1.^pn2)^(1/pn2)-1; %smooth max cosine angles
    dgang = sum(costhetap1.^pn2).^(1/pn2-1).*dgangm.*(varmax(1:nvar)-varmin(1:nvar)); %derivatives of the smoothed max. cosine angles

    g1col(loop) = V;  %comulative volume constraint
    g2col(loop) = gL; %comulative minimum polygon side length constraint
    g3col(loop) = gang; % comulative max. cosine angle
    gcolest(loop) = dg'*svarnew; %reavaluated comulative volume
    
    %% updating design with MMA
    
    svarval = svarnew;
    svarminmma(1:nvar,1) = max(zeros(nvar,1),svarval(1:nvar,1)-movemmavec(1:nvar));
    svarmaxmma(1:nvar,1) = min( ones(nvar,1),svarval(1:nvar,1)+movemmavec(1:nvar));
    fscale = scaling/fcol(1); %scaling factor of the objective wrt 1st iteration value
    fscl = f*fscale; %scaling objective

    fval = [V/Vstar - 1,gL*Lepsi-1,gang/AngLim - 1]';
    dfdx1 = dg(:)/Vstar;
    dfdx1(nvar+1:end) = [];
    dfdx2 = zeros(nvar,1); dfdx2(1:nvar) = dgL*Lepsi;
    dfdx3 = zeros(nvar,1); dfdx3(1:nvar) = dgang/AngLim;    
    dfdx = [dfdx1,dfdx2,dfdx3]';
    df = fscale*df; %scaling sensitivites
    %calling the mma subproblem and updating design: 
    [svarnew,~,~,~,~,~,~,~,~,low,upp,mmainit] = mmasub(mc,nv,loop,svarval,svarminmma,svarmaxmma,svarold1,svarold2,fscl,df,fval,dfdx,low,upp,a0mma,amma,cmma,dmma);
    mmainitcol(loop) = mmainit;
    svarold2 = svarold1;
    svarold1 = svarval;
    changecs = max(max(abs(svarnew-svarval)));
    changsizeecol(loop) = changecs;
    fprintf('change: %5.4f,init: %2i, loop: %2i, obj: %4.4f, w1 = %4.3f, w1/w_cyl = %4.3f, V/V*: %3.3f, min(Lp)/Lp_min: %2.2f, max(cos(th)): %3.2f\n',changecs,mmainit,loop,1/f,sqrt(min(lambdasort10)),sqrt(min(lambdasort10))/wcyl,V/Vstar,min(Lp)/Lepsi,max(costhetap1)-1);
end %%%%%%%%%%%%%%%%%%%%%%%%%%%%end of optimization loop%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tend = cputime - tstart;
if changecs <= stopcseps %&& changegs <= stopgseps
    fprintf('Optimization terminated with convergence. Elapsed time: %4.1f sec\n',tend);
else
    fprintf('Optimization terminated when reached max. iterataions. Elapsed time: %4.1f sec\n',tend);
end

fcol(loop+1:end) = [];
g1col(loop+1:end) = [];
g2col(loop+1:end) = [];
g3col(loop+1:end) = [];
mmainitcol(loop+1:end) = [];
changsizeecol(loop+1:end) = [];

save('opt_data','fcol','g1col','g2col','g3col','changsizeecol','mmainitcol','svarnew','membersg');

end

%% Internal functions:

function data = beamconstruct(dz,nmem)

%Construction of the beam assembly, indexing and connectivity mapping. can
%be useful also for a 3D ground structure.

data.nnodes = 2*nmem + 1;
data.nmem = nmem;
data.IX = zeros(data.nnodes,3);
gapz = dz/nmem;
data.IX(1:nmem+1,3) = linspace(-dz/2,dz/2,nmem+1);
data.IX(nmem+2:end,3) = linspace(-dz/2+gapz/2,dz/2-gapz/2,nmem);
ii = 1:nmem;
jj = nmem+2:data.nnodes;
kk = 2:nmem+1;
data.memconnect = [ii',jj',kk']; 
nnz = 0;
for m = 1:nmem    
    actnodes = data.memconnect(m,:);
    actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
               actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
               actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];
    data.Srow(nnz+1:nnz+324,1) = reshape(repmat(actdofs,1,18),324,1);
    data.Scol(nnz+1:nnz+324,1) = reshape(repmat(actdofs,18,1),324,1);
    nnz = nnz + 324;    
    Lx = data.IX(kk(m),1) - data.IX(ii(m),1); %ith member X dir. projection
    Ly = data.IX(kk(m),2) - data.IX(ii(m),2); %ith member Y dir. projection
    Lz = data.IX(kk(m),3) - data.IX(ii(m),3); %ith member Z dir. projection
    data.L(m) = (Lx^2+Ly^2+Lz^2)^0.5; %ith member length
    data.Cx(m) = Lx/data.L(m); %ith member cosines - x dir.
    data.Cy(m) = Ly/data.L(m); %ith member cosines - y dir.
    data.Cz(m) = Lz/data.L(m); %ith member cosine - z dir.
    
end

end

function [xx,yy,xxmin,xxmax,yymin,yymax] = CircCpts(np,r,theta0,cx,cy,boxx,boxy,lim)

%construction of the bspline control point polygon in a circular pattern
%and setting physical box constraints for each control point coordinate
%
%inputs:
% np - number of control points
% r  - radius distance of the control points positions (not exactly the circular curve radius)
% theta0 - tilt angle of the first contorl points w.r.t. the vertical axis.
% cx,cy - coordinates of the center of the circle
% boxx, boxy - box constraints of the physical design domain.
% lim - limitation of the control points allowed positions near the axes.
%
% outputs:
% xx,yy - coordinates of the control points
% xxmin, yymin - individual minimum allowed bounds of each control point
% xxmax, yymax - individual maximum allowed bounds of each control point

theta = linspace(theta0,2*pi+theta0,np+1);
dtheta = theta(2) - theta(1);

xlb = cx - boxx/2;
xub = cx + boxx/2;
ylb = cy - boxy/2;
yub = cy + boxy/2;

xx = cx + r*cos(theta(1:end-1)+dtheta/2);
yy = cy + r*sin(theta(1:end-1)+dtheta/2);

deltax = boxx;
deltay = boxy;
xxmin(xx>0) = max(xx(xx>0)-deltax,lim);
xxmax(xx>0) = min(xx(xx>0)+deltax,xub);
xxmin(xx<0) = max(xx(xx<0)-deltax,xlb);
xxmax(xx<0) = min(xx(xx<0)+deltax,-lim);
yymin(yy>0) = max(yy(yy>0)-deltay,lim);
yymax(yy>0) = min(yy(yy>0)+deltay,yub);
yymin(yy<0) = max(yy(yy<0)-deltay,ylb);
yymax(yy<0) = min(yy(yy<0)+deltay,-lim);

end

function [sp,N,dN,xi0,xi1,kntscoor,A,S,I] = ClosedUnclampedBspline(P,p,desc)
% Generates a Counterclockwise closed spline using control points.
%inputs: 'P' control points - 2 rows vector of the clamping polygon
%        'p' order - B-spline plynomials order
%        'xi0,xi1' bounding spline knots parameters
%        properties of the area calculated utilizing Green's theorem
%        'A' area 
%        'C' centroid of the area [x,y]
%        'I' inertia tensor w.r.t. centroid: [Ixx,Ixy, 0 ...
%                                             Ixy,Iyy, 0 ; 
%                                               0 , 0 ,Jzz]
%
%
sp = 1;
P = [P, P(:,1: p )]; %repeating the first n control points to create a closed curve
n = length(P); % order of B-spline
m = n + p; %order of knots span vector
Xi = 1:m; % knots span vector
xi0 = p; %lower integration limit
xi1 = n; %upper integratio limit
xi = linspace(xi0,xi1,desc); %xi the parametric variable of the B-spline
[N,dN] = bspline_base_and_deriv(p,Xi,xi,desc);
xx = N'*P(1,:)'; %explicit x(xi) cooridnate
yy = N'*P(2,:)'; %explicit y(xi) cooridnate
dxx = dN'*P(1,:)'; %derivative: dx/dxi = sigma(dN/dxi*P(1)) = [dN/dxi]^T*P(1)
dyy = dN'*P(2,:)'; %derivative: dy/dxi = sigma(dN/dxi*P(2)) = [dN/dxi]^T*P(2)

%finding the coordinates of the knots
knotind = zeros(1,n-p+1);
for ix = xi0:xi1
    knotind(ix-xi0+1) = find(xi>=Xi(ix),1,'first');
end
knotind(end) = knotind(1);
kntscoor = [xx(knotind),yy(knotind)];
%explicit formulation of the cross section properties in the closed spline
%using Green's therorem IAW prof. Elber's paper

A = 0.5*trapz(xi,(xx.*dyy - yy.*dxx)); %cross section area
Sx = -0.5*trapz(xi,(yy.^2.*dxx));
Sy = 0.5*trapz(xi,(xx.^2.*dyy));

%inertia terms w.r.t. x,y reference frame located in the original datum

Ipxx = -1/3*trapz(xi,(yy.^3.*dxx));
Ipyy =  1/3*trapz(xi,(xx.^3.*dyy));
Ipxy = -0.5*trapz(xi,(xx.*yy.^2.*dxx));
Ipyx = 0.5*trapz(xi,(xx.^2.*yy.*dyy));

%in case of truncation inaccuracy of the 1st moment around zero, we reduce it manually:
if abs(Sx)>Ipxx || abs(Sx)>Ipyy; Sx = 1e-3*Sx; end
if abs(Sy)>Ipxx || abs(Sy)>Ipyy; Sy = 1e-3*Sy; end

S = [Sx,Sy]; %first moment of area
%inertia terms located at the centroid:
Ixx  = Ipxx - Sy^2/A;
Iyy  = Ipyy - Sx^2/A;
Ixy = Ipxy - Sx*Sy/A;
Iyx = Ipyx - Sx*Sy/A;

%inertia tensor, including approximated polar moment of inertia (no St. Venant term)
Jzz = Ixx+Iyy;
I = [Ixx,Ixy, 0 ;...
     Iyx,Iyy, 0 ;...
      0 , 0 ,Jzz];
end

function [econnect, nx,ny] = BuildFixedGrid(boundingbox,nelx,nely)

%subroutine to create a fixed grid mesh with the correct connectivity
%input:
%       cx, cy - origin coordinates of the grid
%       dx, dy - size of grid
%       res - resolution number: number of elements in the x direction
%output:
%       nx, ny - coordinates of the indexed node ordered coloumnwise

x = linspace(boundingbox(1), boundingbox(2),nelx+1);
y = linspace(boundingbox(3), boundingbox(4),nely+1);

[nx,ny] = meshgrid(x,y);
nx = nx(:); %indexed node x coordinates
ny = ny(:); %indexed node y coordinates
%building connectivity matrix: attributing each element to its 4 nodes (Q4
%1st order elements)
nodenrs = reshape(1:(1+nelx)*(1+nely),1+nely,1+nelx); %nodes map on the mesh grid
k = 0;
econnect = zeros(nelx*nely,4);
for nnx = 1:nelx
    for nny = 1:nely
        k = k + 1;
        econnect(k,1) = nodenrs(nny,nnx);
        econnect(k,2) = nodenrs(nny,nnx+1);
        econnect(k,3) = nodenrs(nny+1,nnx+1);
        econnect(k,4) = nodenrs(nny+1,nnx);
    end
end
end

function K = StiffAssemblyFull(membersg,gsdata)

%stiffness matrix assembly IAW the DOFs
nnodes = length(gsdata.IX(:,1));
ndofs = 6*nnodes; 
K = zeros(ndofs);

for m = 1:gsdata.nmem
    actnodes = membersg{m}.nodes;
    actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
               actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
               actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];
    K(actdofs,actdofs) = K(actdofs,actdofs) +  membersg{m}.KbLoc;
end

end

function M = MassAssemblyFull(membersg,gsdata)

%mass matrix assembly IAW the DOFs
nnodes = length(gsdata.IX(:,1));
ndofs = 6*nnodes; 
M = zeros(ndofs);

for m = 1:gsdata.nmem
    actnodes = membersg{m}.nodes;
    actdofs = [actnodes(1)*6-5,actnodes(1)*6-4,actnodes(1)*6-3,actnodes(1)*6-2,actnodes(1)*6-1,actnodes(1)*6 ...
               actnodes(2)*6-5,actnodes(2)*6-4,actnodes(2)*6-3,actnodes(2)*6-2,actnodes(2)*6-1,actnodes(2)*6 ...
               actnodes(3)*6-5,actnodes(3)*6-4,actnodes(3)*6-3,actnodes(3)*6-2,actnodes(3)*6-1,actnodes(3)*6];
    M(actdofs,actdofs) = M(actdofs,actdofs) +  membersg{m}.MbLoc;
end

end

function Ms = ConsistentBeamMassCalc(A,I,S,rho)

%calculating consistent mass marix directly IAW Blasques
%'Multi-material topology optimization' (https://doi.org/10.1016/j.compstruct.2013.12.021)
% and Hodges, 'Nonlinear composite beam theory' (https://doi.org/10.2514/4.866821)
% A - the cross section area, S - the first moment of area: Sx = A*x_c, Sy = A*y_c
% I - the area inertia tensor which when multiplied by the density - rho,
% becomes the mass tensor of inertia
% notice that they refer to 'mass per unit length' which is equivalent to
% rho*A in this case.

Ms = zeros(6);
Ms(1,1) = rho*A;
Ms(2,2) = rho*A;
Ms(3,3) = rho*A;
Ms(4,4) = rho*I(1,1);
Ms(5,5) = rho*I(2,2);
Ms(6,6) = rho*I(3,3);

Ms(4,5) = -I(1,2);
% 

Ms(1,6) = -rho*S(1);
Ms(2,6) =  rho*S(2);
Ms(3,4) =  rho*S(1);
Ms(3,5) = -rho*S(2);


Ms = (Ms+Ms')/2;

end

function dMs = ConstMassSens(dA,dS,dI,~,~,rho)

%calculating derivatrives of the consistent mass marix directly IAW Blasques
%'Multi-material topology optimization' and Hodges, 'Nonlinear
%composite beam theory

nvars = length(dA);

dMs = zeros(6,6,nvars);
dMs(1,1,:) = rho*dA; %rho*dA/dx
dMs(2,2,:) = rho*dA; %rho*dA/dx
dMs(3,3,:) = rho*dA; %dA/dx
dMs(4,4,:) = rho*dI(:,1); %dIxx/dx
dMs(5,5,:) = rho*dI(:,2); %dIyy/dx
dMs(6,6,:) = rho*dI(:,1) + rho*dI(:,2); %d/dx(Iyy + Ixx)

dMs(1,6,:) = -rho*dS(:,1); %-rho*dSx/dx
dMs(2,6,:) =  rho*dS(:,2); % rho*dSy/dx
dMs(3,4,:) =  rho*dS(:,1); % rho*dSx/dx
dMs(3,5,:) = -rho*dS(:,2); %-rho*dSy/dx

dMs(4,5,:) = -rho*dI(3); %dIxy/dx 

%imposing symmetry:
dMs(6,1,:) = dMs(1,6,:);
dMs(6,2,:) = dMs(2,6,:);
dMs(4,3,:) = dMs(3,4,:);
dMs(5,3,:) = dMs(3,5,:);
dMs(5,4,:) = dMs(4,5,:);

end

function DomainPlot(mincor,maxcor)

%plotting the box representing the physical domain bounds

xminlim = mincor(1);
yminlim = mincor(2);
zminlim = mincor(3);
xmaxlim = maxcor(1);
ymaxlim = maxcor(2);
zmaxlim = maxcor(3);


plot3([zminlim,zmaxlim,zmaxlim,zminlim,zminlim],xminlim*ones(1,5),[yminlim,yminlim,ymaxlim,ymaxlim,yminlim],'k--'); hold on; axis equal; axis off;
plot3([zminlim,zmaxlim,zmaxlim,zminlim,zminlim],xmaxlim*ones(1,5),[yminlim,yminlim,ymaxlim,ymaxlim,yminlim],'k--');
plot3([zminlim,zminlim],[xminlim,xmaxlim],[yminlim,yminlim],'k--');
plot3([zminlim,zminlim],[xminlim,xmaxlim],[ymaxlim,ymaxlim],'k--');
plot3([zmaxlim,zmaxlim],[xminlim,xmaxlim],[yminlim,yminlim],'k--');
plot3([zmaxlim,zmaxlim],[xminlim,xmaxlim],[ymaxlim,ymaxlim],'k--');
end

function membersg = RealTimePlot(membersg,nm,SampPts)

% real time plotting of beam segments with proper visualization

npts = length(membersg{nm}.px);
membersg{nm}.PtsLocal = [membersg{nm}.Cs(1:length(membersg{nm}.Cs)/SampPts:end,1), membersg{nm}.Cs(1:length(membersg{nm}.Cs)/SampPts:end,2),zeros(SampPts,1)/2]; %exoort sampling curve points in local coordinates
membersg{nm}.ExpPts2Cad = (membersg{nm}.Rt(1:3,1:3)'*membersg{nm}.PtsLocal'+repmat(membersg{nm}.IX(2,:),[SampPts,1])')';
membersg{nm}.Cpts2Cad = membersg{nm}.Rt(1:3,1:3)'*[membersg{nm}.px';membersg{nm}.py';zeros(1,npts)] + repmat(membersg{nm}.IX(2,:),[npts,1])';
membersg{nm}.ExpPts2Cad(end+1,:) = membersg{nm}.ExpPts2Cad(1,:);
EdgeMemPoints1 = (membersg{nm}.Rt(1:3,1:3)'*membersg{nm}.PtsLocal'+repmat(membersg{nm}.IX(1,:),[SampPts,1])')';
EdgeMemPoints2 = (membersg{nm}.Rt(1:3,1:3)'*membersg{nm}.PtsLocal'+repmat(membersg{nm}.IX(3,:),[SampPts,1])')';
tmpx = [EdgeMemPoints1(:,1),EdgeMemPoints2(:,1)];
tmpy = [EdgeMemPoints1(:,2),EdgeMemPoints2(:,2)];
tmpz = [EdgeMemPoints1(:,3),EdgeMemPoints2(:,3)];
plot3([EdgeMemPoints1(:,3);EdgeMemPoints1(1,3)],[EdgeMemPoints1(:,1);EdgeMemPoints1(1,1)],[EdgeMemPoints1(:,2);EdgeMemPoints1(1,2)],'k','LineWidth',1.0);
hold on; axis equal; axis off; view([45,20]);
plot3([EdgeMemPoints2(:,3);EdgeMemPoints2(1,3)],[EdgeMemPoints2(:,1);EdgeMemPoints2(1,1)],[EdgeMemPoints2(:,2);EdgeMemPoints2(1,2)],'k','LineWidth',1.0);
fv = WatertightStlWrite([],tmpx(:),tmpy(:),tmpz(:),membersg{nm}.Rt(1:3,1:3),'binary');
hp4 = patch('faces',fv.faces,'vertices',[fv.vertices(:,3),fv.vertices(:,1),fv.vertices(:,2)]);
hp4.FaceAlpha = 1;%hp4.FaceColor = [0,0,1];
hp4.FaceColor = [0.875,0.875,0.875]; hp4.EdgeColor = 'none';
view([45,20]);
drawnow;

end
